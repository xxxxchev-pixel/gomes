<?php
// Redirecionamento para nova localização
header('Location: auth/logout.php');
exit;
