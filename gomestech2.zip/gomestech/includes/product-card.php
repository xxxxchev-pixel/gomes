<?php
/**
 * Componente de Cartão de Produto Padrão
 * Usado em: index.php, catalogo.php, categoria/index.php, favoritos.php, etc.
 */

function render_product_card($product) {
    $product_id = $product['id'] ?? 0;
    $product_slug = $product['slug'] ?? '';
    $product_url = $product_slug ? "produto.php?url=" . urlencode($product_slug) : "produto.php?id=" . $product_id;
    
    $marca = htmlspecialchars($product['marca'] ?? '');
    $modelo = htmlspecialchars($product['modelo'] ?? '');
    $categoria = htmlspecialchars($product['categoria'] ?? '');
    $preco = number_format($product['preco'] ?? 0, 2, ',', '.');
    $preco_original = isset($product['preco_original']) && $product['preco_original'] > $product['preco'] 
        ? number_format($product['preco_original'], 2, ',', '.') 
        : null;
    
    $imagem = htmlspecialchars($product['imagem'] ?? 'https://via.placeholder.com/300/F5F5F7/1D1D1F?text=' . urlencode($modelo));
    
    // Badges
    $badges = [];
    if (!empty($product['novidade'])) {
        $badges[] = '<span class="product-badge badge-new">Novidade</span>';
    }
    if (!empty($product['destaque'])) {
        $badges[] = '<span class="product-badge badge-featured">Destaque</span>';
    }
    if ($preco_original) {
        $desconto = round((($product['preco_original'] - $product['preco']) / $product['preco_original']) * 100);
        $badges[] = '<span class="product-badge badge-discount">-' . $desconto . '%</span>';
    }
    
    $badges_html = !empty($badges) ? '<div class="product-badges">' . implode('', $badges) . '</div>' : '';
    
    ?>
    <div class="product-card">
        <?php echo $badges_html; ?>
        <a href="<?php echo $product_url; ?>" class="product-image">
            <img 
                src="<?php echo $imagem; ?>" 
                alt="<?php echo $marca . ' ' . $modelo; ?>"
                loading="lazy"
                onerror="this.src='https://via.placeholder.com/300/F5F5F7/1D1D1F?text=<?php echo urlencode($marca); ?>'"
            >
        </a>
        <div class="product-info">
            <span class="product-category"><?php echo $categoria; ?></span>
            <h3 class="product-title">
                <a href="<?php echo $product_url; ?>">
                    <?php echo $marca . ' ' . $modelo; ?>
                </a>
            </h3>
            <div class="product-footer">
                <div class="product-price-wrapper">
                    <?php if ($preco_original): ?>
                        <span class="product-price-old">€<?php echo $preco_original; ?></span>
                    <?php endif; ?>
                    <span class="product-price">€<?php echo $preco; ?></span>
                </div>
                <div class="product-actions">
                    <form method="post" action="carrinho.php" class="add-to-cart-form">
                        <input type="hidden" name="id" value="<?php echo $product_id; ?>">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="qty" value="1">
                        <button type="submit" class="btn btn-primary btn-cart-main">
                            🛒 Adicionar ao Carrinho
                        </button>
                    </form>
                    <div class="product-secondary-actions">
                        <button class="btn-icon btn-secondary-action favorite-btn" 
                                data-id="<?php echo $product_id; ?>" 
                                title="Adicionar aos favoritos">
                            ❤️ <span class="icon-text">Favorito</span>
                        </button>
                        <button class="btn-icon btn-secondary-action compare-btn" 
                                data-id="<?php echo $product_id; ?>" 
                                title="Comparar">
                            ⚖️ <span class="icon-text">Comparar</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}
?>
