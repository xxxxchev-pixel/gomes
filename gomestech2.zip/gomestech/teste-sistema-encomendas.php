<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste do Sistema de Encomendas - GomesTech</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        
        .test-card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        h1 {
            color: #00c853;
            text-align: center;
        }
        
        h2 {
            color: #333;
            border-bottom: 2px solid #00c853;
            padding-bottom: 10px;
        }
        
        .test-section {
            margin: 20px 0;
            padding: 15px;
            background: #f9f9f9;
            border-left: 4px solid #00c853;
            border-radius: 4px;
        }
        
        .status {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            margin-left: 10px;
        }
        
        .status.success {
            background: #00c853;
            color: white;
        }
        
        .status.error {
            background: #f44336;
            color: white;
        }
        
        .status.warning {
            background: #ff9800;
            color: white;
        }
        
        pre {
            background: #2d2d2d;
            color: #f1f1f1;
            padding: 15px;
            border-radius: 8px;
            overflow-x: auto;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background: #00c853;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            margin: 5px;
            transition: all 0.3s;
        }
        
        .btn:hover {
            background: #00a844;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,200,83,0.3);
        }
        
        .btn-secondary {
            background: #2196f3;
        }
        
        .btn-secondary:hover {
            background: #1976d2;
        }
        
        code {
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 4px;
            color: #00c853;
        }
        
        ul {
            line-height: 1.8;
        }
        
        .checklist li {
            list-style: none;
            padding-left: 30px;
            position: relative;
        }
        
        .checklist li:before {
            content: '✓';
            position: absolute;
            left: 0;
            color: #00c853;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <h1>🧪 Teste do Sistema de Encomendas</h1>
    
    <div class="test-card">
        <h2>📋 Checklist de Verificação</h2>
        <ul class="checklist">
            <li>Base de dados com tabelas <code>encomendas</code> e <code>encomenda_itens</code></li>
            <li>Coluna <code>stock</code> na tabela <code>produtos</code></li>
            <li>Colunas <code>nif</code>, <code>codigo_postal</code>, <code>cidade</code> na tabela <code>users</code></li>
            <li>Arquivo <code>checkout.php</code> com processamento de encomendas</li>
            <li>Arquivo <code>encomenda-confirmacao.php</code> criado</li>
            <li>Sistema de geração de números de encomenda (GT + data + random)</li>
            <li>Transações de base de dados implementadas</li>
            <li>Gestão de stock automática</li>
            <li>Validação de formulários</li>
            <li>Instruções de pagamento por método</li>
        </ul>
    </div>

    <?php
    require_once 'config.php';
    
    // Testar conexão com a base de dados
    echo '<div class="test-card">';
    echo '<h2>🔌 Teste de Conexão com Base de Dados</h2>';
    
    if ($mysqli->connect_error) {
        echo '<p>Conexão: <span class="status error">ERRO</span></p>';
        echo '<p>Erro: ' . $mysqli->connect_error . '</p>';
    } else {
        echo '<p>Conexão: <span class="status success">OK</span></p>';
        echo '<p>Base de dados: ' . $mysqli->get_server_info() . '</p>';
    }
    echo '</div>';
    
    // Verificar se as tabelas existem
    echo '<div class="test-card">';
    echo '<h2>📊 Verificação de Tabelas</h2>';
    
    $tables_to_check = ['encomendas', 'encomenda_itens', 'produtos', 'users'];
    
    foreach ($tables_to_check as $table) {
        $result = $mysqli->query("SHOW TABLES LIKE '$table'");
        if ($result && $result->num_rows > 0) {
            echo "<p>Tabela <code>$table</code>: <span class='status success'>EXISTE</span></p>";
            
            // Verificar estrutura
            $columns = $mysqli->query("SHOW COLUMNS FROM $table");
            echo "<div class='test-section'>";
            echo "<strong>Colunas:</strong><br>";
            while ($col = $columns->fetch_assoc()) {
                echo "- {$col['Field']} ({$col['Type']})<br>";
            }
            echo "</div>";
        } else {
            echo "<p>Tabela <code>$table</code>: <span class='status error'>NÃO EXISTE</span></p>";
            
            if ($table === 'encomendas' || $table === 'encomenda_itens') {
                echo "<p><strong>⚠️ Ação necessária:</strong> Execute o script <code>database/criar_tabelas_encomendas.sql</code></p>";
            }
        }
    }
    echo '</div>';
    
    // Verificar arquivos importantes
    echo '<div class="test-card">';
    echo '<h2>📁 Verificação de Arquivos</h2>';
    
    $files_to_check = [
        'checkout.php' => 'Página de checkout',
        'encomenda-confirmacao.php' => 'Página de confirmação',
        'carrinho.php' => 'Página do carrinho',
        'database/criar_tabelas_encomendas.sql' => 'Script de criação de tabelas',
        'SISTEMA_ENCOMENDAS.md' => 'Documentação do sistema'
    ];
    
    foreach ($files_to_check as $file => $desc) {
        if (file_exists($file)) {
            echo "<p><code>$file</code>: <span class='status success'>EXISTE</span> - $desc</p>";
        } else {
            echo "<p><code>$file</code>: <span class='status error'>NÃO ENCONTRADO</span> - $desc</p>";
        }
    }
    echo '</div>';
    
    // Teste de geração de número de encomenda
    echo '<div class="test-card">';
    echo '<h2>🔢 Teste de Geração de Número de Encomenda</h2>';
    
    $test_order_number = 'GT' . date('Ymd') . rand(1000, 9999);
    echo "<p>Número gerado: <strong style='color: #00c853; font-size: 20px;'>$test_order_number</strong></p>";
    echo "<p>Formato: GT + AAAAMMDD + 4 dígitos aleatórios</p>";
    echo "<p>Data atual: " . date('d/m/Y') . "</p>";
    echo '</div>';
    
    // Verificar produtos com stock
    echo '<div class="test-card">';
    echo '<h2>📦 Produtos Disponíveis para Teste</h2>';
    
    $result = $mysqli->query("SELECT id, marca, modelo, preco, stock FROM produtos LIMIT 5");
    
    if ($result && $result->num_rows > 0) {
        echo "<table style='width: 100%; border-collapse: collapse;'>";
        echo "<tr style='background: #f5f5f5; font-weight: bold;'>";
        echo "<th style='padding: 10px; text-align: left;'>ID</th>";
        echo "<th style='padding: 10px; text-align: left;'>Produto</th>";
        echo "<th style='padding: 10px; text-align: right;'>Preço</th>";
        echo "<th style='padding: 10px; text-align: right;'>Stock</th>";
        echo "</tr>";
        
        while ($product = $result->fetch_assoc()) {
            $stock_status = $product['stock'] > 0 ? 'success' : 'error';
            echo "<tr style='border-bottom: 1px solid #eee;'>";
            echo "<td style='padding: 10px;'>{$product['id']}</td>";
            echo "<td style='padding: 10px;'>{$product['marca']} {$product['modelo']}</td>";
            echo "<td style='padding: 10px; text-align: right;'>" . number_format($product['preco'], 2, ',', '.') . " €</td>";
            echo "<td style='padding: 10px; text-align: right;'><span class='status $stock_status'>{$product['stock']}</span></td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p><span class='status error'>Nenhum produto encontrado</span></p>";
    }
    echo '</div>';
    ?>
    
    <div class="test-card">
        <h2>🚀 Próximos Passos</h2>
        <div class="test-section">
            <h3>1. Configurar Base de Dados</h3>
            <p>Se as tabelas não existirem, execute:</p>
            <pre>mysql -u root -p gomestech < database/criar_tabelas_encomendas.sql</pre>
            <p>Ou importe via phpMyAdmin</p>
        </div>
        
        <div class="test-section">
            <h3>2. Testar Fluxo de Compra</h3>
            <ul>
                <li>Faça login no site</li>
                <li>Adicione produtos ao carrinho</li>
                <li>Acesse o checkout</li>
                <li>Preencha todos os campos</li>
                <li>Selecione um método de pagamento</li>
                <li>Finalize a encomenda</li>
                <li>Verifique a página de confirmação</li>
            </ul>
        </div>
        
        <div class="test-section">
            <h3>3. Verificar Sistema</h3>
            <ul>
                <li>Verifique se a encomenda foi criada na base de dados</li>
                <li>Confirme que o stock foi reduzido</li>
                <li>Verifique se o carrinho foi limpo</li>
                <li>Teste os diferentes métodos de pagamento</li>
            </ul>
        </div>
        
        <div style="text-align: center; margin-top: 30px;">
            <a href="index.php" class="btn">🏠 Ir para a Loja</a>
            <a href="carrinho.php" class="btn btn-secondary">🛒 Ver Carrinho</a>
            <?php if (file_exists('SISTEMA_ENCOMENDAS.md')): ?>
                <a href="SISTEMA_ENCOMENDAS.md" class="btn btn-secondary" download>📄 Download Documentação</a>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="test-card" style="background: #e3f2fd;">
        <h2>💡 Dicas</h2>
        <ul>
            <li><strong>NIF:</strong> Use 9 dígitos (ex: 123456789)</li>
            <li><strong>Código Postal:</strong> Formato XXXX-XXX (ex: 1000-100)</li>
            <li><strong>Métodos de Pagamento:</strong> Todos simulados, nenhum pagamento real é processado</li>
            <li><strong>Stock:</strong> É reduzido automaticamente após a compra</li>
            <li><strong>Envio Grátis:</strong> Para compras ≥ 50 €</li>
        </ul>
    </div>
</body>
</html>
