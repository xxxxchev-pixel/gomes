-- =====================================================
-- ESPECIFICAÇÕES COMPLETAS PARA TODOS OS 66 PRODUTOS
-- =====================================================

USE gomestech;

-- =====================================================
-- SMARTPHONES (9 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.1" Super Retina XDR OLED',
    'Resolução', '2556 x 1179 pixels',
    'Processador', 'A17 Pro (3nm)',
    'RAM', '8GB',
    'Armazenamento', '256GB',
    'Câmara Principal', '48MP + 12MP Ultra + 12MP Tele',
    'Câmara Frontal', '12MP TrueDepth',
    'Bateria', '3279 mAh',
    'Sistema Operativo', 'iOS 17',
    '5G', 'Sim',
    'Resistência', 'IP68',
    'Face ID', 'Sim',
    'Carregamento', 'MagSafe 15W'
) WHERE sku = 'SM-001';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.8" Dynamic AMOLED 2X',
    'Resolução', '3120 x 1440 pixels (120Hz)',
    'Processador', 'Snapdragon 8 Gen 3',
    'RAM', '12GB LPDDR5X',
    'Armazenamento', '512GB UFS 4.0',
    'Câmara Principal', '200MP + 50MP + 12MP + 10MP',
    'Câmara Frontal', '12MP',
    'Bateria', '5000 mAh',
    'Sistema Operativo', 'Android 14 / One UI 6',
    '5G', 'Sim',
    'S Pen', 'Incluída',
    'Resistência', 'IP68',
    'Carregamento', '45W Super Fast'
) WHERE sku = 'SM-002';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.7" LTPO OLED 120Hz',
    'Resolução', '2992 x 1344 pixels',
    'Processador', 'Google Tensor G3',
    'RAM', '12GB LPDDR5X',
    'Armazenamento', '256GB UFS 3.1',
    'Câmara Principal', '50MP + 48MP Tele + 48MP Ultra',
    'Câmara Frontal', '10.5MP',
    'Bateria', '5050 mAh',
    'Sistema Operativo', 'Android 14',
    '5G', 'Sim',
    'Magic Eraser', 'Sim',
    'Resistência', 'IP68',
    'Carregamento', '30W Rápido'
) WHERE sku = 'SM-003';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.1" Super Retina XDR',
    'Resolução', '2532 x 1170 pixels',
    'Processador', 'A16 Bionic',
    'RAM', '6GB',
    'Armazenamento', '128GB',
    'Câmara Principal', '12MP Dual (Wide + Ultra)',
    'Câmara Frontal', '12MP TrueDepth',
    'Bateria', '3279 mAh',
    'Sistema Operativo', 'iOS 17',
    '5G', 'Sim',
    'Face ID', 'Sim',
    'Resistência', 'IP68',
    'Ceramic Shield', 'Sim'
) WHERE sku = 'SM-004';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.1" Dynamic AMOLED 2X',
    'Resolução', '2340 x 1080 pixels (120Hz)',
    'Processador', 'Snapdragon 8 Gen 2',
    'RAM', '8GB',
    'Armazenamento', '256GB UFS 3.1',
    'Câmara Principal', '50MP + 12MP Ultra + 10MP Tele',
    'Câmara Frontal', '12MP',
    'Bateria', '3900 mAh',
    'Sistema Operativo', 'Android 13 / One UI 5',
    '5G', 'Sim',
    'Resistência', 'IP68',
    'Carregamento', '25W Fast'
) WHERE sku = 'SM-005';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.4" Super AMOLED',
    'Resolução', '2340 x 1080 pixels (120Hz)',
    'Processador', 'Exynos 1380',
    'RAM', '8GB',
    'Armazenamento', '128GB',
    'Câmara Principal', '50MP + 12MP Ultra + 5MP Macro',
    'Câmara Frontal', '32MP',
    'Bateria', '5000 mAh',
    'Sistema Operativo', 'Android 13 / One UI 5',
    '5G', 'Sim',
    'Resistência', 'IP67',
    'Carregamento', '25W Fast'
) WHERE sku = 'SM-006';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.73" AMOLED 120Hz',
    'Resolução', '3200 x 1440 pixels',
    'Processador', 'Snapdragon 8 Gen 2',
    'RAM', '12GB LPDDR5X',
    'Armazenamento', '256GB UFS 4.0',
    'Câmara Principal', '50MP + 50MP Tele + 50MP Ultra',
    'Câmara Frontal', '32MP',
    'Bateria', '4820 mAh',
    'Sistema Operativo', 'Android 13 / MIUI 14',
    '5G', 'Sim',
    'Resistência', 'IP68',
    'Carregamento', '120W HyperCharge'
) WHERE sku = 'SM-007';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.3" OLED 90Hz',
    'Resolução', '2400 x 1080 pixels',
    'Processador', 'Google Tensor G2',
    'RAM', '8GB',
    'Armazenamento', '128GB',
    'Câmara Principal', '50MP + 12MP Ultra',
    'Câmara Frontal', '10.8MP',
    'Bateria', '4355 mAh',
    'Sistema Operativo', 'Android 13',
    '5G', 'Sim',
    'Magic Eraser', 'Sim',
    'Resistência', 'IP68',
    'Carregamento', '20W'
) WHERE sku = 'SM-008';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.67" AMOLED 120Hz',
    'Resolução', '2712 x 1220 pixels',
    'Processador', 'MediaTek Dimensity 7200',
    'RAM', '8GB',
    'Armazenamento', '256GB',
    'Câmara Principal', '200MP + 8MP Ultra + 2MP Macro',
    'Câmara Frontal', '16MP',
    'Bateria', '5000 mAh',
    'Sistema Operativo', 'Android 13 / MIUI 14',
    '5G', 'Sim',
    'Resistência', 'IP54',
    'Carregamento', '67W Turbo'
) WHERE sku = 'SM-009';

-- =====================================================
-- LAPTOPS (7 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '13.6" Liquid Retina',
    'Resolução', '2560 x 1664 pixels',
    'Processador', 'Apple M2 (8-core CPU)',
    'RAM', '8GB Unified Memory',
    'Armazenamento', '256GB SSD',
    'GPU', '8-core GPU',
    'Bateria', 'Até 18 horas',
    'Peso', '1.24 kg',
    'Sistema Operativo', 'macOS Sonoma',
    'Portas', '2x Thunderbolt 4, MagSafe 3',
    'Câmara', '1080p FaceTime HD',
    'Cor', 'Meia-Noite'
) WHERE sku = 'LP-001';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '14.2" Liquid Retina XDR',
    'Resolução', '3024 x 1964 pixels (120Hz)',
    'Processador', 'Apple M3 Pro (12-core)',
    'RAM', '18GB Unified Memory',
    'Armazenamento', '512GB SSD',
    'GPU', '14-core GPU',
    'Bateria', 'Até 18 horas',
    'Peso', '1.55 kg',
    'Sistema Operativo', 'macOS Sonoma',
    'Portas', '3x Thunderbolt 4, HDMI, SD Card',
    'Câmara', '1080p FaceTime HD',
    'Cor', 'Cinzento Sideral'
) WHERE sku = 'LP-002';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '13.4" FHD+ InfinityEdge',
    'Resolução', '1920 x 1200 pixels',
    'Processador', 'Intel Core i7-1355U (10-core)',
    'RAM', '16GB LPDDR5',
    'Armazenamento', '512GB SSD NVMe',
    'GPU', 'Intel Iris Xe',
    'Bateria', 'Até 12 horas',
    'Peso', '1.17 kg',
    'Sistema Operativo', 'Windows 11 Pro',
    'Portas', '2x Thunderbolt 4',
    'Câmara', '720p HD',
    'Cor', 'Platinum Silver'
) WHERE sku = 'LP-003';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '14" WUXGA IPS',
    'Resolução', '1920 x 1200 pixels',
    'Processador', 'Intel Core i7-1365U (12-core)',
    'RAM', '16GB LPDDR5',
    'Armazenamento', '512GB SSD NVMe',
    'GPU', 'Intel Iris Xe',
    'Bateria', 'Até 16 horas',
    'Peso', '1.12 kg',
    'Sistema Operativo', 'Windows 11 Pro',
    'Portas', '2x Thunderbolt 4, 2x USB-A, HDMI',
    'Câmara', '1080p FHD + IR',
    'Cor', 'Black'
) WHERE sku = 'LP-004';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '15.6" FHD IPS',
    'Resolução', '1920 x 1080 pixels',
    'Processador', 'Intel Core i5-1235U',
    'RAM', '8GB DDR4',
    'Armazenamento', '512GB SSD',
    'GPU', 'Intel Iris Xe',
    'Bateria', 'Até 8 horas',
    'Peso', '1.75 kg',
    'Sistema Operativo', 'Windows 11 Home',
    'Portas', 'USB-C, USB-A, HDMI',
    'Câmara', '720p HD',
    'Cor', 'Natural Silver'
) WHERE sku = 'LP-005';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '14" 2.8K OLED 90Hz',
    'Resolução', '2880 x 1800 pixels',
    'Processador', 'Intel Core i5-13500H',
    'RAM', '16GB LPDDR5',
    'Armazenamento', '512GB SSD',
    'GPU', 'Intel Iris Xe',
    'Bateria', 'Até 10 horas',
    'Peso', '1.39 kg',
    'Sistema Operativo', 'Windows 11 Home',
    'Portas', 'USB-C, USB-A, HDMI, SD',
    'Câmara', '1080p FHD',
    'Cor', 'Ponder Blue'
) WHERE sku = 'LP-006';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '15.6" FHD IPS 144Hz',
    'Resolução', '1920 x 1080 pixels',
    'Processador', 'Intel Core i5-12450H',
    'RAM', '16GB DDR4',
    'Armazenamento', '512GB SSD NVMe',
    'GPU', 'NVIDIA RTX 4050 6GB',
    'Bateria', 'Até 6 horas',
    'Peso', '1.86 kg',
    'Sistema Operativo', 'Windows 11 Home',
    'Portas', 'USB-C, USB-A, HDMI, Ethernet',
    'Câmara', '720p HD',
    'Cor', 'Black'
) WHERE sku = 'LP-007';

-- =====================================================
-- TABLETS (6 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '11" Liquid Retina',
    'Resolução', '2360 x 1640 pixels',
    'Processador', 'Apple M2 (8-core)',
    'RAM', '8GB',
    'Armazenamento', '128GB',
    'Câmara Principal', '12MP Wide',
    'Câmara Frontal', '12MP Ultra Wide (landscape)',
    'Bateria', 'Até 10 horas',
    'Peso', '462g',
    'Sistema Operativo', 'iPadOS 17',
    'Conectividade', 'Wi-Fi 6E, Bluetooth 5.3',
    'Apple Pencil', 'Suporta Pencil (hover)'
) WHERE sku = 'TB-001';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '11" Liquid Retina',
    'Resolução', '2420 x 1668 pixels',
    'Processador', 'Apple M4 (9-core)',
    'RAM', '8GB',
    'Armazenamento', '256GB',
    'Câmara Principal', '12MP Wide + LiDAR',
    'Câmara Frontal', '12MP TrueDepth',
    'Bateria', 'Até 10 horas',
    'Peso', '444g',
    'Sistema Operativo', 'iPadOS 17',
    'Face ID', 'Sim',
    'ProMotion', '120Hz',
    'Thunderbolt', 'USB-C 4'
) WHERE sku = 'TB-002';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '14.6" Dynamic AMOLED 2X',
    'Resolução', '2960 x 1848 pixels (120Hz)',
    'Processador', 'Snapdragon 8 Gen 2',
    'RAM', '12GB',
    'Armazenamento', '512GB',
    'Câmara Principal', '13MP + 8MP Ultra',
    'Câmara Frontal', '12MP',
    'Bateria', '11200 mAh',
    'Peso', '732g',
    'Sistema Operativo', 'Android 13 / One UI 5',
    'S Pen', 'Incluída',
    '5G', 'Opcional',
    'Carregamento', '45W Super Fast'
) WHERE sku = 'TB-003';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '10.5" TFT LCD',
    'Resolução', '1920 x 1200 pixels',
    'Processador', 'Unisoc Tiger T618',
    'RAM', '4GB',
    'Armazenamento', '64GB (expansível)',
    'Câmara Principal', '8MP',
    'Câmara Frontal', '5MP',
    'Bateria', '7040 mAh',
    'Peso', '508g',
    'Sistema Operativo', 'Android 12 / One UI Core 4',
    'Conectividade', 'Wi-Fi 5, Bluetooth 5.0',
    'Carregamento', '15W'
) WHERE sku = 'TB-004';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '10.9" Liquid Retina',
    'Resolução', '2360 x 1640 pixels',
    'Processador', 'Apple A14 Bionic',
    'RAM', '4GB',
    'Armazenamento', '64GB',
    'Câmara Principal', '12MP Wide',
    'Câmara Frontal', '12MP Ultra Wide (landscape)',
    'Bateria', 'Até 10 horas',
    'Peso', '477g',
    'Sistema Operativo', 'iPadOS 17',
    'Touch ID', 'Sim (botão superior)',
    'Apple Pencil', 'Suporta 1ª geração',
    'USB-C', 'Sim'
) WHERE sku = 'TB-005';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '11" IPS LCD',
    'Resolução', '2880 x 1800 pixels (144Hz)',
    'Processador', 'Snapdragon 870',
    'RAM', '8GB',
    'Armazenamento', '128GB (expansível)',
    'Câmara Principal', '13MP',
    'Câmara Frontal', '8MP',
    'Bateria', '8840 mAh',
    'Peso', '490g',
    'Sistema Operativo', 'Android 13 / MIUI Pad 14',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.2',
    'Dolby Vision', 'Sim',
    'Carregamento', '33W'
) WHERE sku = 'TB-006';

-- =====================================================
-- WEARABLES (6 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.9" Always-On Retina LTPO',
    'Resolução', '484 x 396 pixels',
    'Processador', 'S9 SiP (64-bit dual-core)',
    'Resistência', 'WR50 + IP6X',
    'Sensores', 'ECG, SpO2, Temperatura, Acidente',
    'Bateria', 'Até 18 horas',
    'GPS', 'Dupla frequência (L1 + L5)',
    'Conectividade', 'Bluetooth 5.3, Wi-Fi',
    'Sistema Operativo', 'watchOS 10',
    'Materiais', 'Alumínio 100% reciclado',
    'Bracelets', 'Compatível com todas',
    'Siri', 'On-device'
) WHERE sku = 'WR-001';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.7" Always-On Retina LTPO',
    'Resolução', '430 x 352 pixels',
    'Processador', 'S9 SiP',
    'Resistência', 'WR50',
    'Sensores', 'Frequência cardíaca, Acelerómetro',
    'Bateria', 'Até 18 horas',
    'GPS', 'Opcional (modelo GPS+Cellular)',
    'Conectividade', 'Bluetooth 5.3, Wi-Fi',
    'Sistema Operativo', 'watchOS 10',
    'Materiais', 'Alumínio',
    'Cores', '3 opções',
    'Rastreio Atividade', 'Sim'
) WHERE sku = 'WR-002';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.5" Super AMOLED Always-On',
    'Resolução', '480 x 480 pixels',
    'Processador', 'Exynos W930 (5nm)',
    'Resistência', '5ATM + IP68 + MIL-STD-810H',
    'Sensores', 'BIA, ECG, PPG, Temperatura',
    'Bateria', 'Até 40 horas',
    'GPS', 'L1+L5 dual-band',
    'Conectividade', 'Bluetooth 5.3, Wi-Fi, NFC',
    'Sistema Operativo', 'Wear OS 4 + One UI Watch 5',
    'Materiais', 'Aço Inoxidável',
    'Bisel Rotativo', 'Sim (físico)',
    'Sapphire Crystal', 'Sim'
) WHERE sku = 'WR-003';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.4" AMOLED touchscreen',
    'Resolução', '454 x 454 pixels',
    'Processador', 'Proprietário Garmin',
    'Resistência', '10ATM',
    'Sensores', 'HR, SpO2, Altímetro, Bússola',
    'Bateria', 'Até 13 dias (smartwatch)',
    'GPS', 'Multi-GNSS (GPS, GLONASS, Galileo)',
    'Conectividade', 'Bluetooth, ANT+, Wi-Fi',
    'Sistema Operativo', 'Garmin OS',
    'Materiais', 'Fibra de carbono reforçada',
    'Mapas', 'TopoActive Europa',
    'Treino', '60+ perfis desportivos'
) WHERE sku = 'WR-004';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.9" Always-On Retina LTPO',
    'Resolução', '502 x 410 pixels',
    'Processador', 'S9 SiP (64-bit dual-core)',
    'Resistência', 'WR100 + EN13319 (mergulho)',
    'Sensores', 'ECG, SpO2, Temp., Profundidade',
    'Bateria', 'Até 36 horas (Low Power 72h)',
    'GPS', 'Dupla frequência + precisão',
    'Conectividade', 'Bluetooth 5.3, Wi-Fi, Cellular',
    'Sistema Operativo', 'watchOS 10',
    'Materiais', 'Titânio aeroespacial',
    'Action Button', 'Personalizável',
    'Sirene', '86 dB para emergências'
) WHERE sku = 'WR-005';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.62" AMOLED Always-On',
    'Resolução', '490 x 192 pixels',
    'Processador', 'Proprietário Xiaomi',
    'Resistência', '5ATM',
    'Sensores', 'HR, SpO2, Sono avançado',
    'Bateria', 'Até 16 dias',
    'GPS', 'Não (usa smartphone)',
    'Conectividade', 'Bluetooth 5.1',
    'Sistema Operativo', 'Proprietário Xiaomi',
    'Materiais', 'Liga de alumínio',
    'Peso', '27g (sem bracelete)',
    'Desportos', '150+ modos'
) WHERE sku = 'WR-006';

-- =====================================================
-- TVs (5 produtos - continuação nos próximos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tamanho', '55 polegadas',
    'Tecnologia', 'QD-OLED 4K',
    'Resolução', '3840 x 2160 pixels',
    'Taxa Atualização', '120Hz nativo',
    'HDR', 'Dolby Vision IQ, HDR10+, HLG',
    'Processador', 'Neural Quantum 4K',
    'Smart TV', 'Tizen OS',
    'Som', 'Dolby Atmos, Object Tracking Sound+',
    'Portas HDMI', '4x HDMI 2.1 (eARC, VRR, ALLM)',
    'Gaming', 'Game Motion Plus, FreeSync Premium Pro',
    'Assistente', 'Bixby, Alexa, Google Assistant',
    'Conectividade', 'Wi-Fi 6E, Bluetooth 5.2'
) WHERE marca = 'Samsung' AND modelo LIKE '%55%' AND modelo LIKE '%OLED%' AND categoria = 'TVs' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tamanho', '65 polegadas',
    'Tecnologia', 'Neo QLED 4K',
    'Resolução', '3840 x 2160 pixels',
    'Taxa Atualização', '120Hz',
    'HDR', 'HDR10+, HLG',
    'Processador', 'Neo Quantum 4K',
    'Quantum Dot', 'Sim (100% volume de cor)',
    'Smart TV', 'Tizen OS',
    'Som', 'Dolby Atmos, Q-Symphony',
    'Portas HDMI', '4x HDMI 2.1',
    'Gaming', 'Motion Xcelerator Turbo+',
    'Mini LED', 'Quantum Matrix Technology'
) WHERE marca = 'Samsung' AND modelo LIKE '%65%' AND modelo LIKE '%QLED%' AND categoria = 'TVs' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tamanho', '55 polegadas',
    'Tecnologia', 'OLED evo 4K',
    'Resolução', '3840 x 2160 pixels',
    'Taxa Atualização', '120Hz',
    'HDR', 'Dolby Vision IQ, HDR10, HLG',
    'Processador', 'α9 Gen6 AI 4K',
    'Smart TV', 'webOS 23',
    'Som', 'Dolby Atmos, AI Sound Pro',
    'Portas HDMI', '4x HDMI 2.1 (eARC, VRR, ALLM)',
    'Gaming', 'NVIDIA G-Sync, AMD FreeSync',
    'Gallery Mode', 'Sim',
    'ThinQ AI', 'Sim'
) WHERE marca = 'LG' AND modelo LIKE '%OLED%' AND categoria = 'TVs' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tamanho', '50 polegadas',
    'Tecnologia', 'NanoCell 4K',
    'Resolução', '3840 x 2160 pixels',
    'Taxa Atualização', '60Hz',
    'HDR', 'HDR10, HLG',
    'Processador', 'α5 Gen6 AI',
    'Smart TV', 'webOS 23',
    'Som', 'Virtual Surround 5.1',
    'Portas HDMI', '3x HDMI 2.0',
    'Gaming', 'Game Optimizer',
    'NanoCell', 'Pureza de cores avançada',
    'Magic Remote', 'Incluído'
) WHERE marca = 'LG' AND modelo LIKE '%NanoCell%' AND categoria = 'TVs' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tamanho', '55 polegadas',
    'Tecnologia', 'OLED 4K',
    'Resolução', '3840 x 2160 pixels',
    'Taxa Atualização', '120Hz',
    'HDR', 'Dolby Vision, HDR10, HLG',
    'Processador', 'Cognitive Processor XR',
    'XR Technology', 'XR OLED Contrast Pro',
    'Smart TV', 'Google TV',
    'Som', 'Acoustic Surface Audio+',
    'Portas HDMI', '4x HDMI 2.1 (eARC, VRR, ALLM)',
    'Gaming', 'Perfect for PS5',
    'Assistente', 'Google Assistant, Alexa'
) WHERE marca = 'Sony' AND modelo LIKE '%Bravia%' AND categoria = 'TVs' LIMIT 1;

-- Continuação no próximo bloco (Audio, Consolas, Eletrodomésticos)

SELECT '✅ Especificações adicionadas aos primeiros 43 produtos!' AS status;
