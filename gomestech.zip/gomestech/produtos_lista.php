<?php
// Lista simples dos produtos usados no site
// Fonte: BD (tabela produtos). Requer BD importada.

session_start();
require_once __DIR__ . '/config.php';

$mysqli = db_connect();
$produtos = get_all_produtos($mysqli);
$mysqli->close();

header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Lista de Produtos - GomesTech</title>
  <link rel="stylesheet" href="css/gomestech.css">
  <style>
    .wrap { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
    table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 12px; overflow: hidden; border: 2px solid #f0f0f0; }
    th, td { padding: 12px 14px; border-bottom: 1px solid #f0f0f0; text-align: left; }
    th { background: #fafafa; font-weight: 800; }
    .muted { color: #666; }
    .badge { display:inline-block; padding: 4px 10px; border-radius: 999px; border: 1px solid #eee; font-size: 12px; font-weight: 700; }
  </style>
</head>
<body>
  <?php include __DIR__ . '/includes/header.php'; ?>

  <div class="wrap">
    <h1 style="margin: 0 0 10px 0;">Produtos usados no site</h1>
    <p class="muted" style="margin: 0 0 20px 0;">Total: <strong><?php echo count($produtos); ?></strong></p>

    <?php if (!count($produtos)): ?>
      <p>Sem produtos encontrados. Confirma se importaste a base de dados em <code>database/GOMESTECH.sql</code>.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Produto</th>
            <th>Categoria</th>
            <th>Preço</th>
            <th>Stock</th>
            <th>Specs</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($produtos as $p): ?>
            <tr>
              <td><?php echo htmlspecialchars($p['id']); ?></td>
              <td>
                <strong><?php echo htmlspecialchars(($p['marca'] ?? '') . ' ' . ($p['modelo'] ?? '')); ?></strong><br>
                <span class="muted"><?php echo htmlspecialchars($p['slug'] ?? ''); ?></span>
              </td>
              <td><?php echo htmlspecialchars($p['categoria'] ?? ''); ?></td>
              <td>€<?php echo number_format((float)($p['preco'] ?? 0), 2, ',', '.'); ?></td>
              <td><?php echo (int)($p['stock'] ?? 0); ?></td>
              <td>
                <?php if (!empty($p['especificacoes'])): ?>
                  <span class="badge">Com</span>
                <?php else: ?>
                  <span class="badge">Sem</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</body>
</html>
