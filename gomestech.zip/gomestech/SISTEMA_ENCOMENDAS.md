# Sistema de Encomendas - GomesTech

## ✅ Sistema Completo Implementado

### 📋 Fluxo de Encomenda

1. **Carrinho** → `carrinho.php`
   - Visualização dos produtos
   - Ajuste de quantidades
   - Cálculo automático de totais
   - Botão "Finalizar Compra"

2. **Checkout** → `checkout.php`
   - Formulário completo de dados:
     * Nome, Email, Telefone
     * NIF (9 dígitos)
     * Morada (rua, número, andar)
     * Código Postal (formato: 1000-100)
     * Cidade
   - Seleção de método de pagamento:
     * Multibanco
     * MB WAY
     * Cartão de Crédito
     * PayPal
   - Resumo da encomenda com cálculo de envio

3. **Processamento** → Backend do `checkout.php`
   - Geração de número de encomenda: `GT + YYYYMMDD + 4 dígitos aleatórios`
     * Exemplo: GT202511271234
   - Transação de base de dados:
     * Inserção na tabela `encomendas`
     * Inserção dos itens na tabela `encomenda_itens`
     * Redução automática do stock
   - Validação de stock disponível
   - Limpeza do carrinho após sucesso

4. **Confirmação** → `encomenda-confirmacao.php`
   - Página de sucesso com animações
   - Detalhes do pagamento por método:
     * **Multibanco**: Entidade + Referência + Valor (válido 3 dias)
     * **MB WAY**: Notificação de pedido enviado (5 minutos para confirmar)
     * **Cartão**: Confirmação de pagamento processado
     * **PayPal**: ID de transação simulado
   - Lista completa de itens encomendados
   - Resumo financeiro (subtotal, envio, desconto, total)
   - Dados de entrega completos
   - Prazo de entrega: 2-5 dias úteis
   - Botões de ação (Voltar à Loja, Ver Encomendas)

### 🔒 Segurança Implementada

- Verificação de sessão ativa (`$_SESSION['user_id']`)
- Validação de propriedade da encomenda (user_id match)
- Prepared statements para todas as queries
- Transações com rollback em caso de erro
- Validação de stock antes da compra
- Sanitização de dados de saída (`htmlspecialchars()`)

### 💳 Métodos de Pagamento

#### Multibanco
- Geração de referência simulada (9 dígitos)
- Entidade: 12345
- Validade: 3 dias
- Atualização automática após pagamento

#### MB WAY
- Envio de pedido para telemóvel
- Tempo limite: 5 minutos
- Confirmação instantânea

#### Cartão de Crédito
- Processamento imediato
- Confirmação instantânea
- Email de confirmação

#### PayPal
- Redirecionamento simulado
- ID de transação: PP-[hash 12 caracteres]
- Confirmação instantânea

### 📊 Base de Dados

#### Tabela: `encomendas`
```sql
- id (PK)
- numero_encomenda (VARCHAR 20, UNIQUE)
- user_id (FK → users.id)
- nome, email, telefone
- nif (VARCHAR 9)
- morada, codigo_postal, cidade
- metodo_pagamento
- subtotal, custo_envio, desconto, total
- status (Pendente, Pago, Enviado, Entregue, Cancelado)
- data_encomenda (TIMESTAMP)
```

#### Tabela: `encomenda_itens`
```sql
- id (PK)
- encomenda_id (FK → encomendas.id)
- produto_id (FK → produtos.id)
- quantidade
- preco_unitario
```

### 🎨 Design e UX

- Layout responsivo (desktop + mobile)
- Animações de entrada suaves
- Ícones informativos
- Cores diferenciadas por status/ação
- Feedback visual claro
- Alertas informativos destacados
- Formatação de preços em português (1.234,56 €)

### ⚙️ Funcionalidades Técnicas

- **Cálculo de Envio**:
  * Grátis para compras ≥ 50 €
  * 4,99 € para compras < 50 €

- **Gestão de Stock**:
  * Verificação antes da compra
  * Redução automática após confirmação
  * Validação: `stock >= quantidade`

- **Geração de Números**:
  * Formato: GT + AAAAMMDD + XXXX
  * Único por encomenda
  * Rastreável

- **Limpeza de Carrinho**:
  * Automática após encomenda bem-sucedida
  * Mantém dados em caso de erro

### 📧 Notificações (Simuladas)

- Email de confirmação de encomenda
- Email com dados de pagamento (Multibanco)
- Email de confirmação de pagamento
- Email de envio (com tracking)
- Email de entrega

### 🔄 Estados da Encomenda

1. **Pendente** - Aguarda pagamento
2. **Pago** - Pagamento confirmado
3. **Enviado** - Em trânsito
4. **Entregue** - Recebido pelo cliente
5. **Cancelado** - Cancelado pelo cliente/sistema

### 📝 Próximas Melhorias Sugeridas

- [ ] Página de rastreamento de encomenda
- [ ] Histórico de encomendas na conta do utilizador
- [ ] Sistema de notificações por email real
- [ ] Integração com API de tracking dos CTT
- [ ] Geração de faturas em PDF
- [ ] Sistema de devoluções
- [ ] Avaliações de produtos pós-compra
- [ ] Programa de pontos de fidelidade

---

**Status**: ✅ Sistema totalmente funcional e pronto para simulação realista de e-commerce
**Data**: Novembro 2024
**Versão**: 1.0
