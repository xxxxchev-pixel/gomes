-- =============================================================================
-- GOMESTECH - BASE DE DADOS FINAL CONSOLIDADA
-- Tudo integrado: estrutura, dados, stored procedures, triggers e funções
-- Data: 26 Novembro 2025
-- =============================================================================

SET FOREIGN_KEY_CHECKS=0;
SET time_zone = "+00:00";
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- =============================================================================
-- CRIAR BASE DE DADOS
-- =============================================================================

DROP DATABASE IF EXISTS `gomestech`;
CREATE DATABASE `gomestech` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `gomestech`;

-- =============================================================================
-- TABELA: users
-- =============================================================================

CREATE TABLE `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `telefone` VARCHAR(20) DEFAULT NULL,
  `nif` VARCHAR(9) DEFAULT NULL,
  `morada` TEXT DEFAULT NULL,
  `codigo_postal` VARCHAR(8) DEFAULT NULL,
  `is_admin` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `nif` (`nif`),
  KEY `idx_email` (`email`),
  KEY `idx_nif` (`nif`),
  KEY `idx_admin` (`is_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin padrão (password: admin123)
INSERT INTO `users` (`id`, `nome`, `email`, `password`, `nif`, `is_admin`) VALUES
(1, 'Administrador', 'admin@gomestech.pt', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '123456789', 1);

-- =============================================================================
-- TABELA: categories
-- =============================================================================

CREATE TABLE `categories` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `icon` VARCHAR(50) DEFAULT NULL,
  `display_order` INT(11) DEFAULT 0,
  `active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_active` (`active`),
  KEY `idx_display_order` (`display_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inserir categorias
INSERT INTO `categories` (`name`, `slug`, `icon`, `display_order`, `active`) VALUES
('Smartphones', 'smartphones', '📱', 1, 1),
('Laptops', 'laptops', '💻', 2, 1),
('Tablets', 'tablets', '📱', 3, 1),
('Wearables', 'wearables', '⌚', 4, 1),
('TVs', 'tvs', '📺', 5, 1),
('Audio', 'audio', '🎧', 6, 1),
('Consolas', 'consolas', '🎮', 7, 1),
('Frigoríficos', 'frigorificos', '🧊', 8, 1),
('Máquinas de Lavar', 'maquinas-lavar', '🌀', 9, 1),
('Micro-ondas', 'micro-ondas', '📦', 10, 1),
('Aspiradores', 'aspiradores', '🧹', 11, 1),
('Ar Condicionado', 'ar-condicionado', '❄️', 12, 1),
('Máquinas de Café', 'maquinas-cafe', '☕', 13, 1);

-- =============================================================================
-- TABELA: brands
-- =============================================================================

CREATE TABLE `brands` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL,
  `logo` VARCHAR(255) DEFAULT NULL,
  `display_order` INT(11) DEFAULT 0,
  `active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_active` (`active`),
  KEY `idx_display_order` (`display_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inserir marcas principais
INSERT INTO `brands` (`name`, `slug`, `active`) VALUES
('Apple', 'apple', 1),
('Samsung', 'samsung', 1),
('Google', 'google', 1),
('OnePlus', 'oneplus', 1),
('Xiaomi', 'xiaomi', 1),
('Dell', 'dell', 1),
('Lenovo', 'lenovo', 1),
('HP', 'hp', 1),
('ASUS', 'asus', 1),
('MSI', 'msi', 1),
('Sony', 'sony', 1),
('Microsoft', 'microsoft', 1),
('Nintendo', 'nintendo', 1),
('LG', 'lg', 1),
('Philips', 'philips', 1),
('Garmin', 'garmin', 1),
('Bose', 'bose', 1),
('JBL', 'jbl', 1),
('Sonos', 'sonos', 1),
('Bosch', 'bosch', 1),
('Dyson', 'dyson', 1),
('iRobot', 'irobot', 1),
('Panasonic', 'panasonic', 1),
('Daikin', 'daikin', 1),
('Mitsubishi', 'mitsubishi', 1),
('Fujitsu', 'fujitsu', 1),
('De''Longhi', 'delonghi', 1),
('Nespresso', 'nespresso', 1);

-- =============================================================================
-- TABELA: produtos
-- =============================================================================

CREATE TABLE `produtos` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `sku` VARCHAR(50) DEFAULT NULL,
  `marca` VARCHAR(100) NOT NULL,
  `modelo` VARCHAR(255) NOT NULL,
    `descricao` TEXT DEFAULT NULL,
  `slug` VARCHAR(250) DEFAULT NULL,
  `categoria` VARCHAR(100) NOT NULL,
  `preco` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `preco_original` DECIMAL(10,2) DEFAULT NULL,
    `desconto_promocao` INT(11) DEFAULT 0,
  `stock` INT(11) DEFAULT 100,
  `imagem` VARCHAR(500) DEFAULT NULL,
  `especificacoes` JSON DEFAULT NULL,
  `loja` VARCHAR(100) DEFAULT 'GomesTech',
  `ativo` TINYINT(1) DEFAULT 1,
  `destaque` TINYINT(1) DEFAULT 0,
  `novidade` TINYINT(1) DEFAULT 0,
  `produto_dia` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `sku` (`sku`),
  KEY `idx_slug` (`slug`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_marca` (`marca`),
  KEY `idx_ativo` (`ativo`),
  KEY `idx_preco` (`preco`),
  KEY `idx_destaque` (`destaque`),
  KEY `idx_novidade` (`novidade`),
  KEY `idx_produto_dia` (`produto_dia`),
  KEY `idx_categoria_ativo` (`categoria`, `ativo`),
  KEY `idx_marca_categoria` (`marca`, `categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- TABELA: orders (Encomendas)
-- =============================================================================

CREATE TABLE `orders` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `order_number` VARCHAR(50) NOT NULL,
  `status` ENUM('pendente', 'processando', 'enviada', 'entregue', 'cancelada') DEFAULT 'pendente',
  `total` DECIMAL(10,2) NOT NULL,
  `shipping_address` TEXT NOT NULL,
  `billing_nif` VARCHAR(9) DEFAULT NULL,
  `payment_method` VARCHAR(50) DEFAULT 'Multibanco',
  `tracking_code` VARCHAR(100) DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_order_number` (`order_number`),
  CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- TABELA: order_items
-- =============================================================================

CREATE TABLE `order_items` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `order_id` INT(11) NOT NULL,
  `produto_id` INT(11) NOT NULL,
  `quantity` INT(11) NOT NULL DEFAULT 1,
  `price` DECIMAL(10,2) NOT NULL,
  `subtotal` DECIMAL(10,2) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_produto` (`produto_id`),
  CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_order_items_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- TABELA: wishlist (Favoritos)
-- =============================================================================

CREATE TABLE `wishlist` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `produto_id` INT(11) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_produto` (`user_id`, `produto_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_produto` (`produto_id`),
  CONSTRAINT `fk_wishlist_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wishlist_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- TABELA: comparisons (Comparações)
-- =============================================================================

CREATE TABLE `comparisons` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `session_id` VARCHAR(100) NOT NULL,
  `produto_id` INT(11) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_produto` (`produto_id`),
  CONSTRAINT `fk_comparisons_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- TABELA: carrinho (Carrinho de Compras)
-- =============================================================================

CREATE TABLE `carrinho` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `session_id` VARCHAR(100) NOT NULL,
  `user_id` INT(11) DEFAULT NULL,
  `produto_id` INT(11) NOT NULL,
  `quantity` INT(11) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_produto` (`produto_id`),
  CONSTRAINT `fk_carrinho_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_carrinho_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- TABELA: favoritos (Lista de Desejos)
-- =============================================================================

CREATE TABLE `favoritos` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `produto_id` INT(11) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_produto` (`user_id`, `produto_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_produto` (`produto_id`),
  CONSTRAINT `fk_favoritos_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_favoritos_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- TABELA: comparacao (Comparação de Produtos)
-- =============================================================================

CREATE TABLE `comparacao` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `session_id` VARCHAR(100) NOT NULL,
  `user_id` INT(11) DEFAULT NULL,
  `produto_id` INT(11) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_produto` (`produto_id`),
  CONSTRAINT `fk_comparacao_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_comparacao_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- TABELA: encomendas
-- =============================================================================

CREATE TABLE `encomendas` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `order_number` VARCHAR(50) NOT NULL,
  `status` ENUM('pendente', 'processando', 'enviada', 'entregue', 'cancelada') DEFAULT 'pendente',
  `total` DECIMAL(10,2) NOT NULL,
  `shipping_address` TEXT NOT NULL,
  `billing_nif` VARCHAR(9) DEFAULT NULL,
  `payment_method` VARCHAR(50) DEFAULT 'Multibanco',
    `modo_entrega` ENUM('standard', 'express') NOT NULL DEFAULT 'standard',
  `tracking_code` VARCHAR(100) DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_order_number` (`order_number`),
  KEY `idx_created` (`created_at` DESC),
  CONSTRAINT `fk_encomendas_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- TABELA: encomenda_itens (Itens das Encomendas Antigas)
-- =============================================================================

CREATE TABLE `encomenda_itens` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `encomenda_id` INT(11) NOT NULL,
  `produto_id` INT(11) NOT NULL,
  `quantity` INT(11) NOT NULL DEFAULT 1,
  `price` DECIMAL(10,2) NOT NULL,
    `subtotal` DECIMAL(10,2) GENERATED ALWAYS AS (ROUND(`price` * `quantity`, 2)) STORED,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_encomenda` (`encomenda_id`),
  KEY `idx_produto` (`produto_id`),
  CONSTRAINT `fk_encomenda_itens_encomenda` FOREIGN KEY (`encomenda_id`) REFERENCES `encomendas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_encomenda_itens_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- TABELA: promocoes (Promoções e Campanhas)
-- =============================================================================

CREATE TABLE `promocoes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
    `produto_id` INT(11) NOT NULL,
    `desconto` DECIMAL(5,2) NOT NULL,
  `data_inicio` DATE NOT NULL,
  `data_fim` DATE NOT NULL,
  `ativo` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ativo` (`ativo`),
  KEY `idx_datas` (`data_inicio`, `data_fim`),
  KEY `idx_produto` (`produto_id`),
    CONSTRAINT `fk_promocoes_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- PRODUTOS DE EXEMPLO (59 produtos de todas as categorias)
-- =============================================================================

INSERT INTO `produtos` (`sku`, `marca`, `modelo`, `categoria`, `preco`, `preco_original`, `stock`, `imagem`, `destaque`, `novidade`, `produto_dia`) VALUES
-- Smartphones (9 produtos)
('SM-001', 'Apple', 'iPhone 15 Pro 256GB', 'Smartphones', 1299.99, 1499.99, 50, 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=500', 1, 1, 0),
('SM-002', 'Samsung', 'Galaxy S24 Ultra 512GB', 'Smartphones', 1399.99, 1599.99, 45, 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500', 1, 1, 1),
('SM-003', 'Google', 'Pixel 8 Pro 256GB', 'Smartphones', 999.99, 1199.99, 30, 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=500', 1, 0, 0),
('SM-004', 'Apple', 'iPhone 14 128GB', 'Smartphones', 899.99, 1099.99, 60, 'https://images.unsplash.com/photo-1663499482523-1c0d96712eb4?w=500', 0, 0, 0),
('SM-005', 'Samsung', 'Galaxy S23 256GB', 'Smartphones', 849.99, 999.99, 55, 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500', 0, 0, 0),
('SM-006', 'Samsung', 'Galaxy A54 5G 128GB', 'Smartphones', 449.99, 549.99, 80, 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500', 0, 1, 0),
('SM-007', 'Xiaomi', '13 Pro 256GB', 'Smartphones', 899.99, 1099.99, 35, 'https://images.unsplash.com/photo-1592286927505-2fd3c4e5e3c4?w=500', 1, 0, 0),
('SM-008', 'Google', 'Pixel 7 128GB', 'Smartphones', 599.99, 799.99, 40, 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=500', 0, 0, 0),
('SM-009', 'Xiaomi', 'Redmi Note 13 Pro 256GB', 'Smartphones', 349.99, 449.99, 90, 'https://images.unsplash.com/photo-1592286927505-2fd3c4e5e3c4?w=500', 0, 1, 0),

-- Laptops (7 produtos)
('LP-001', 'Apple', 'MacBook Air M2 13"', 'Laptops', 1299.99, 1499.99, 30, 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500', 1, 1, 0),
('LP-002', 'Apple', 'MacBook Pro 14" M3 Pro', 'Laptops', 2299.99, 2699.99, 20, 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500', 1, 1, 0),
('LP-003', 'Dell', 'XPS 13 9315 i7', 'Laptops', 1399.99, 1699.99, 25, 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=500', 1, 0, 0),
('LP-004', 'Lenovo', 'ThinkPad X1 Carbon Gen 11', 'Laptops', 1799.99, 2099.99, 18, 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=500', 0, 0, 0),
('LP-005', 'HP', 'Pavilion 15 i5', 'Laptops', 799.99, 999.99, 40, 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500', 0, 0, 0),
('LP-006', 'ASUS', 'ZenBook 14 OLED', 'Laptops', 1199.99, 1499.99, 22, 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=500', 0, 1, 0),
('LP-007', 'MSI', 'GF63 Thin i5 RTX 4050', 'Laptops', 999.99, 1299.99, 15, 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=500', 1, 0, 0),

-- Tablets (6 produtos)
('TB-001', 'Apple', 'iPad Air M2 11" 128GB', 'Tablets', 699.99, 799.99, 35, 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=500', 1, 1, 0),
('TB-002', 'Apple', 'iPad Pro 11" M4 256GB', 'Tablets', 1099.99, 1299.99, 25, 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=500', 1, 1, 0),
('TB-003', 'Samsung', 'Galaxy Tab S9 Ultra 512GB', 'Tablets', 1199.99, 1399.99, 18, 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=500', 1, 0, 0),
('TB-004', 'Samsung', 'Galaxy Tab A8 64GB', 'Tablets', 249.99, 349.99, 50, 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=500', 0, 0, 0),
('TB-005', 'Apple', 'iPad 10.9" 64GB', 'Tablets', 449.99, 549.99, 40, 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=500', 0, 0, 0),
('TB-006', 'Xiaomi', 'Pad 6 128GB', 'Tablets', 349.99, 449.99, 30, 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=500', 0, 1, 0),

-- Wearables (6 produtos)
('WR-001', 'Apple', 'Apple Watch Series 9 45mm GPS', 'Wearables', 479.99, 549.99, 40, 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=500', 1, 1, 0),
('WR-002', 'Apple', 'Apple Watch SE 40mm GPS', 'Wearables', 299.99, 349.99, 50, 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=500', 0, 0, 0),
('WR-003', 'Samsung', 'Galaxy Watch 6 Classic 47mm', 'Wearables', 399.99, 479.99, 30, 'https://images.unsplash.com/photo-1617625802912-cde586faf331?w=500', 1, 0, 0),
('WR-004', 'Garmin', 'Forerunner 265', 'Wearables', 449.99, 549.99, 25, 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=500', 1, 0, 0),
('WR-005', 'Apple', 'Apple Watch Ultra 2', 'Wearables', 899.99, 999.99, 15, 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=500', 1, 1, 0),
('WR-006', 'Xiaomi', 'Watch S2 Pro', 'Wearables', 199.99, 279.99, 45, 'https://images.unsplash.com/photo-1617625802912-cde586faf331?w=500', 0, 1, 0),

-- TVs (5 produtos)
('TV-001', 'Samsung', 'Neo QLED 65" QN95C', 'TVs', 2499.99, 2999.99, 10, 'https://images.unsplash.com/photo-1593784991095-a205069470b6?w=500', 1, 1, 0),
('TV-002', 'LG', 'OLED 55" C3', 'TVs', 1899.99, 2299.99, 12, 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=500', 1, 1, 0),
('TV-003', 'Sony', 'OLED 65" A80L', 'TVs', 2199.99, 2699.99, 8, 'https://images.unsplash.com/photo-1593359863503-f598d27de6f?w=500', 1, 0, 0),
('TV-004', 'Samsung', 'QLED 55" Q60C', 'TVs', 799.99, 999.99, 25, 'https://images.unsplash.com/photo-1593784991095-a205069470b6?w=500', 0, 0, 0),
('TV-005', 'Philips', 'OLED 55" 808', 'TVs', 1599.99, 1999.99, 15, 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500', 0, 0, 0),

-- Audio (7 produtos)
('AU-001', 'Apple', 'AirPods Max', 'Audio', 579.99, 629.99, 30, 'https://images.unsplash.com/photo-1625644312452-6e8c6c8ed5b8?w=500', 1, 0, 0),
('AU-002', 'Bose', 'QuietComfort Ultra', 'Audio', 449.99, 499.99, 35, 'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=500', 1, 1, 0),
('AU-003', 'Apple', 'AirPods Pro 2ª Gen', 'Audio', 279.99, 299.99, 70, 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=500', 1, 1, 0),
('AU-004', 'Apple', 'AirPods 3ª Gen', 'Audio', 189.99, 219.99, 60, 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=500', 0, 0, 0),
('AU-005', 'Sony', 'WF-1000XM5', 'Audio', 299.99, 329.99, 40, 'https://images.unsplash.com/photo-1613040809024-b4ef7ba99bc3?w=500', 1, 1, 0),
('AU-006', 'JBL', 'Charge 5', 'Audio', 179.99, 219.99, 55, 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=500', 0, 0, 0),
('AU-007', 'Sonos', 'Era 300', 'Audio', 499.99, 599.99, 20, 'https://images.unsplash.com/photo-1545454675-3531b543be5d?w=500', 1, 1, 0),

-- Consolas (5 produtos)
('CN-001', 'Sony', 'PlayStation 5 Slim', 'Consolas', 549.99, 599.99, 25, 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=500', 1, 1, 1),
('CN-002', 'Sony', 'PlayStation 5 Digital', 'Consolas', 449.99, 499.99, 20, 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=500', 1, 0, 0),
('CN-003', 'Microsoft', 'Xbox Series X', 'Consolas', 499.99, 549.99, 18, 'https://images.unsplash.com/photo-1621259182978-fbf93132d53d?w=500', 1, 0, 0),
('CN-004', 'Microsoft', 'Xbox Series S', 'Consolas', 299.99, 349.99, 30, 'https://images.unsplash.com/photo-1621259182978-fbf93132d53d?w=500', 0, 0, 0),
('CN-005', 'Nintendo', 'Switch OLED', 'Consolas', 349.99, 399.99, 35, 'https://images.unsplash.com/photo-1578303512597-81e6cc155b3e?w=500', 1, 1, 0),

-- Frigoríficos (3 produtos)
('FR-001', 'Samsung', 'RB38A7B6DS9', 'Frigoríficos', 899.99, 1099.99, 12, 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=500', 1, 0, 0),
('FR-002', 'LG', 'GSX960NSVZ Side-by-Side', 'Frigoríficos', 1599.99, 1899.99, 8, 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=500', 1, 1, 0),
('FR-003', 'Bosch', 'KGN39VWEA Combinado', 'Frigoríficos', 749.99, 949.99, 15, 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=500', 0, 0, 0),

-- Máquinas de Lavar (3 produtos)
('ML-001', 'Samsung', 'WW90T4540AE 9kg', 'Máquinas de Lavar', 549.99, 699.99, 18, 'https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?w=500', 1, 0, 0),
('ML-002', 'LG', 'F4WV709P1 9kg', 'Máquinas de Lavar', 599.99, 749.99, 15, 'https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?w=500', 1, 1, 0),
('ML-003', 'Bosch', 'WAU28S80ES 8kg', 'Máquinas de Lavar', 649.99, 799.99, 12, 'https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?w=500', 0, 0, 0),

-- Micro-ondas (3 produtos)
('MO-001', 'Samsung', 'MS28J5255UB 28L', 'Micro-ondas', 179.99, 229.99, 25, 'https://images.unsplash.com/photo-1585515320310-259814833e62?w=500', 0, 0, 0),
('MO-002', 'LG', 'MS2043DB 20L', 'Micro-ondas', 129.99, 179.99, 30, 'https://images.unsplash.com/photo-1585515320310-259814833e62?w=500', 0, 0, 0),
('MO-003', 'Bosch', 'BFL524MS0 Encastre', 'Micro-ondas', 399.99, 499.99, 10, 'https://images.unsplash.com/photo-1585515320310-259814833e62?w=500', 1, 1, 0),

-- Aspiradores (3 produtos)
('AS-001', 'Dyson', 'V11 Absolute', 'Aspiradores', 599.99, 749.99, 15, 'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=500', 1, 0, 0),
('AS-002', 'iRobot', 'Roomba j7+', 'Aspiradores', 799.99, 999.99, 12, 'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=500', 1, 1, 0),
('AS-003', 'Xiaomi', 'Robot Vacuum S10+', 'Aspiradores', 449.99, 599.99, 20, 'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=500', 1, 1, 0),

-- Ar Condicionado (5 produtos)
('AC-001', 'Samsung', 'WindFree Elite 12000 BTU', 'Ar Condicionado', 899.99, 1199.99, 10, 'https://images.unsplash.com/photo-1631545804989-2ee93a881a97?w=500', 1, 1, 0),
('AC-002', 'LG', 'Artcool 9000 BTU Inverter', 'Ar Condicionado', 749.99, 999.99, 12, 'https://images.unsplash.com/photo-1631545804989-2ee93a881a97?w=500', 1, 0, 0),
('AC-003', 'Daikin', 'FTXM35R Perfera', 'Ar Condicionado', 1099.99, 1399.99, 8, 'https://images.unsplash.com/photo-1631545804989-2ee93a881a97?w=500', 1, 0, 0),
('AC-004', 'Mitsubishi', 'MSZ-LN35VGW', 'Ar Condicionado', 1199.99, 1499.99, 6, 'https://images.unsplash.com/photo-1631545804989-2ee93a881a97?w=500', 0, 0, 0),
('AC-005', 'Fujitsu', 'ASYG12KPCA', 'Ar Condicionado', 849.99, 1099.99, 10, 'https://images.unsplash.com/photo-1631545804989-2ee93a881a97?w=500', 0, 1, 0),

-- Máquinas de Café (4 produtos)
('MC-001', 'Nespresso', 'Essenza Mini', 'Máquinas de Café', 99.99, 129.99, 40, 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=500', 0, 0, 0),
('MC-002', 'Philips', 'LatteGo 5400', 'Máquinas de Café', 799.99, 999.99, 15, 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=500', 1, 1, 0),
('MC-003', 'De\'Longhi', 'Magnifica S ECAM22.110.B', 'Máquinas de Café', 449.99, 599.99, 18, 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=500', 1, 0, 0),
('MC-004', 'Nespresso', 'Vertuo Next', 'Máquinas de Café', 149.99, 199.99, 30, 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=500', 0, 1, 0);

-- =============================================================================
-- FUNÇÕES AUXILIARES
-- =============================================================================

DELIMITER //

-- Função para gerar slug a partir de texto
CREATE FUNCTION fn_slugify(texto VARCHAR(255)) 
RETURNS VARCHAR(255)
DETERMINISTIC
BEGIN
    DECLARE slug VARCHAR(255);
    SET slug = LOWER(TRIM(texto));
    
    -- Substituir caracteres especiais portugueses
    SET slug = REPLACE(slug, 'á', 'a');
    SET slug = REPLACE(slug, 'à', 'a');
    SET slug = REPLACE(slug, 'â', 'a');
    SET slug = REPLACE(slug, 'ã', 'a');
    SET slug = REPLACE(slug, 'é', 'e');
    SET slug = REPLACE(slug, 'ê', 'e');
    SET slug = REPLACE(slug, 'í', 'i');
    SET slug = REPLACE(slug, 'ó', 'o');
    SET slug = REPLACE(slug, 'ô', 'o');
    SET slug = REPLACE(slug, 'õ', 'o');
    SET slug = REPLACE(slug, 'ú', 'u');
    SET slug = REPLACE(slug, 'ç', 'c');
    
    -- Remover caracteres especiais e substituir espaços por hífens
    SET slug = REGEXP_REPLACE(slug, '[^a-z0-9]+', '-');
    SET slug = REGEXP_REPLACE(slug, '^-+|-+$', '');
    
    RETURN slug;
END//

-- Função para calcular desconto percentual
CREATE FUNCTION fn_calcular_desconto(preco_original DECIMAL(10,2), preco_atual DECIMAL(10,2))
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE desconto INT;
    
    IF preco_original IS NULL OR preco_original = 0 OR preco_atual >= preco_original THEN
        RETURN 0;
    END IF;
    
    SET desconto = ROUND(((preco_original - preco_atual) / preco_original) * 100);
    RETURN desconto;
END//

-- Função para verificar se produto está em promoção
CREATE FUNCTION fn_em_promocao(preco_original DECIMAL(10,2), preco_atual DECIMAL(10,2))
RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    IF preco_original IS NULL OR preco_original = 0 THEN
        RETURN FALSE;
    END IF;
    
    RETURN preco_atual < preco_original;
END//

DELIMITER ;

-- =============================================================================
-- TRIGGERS AUTOMÁTICOS
-- =============================================================================

DELIMITER //

-- Trigger para gerar slug automaticamente ao inserir produto
CREATE TRIGGER trg_produtos_before_insert
BEFORE INSERT ON produtos
FOR EACH ROW
BEGIN
    DECLARE base_slug VARCHAR(250);
    DECLARE final_slug VARCHAR(250);
    DECLARE slug_exists INT;
    DECLARE counter INT DEFAULT 1;
    
    -- Gerar slug base a partir do modelo
    SET base_slug = fn_slugify(NEW.modelo);
    SET final_slug = base_slug;
    
    -- Verificar se slug já existe e adicionar número se necessário
    SELECT COUNT(*) INTO slug_exists FROM produtos WHERE slug = final_slug;
    
    WHILE slug_exists > 0 DO
        SET final_slug = CONCAT(base_slug, '-', counter);
        SELECT COUNT(*) INTO slug_exists FROM produtos WHERE slug = final_slug;
        SET counter = counter + 1;
    END WHILE;
    
    SET NEW.slug = final_slug;
    
    -- Gerar SKU automaticamente se não fornecido
    IF NEW.sku IS NULL OR NEW.sku = '' THEN
        SET NEW.sku = CONCAT(
            UPPER(SUBSTRING(NEW.categoria, 1, 2)),
            '-',
            LPAD(FLOOR(1000 + (RAND() * 8999)), 4, '0')
        );
    END IF;
END//

-- Trigger para atualizar slug ao alterar modelo
CREATE TRIGGER trg_produtos_before_update
BEFORE UPDATE ON produtos
FOR EACH ROW
BEGIN
    IF NEW.modelo != OLD.modelo THEN
        DECLARE base_slug VARCHAR(250);
        DECLARE final_slug VARCHAR(250);
        DECLARE slug_exists INT;
        DECLARE counter INT DEFAULT 1;
        
        SET base_slug = fn_slugify(NEW.modelo);
        SET final_slug = base_slug;
        
        SELECT COUNT(*) INTO slug_exists FROM produtos WHERE slug = final_slug AND id != NEW.id;
        
        WHILE slug_exists > 0 DO
            SET final_slug = CONCAT(base_slug, '-', counter);
            SELECT COUNT(*) INTO slug_exists FROM produtos WHERE slug = final_slug AND id != NEW.id;
            SET counter = counter + 1;
        END WHILE;
        
        SET NEW.slug = final_slug;
    END IF;
END//

-- Nota: stock é reduzido apenas quando a encomenda passa para 'entregue' (lógica do PHP).
-- O subtotal em `encomenda_itens` é calculado via coluna gerada.

DELIMITER ;

-- =============================================================================
-- STORED PROCEDURES
-- =============================================================================

DELIMITER //

-- Procedure para gerar slugs para todos os produtos sem slug
CREATE PROCEDURE sp_gerar_todos_slugs()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE produto_id INT;
    DECLARE produto_modelo VARCHAR(255);
    
    DECLARE cur CURSOR FOR 
        SELECT id, modelo FROM produtos WHERE slug IS NULL OR slug = '';
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO produto_id, produto_modelo;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        UPDATE produtos 
        SET slug = fn_slugify(produto_modelo) 
        WHERE id = produto_id;
    END LOOP;
    
    CLOSE cur;
    
    SELECT CONCAT('Slugs gerados para ', ROW_COUNT(), ' produtos') AS resultado;
END//

-- Procedure para aplicar desconto global por categoria
CREATE PROCEDURE sp_aplicar_desconto_categoria(
    IN p_categoria VARCHAR(100),
    IN p_percentagem DECIMAL(5,2)
)
BEGIN
    UPDATE produtos
    SET preco_original = IF(preco_original IS NULL, preco, preco_original),
        preco = ROUND(preco * (1 - p_percentagem / 100), 2)
    WHERE categoria = p_categoria AND ativo = 1;
    
    SELECT CONCAT('Desconto de ', p_percentagem, '% aplicado a ', ROW_COUNT(), ' produtos da categoria ', p_categoria) AS resultado;
END//

-- Procedure para remover descontos de uma categoria
CREATE PROCEDURE sp_remover_desconto_categoria(
    IN p_categoria VARCHAR(100)
)
BEGIN
    UPDATE produtos
    SET preco = preco_original,
        preco_original = NULL
    WHERE categoria = p_categoria AND preco_original IS NOT NULL;
    
    SELECT CONCAT('Descontos removidos de ', ROW_COUNT(), ' produtos da categoria ', p_categoria) AS resultado;
END//

-- Procedure para marcar produtos em destaque
CREATE PROCEDURE sp_marcar_destaques(
    IN p_limite INT
)
BEGIN
    -- Resetar todos os destaques
    UPDATE produtos SET destaque = 0;
    
    -- Marcar os mais vendidos/caros como destaque
    UPDATE produtos
    SET destaque = 1
    WHERE ativo = 1
    ORDER BY preco DESC
    LIMIT p_limite;
    
    SELECT CONCAT(p_limite, ' produtos marcados como destaque') AS resultado;
END//

-- Procedure para atualizar stock em lote
CREATE PROCEDURE sp_atualizar_stock_lote(
    IN p_categoria VARCHAR(100),
    IN p_quantidade INT
)
BEGIN
    UPDATE produtos
    SET stock = stock + p_quantidade
    WHERE categoria = p_categoria AND ativo = 1;
    
    SELECT CONCAT('Stock atualizado para ', ROW_COUNT(), ' produtos da categoria ', p_categoria) AS resultado;
END//

-- Procedure para relatório de vendas (preparado para futuro)
CREATE PROCEDURE sp_relatorio_vendas(
    IN p_data_inicio DATE,
    IN p_data_fim DATE
)
BEGIN
    SELECT 
        p.categoria,
        p.marca,
        COUNT(DISTINCT e.id) AS total_encomendas,
        SUM(ei.quantity) AS total_unidades,
        SUM(ei.subtotal) AS total_vendas
    FROM encomendas e
    INNER JOIN encomenda_itens ei ON e.id = ei.encomenda_id
    INNER JOIN produtos p ON ei.produto_id = p.id
    WHERE e.created_at BETWEEN p_data_inicio AND p_data_fim
        AND e.status != 'cancelada'
    GROUP BY p.categoria, p.marca
    ORDER BY total_vendas DESC;
END//

-- Procedure para obter top produtos
CREATE PROCEDURE sp_top_produtos(
    IN p_limite INT,
    IN p_tipo VARCHAR(20)
)
BEGIN
    IF p_tipo = 'preco' THEN
        SELECT id, marca, modelo, categoria, preco, stock
        FROM produtos
        WHERE ativo = 1
        ORDER BY preco DESC
        LIMIT p_limite;
        
    ELSEIF p_tipo = 'novidade' THEN
        SELECT id, marca, modelo, categoria, preco, stock
        FROM produtos
        WHERE ativo = 1 AND novidade = 1
        ORDER BY created_at DESC
        LIMIT p_limite;
        
    ELSEIF p_tipo = 'destaque' THEN
        SELECT id, marca, modelo, categoria, preco, stock
        FROM produtos
        WHERE ativo = 1 AND destaque = 1
        ORDER BY preco DESC
        LIMIT p_limite;
        
    ELSE
        SELECT id, marca, modelo, categoria, preco, stock
        FROM produtos
        WHERE ativo = 1
        ORDER BY RAND()
        LIMIT p_limite;
    END IF;
END//

-- Procedure para diagnóstico da base de dados
CREATE PROCEDURE sp_diagnostico()
BEGIN
    SELECT 'Total de Produtos' AS metrica, COUNT(*) AS valor FROM produtos
    UNION ALL
    SELECT 'Produtos Ativos', COUNT(*) FROM produtos WHERE ativo = 1
    UNION ALL
    SELECT 'Produtos em Destaque', COUNT(*) FROM produtos WHERE destaque = 1
    UNION ALL
    SELECT 'Produtos Novidade', COUNT(*) FROM produtos WHERE novidade = 1
    UNION ALL
    SELECT 'Produtos com Desconto', COUNT(*) FROM produtos WHERE preco_original IS NOT NULL AND preco < preco_original
    UNION ALL
    SELECT 'Total de Utilizadores', COUNT(*) FROM users
    UNION ALL
    SELECT 'Administradores', COUNT(*) FROM users WHERE is_admin = 1
    UNION ALL
    SELECT 'Total de Encomendas', COUNT(*) FROM encomendas
    UNION ALL
    SELECT 'Categorias Únicas', COUNT(DISTINCT categoria) FROM produtos
    UNION ALL
    SELECT 'Marcas Únicas', COUNT(DISTINCT marca) FROM produtos;
END//

DELIMITER ;

-- =============================================================================
-- VIEWS ÚTEIS
-- =============================================================================

-- View para produtos com desconto
CREATE OR REPLACE VIEW vw_produtos_desconto AS
SELECT 
    id,
    sku,
    marca,
    modelo,
    categoria,
    preco,
    preco_original,
    fn_calcular_desconto(preco_original, preco) AS desconto_percentual,
    stock,
    imagem,
    slug
FROM produtos
WHERE preco_original IS NOT NULL 
    AND preco < preco_original 
    AND ativo = 1
ORDER BY fn_calcular_desconto(preco_original, preco) DESC;

-- View para produtos em destaque
CREATE OR REPLACE VIEW vw_produtos_destaque AS
SELECT 
    id,
    sku,
    marca,
    modelo,
    categoria,
    preco,
    preco_original,
    fn_calcular_desconto(preco_original, preco) AS desconto_percentual,
    stock,
    imagem,
    slug,
    destaque,
    novidade,
    produto_dia
FROM produtos
WHERE ativo = 1 
    AND (destaque = 1 OR novidade = 1 OR produto_dia = 1)
ORDER BY produto_dia DESC, destaque DESC, novidade DESC, preco DESC;

-- View para estatísticas por categoria
CREATE OR REPLACE VIEW vw_stats_categoria AS
SELECT 
    categoria,
    COUNT(*) AS total_produtos,
    COUNT(DISTINCT marca) AS total_marcas,
    ROUND(AVG(preco), 2) AS preco_medio,
    MIN(preco) AS preco_minimo,
    MAX(preco) AS preco_maximo,
    SUM(stock) AS stock_total
FROM produtos
WHERE ativo = 1
GROUP BY categoria
ORDER BY total_produtos DESC;

-- =============================================================================
-- ÍNDICES ADICIONAIS PARA PERFORMANCE
-- =============================================================================

CREATE INDEX idx_produtos_specs ON produtos((CAST(especificacoes AS CHAR(255))));
CREATE INDEX idx_produtos_created ON produtos(created_at DESC);
CREATE INDEX idx_produtos_updated ON produtos(updated_at DESC);
CREATE INDEX idx_users_created ON users(created_at DESC);
CREATE INDEX idx_encomendas_created ON encomendas(created_at DESC);
CREATE INDEX idx_encomendas_user_status ON encomendas(user_id, status);

-- =============================================================================
-- EXECUTAR PROCEDURES INICIAIS
-- =============================================================================

-- Gerar slugs para todos os produtos
CALL sp_gerar_todos_slugs();

-- Marcar 12 produtos como destaque
CALL sp_marcar_destaques(12);

-- =============================================================================
-- VERIFICAÇÃO FINAL
-- =============================================================================

-- Mostrar diagnóstico completo
CALL sp_diagnostico();

-- Mostrar estatísticas por categoria
SELECT * FROM vw_stats_categoria;

-- =============================================================================
-- FINAL
-- =============================================================================

SET FOREIGN_KEY_CHECKS=1;

SELECT '✅ Base de dados GOMESTECH instalada com sucesso!' AS status;
SELECT 'Total de produtos inseridos:' AS info, COUNT(*) AS total FROM produtos;
SELECT 'Categorias disponíveis:' AS info, COUNT(DISTINCT categoria) AS total FROM produtos;
SELECT 'Marcas disponíveis:' AS info, COUNT(DISTINCT marca) AS total FROM produtos;
