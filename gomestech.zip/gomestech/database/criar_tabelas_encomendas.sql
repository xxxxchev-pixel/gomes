-- Script SQL para criar tabelas de encomendas no GomesTech
-- Execute este script na sua base de dados MySQL

USE gomestech;

-- Tabela de encomendas
CREATE TABLE IF NOT EXISTS encomendas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero_encomenda VARCHAR(20) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    nif VARCHAR(9) NOT NULL,
    morada TEXT NOT NULL,
    codigo_postal VARCHAR(10) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    metodo_pagamento VARCHAR(50) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    custo_envio DECIMAL(10,2) DEFAULT 0,
    desconto DECIMAL(10,2) DEFAULT 0,
    total DECIMAL(10,2) NOT NULL,
    status ENUM('Pendente', 'Pago', 'Enviado', 'Entregue', 'Cancelado') DEFAULT 'Pendente',
    data_encomenda TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_numero_encomenda (numero_encomenda),
    INDEX idx_status (status),
    INDEX idx_data (data_encomenda)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de itens da encomenda
CREATE TABLE IF NOT EXISTS encomenda_itens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    encomenda_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (encomenda_id) REFERENCES encomendas(id) ON DELETE CASCADE,
    FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE RESTRICT,
    INDEX idx_encomenda (encomenda_id),
    INDEX idx_produto (produto_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Adicionar colunas na tabela users se não existirem
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS nif VARCHAR(9) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS codigo_postal VARCHAR(10) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS cidade VARCHAR(100) DEFAULT NULL;

-- Verificar se a coluna stock existe na tabela produtos
-- Se não existir, adicionar com valor padrão
ALTER TABLE produtos 
ADD COLUMN IF NOT EXISTS stock INT DEFAULT 100;

-- Inserir dados de exemplo (opcional para testes)
-- Descomentar as linhas abaixo se quiser dados de teste

/*
-- Exemplo de encomenda de teste
INSERT INTO encomendas (
    numero_encomenda, user_id, nome, email, telefone, nif,
    morada, codigo_postal, cidade, metodo_pagamento,
    subtotal, custo_envio, desconto, total, status
) VALUES (
    'GT20241127TEST', 1, 'João Silva', 'joao@example.com', '912345678', '123456789',
    'Rua das Flores, 123, 2º Esq', '1000-100', 'Lisboa', 'Multibanco',
    100.00, 4.99, 0, 104.99, 'Pendente'
);

-- Exemplo de item da encomenda
INSERT INTO encomenda_itens (encomenda_id, produto_id, quantidade, preco_unitario)
VALUES (LAST_INSERT_ID(), 1, 1, 100.00);
*/

-- Mostrar estrutura das tabelas criadas
SHOW CREATE TABLE encomendas;
SHOW CREATE TABLE encomenda_itens;

SELECT 'Tabelas de encomendas criadas com sucesso!' AS status;
