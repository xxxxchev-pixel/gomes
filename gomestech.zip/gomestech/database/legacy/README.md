# database/legacy

Esta pasta contém scripts SQL **antigos/opcionais** que foram usados durante o desenvolvimento.

## Porque existe?
- Para manter a pasta [database/](../README.md) limpa (com poucos ficheiros).
- Para não perder scripts úteis de manutenção/experimentos.

## Importante
- Para uma instalação normal do projeto, usa apenas [database/GOMESTECH.sql](../GOMESTECH.sql).
- Estes ficheiros podem estar desatualizados face ao esquema final.

## Conteúdo
- `criar_tabelas_encomendas.sql` (versão antiga/alternativa de tabelas de encomendas)
- `adicionar_especificacoes*.sql` (updates de JSON `especificacoes` em `produtos`)
- `especificacoes_completas_parte*.sql` (updates de especificações completas)
