-- =====================================================
-- ESPECIFICAÇÕES COMPLETAS - PARTE 2
-- Audio, Consolas e Eletrodomésticos
-- =====================================================

USE gomestech;

-- =====================================================
-- AUDIO (7 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Over-ear sem fios',
    'Cancelamento Ruído', 'Ativo Adaptativo (QuietComfort)',
    'Driver', '40mm TriPort',
    'Bateria', 'Até 24 horas',
    'Carregamento', 'USB-C (carga rápida 15min=2.5h)',
    'Bluetooth', '5.3',
    'Codecs', 'AAC, aptX Adaptive',
    'Controlos', 'Tácteis + botão físico',
    'Resistência', 'IPX4 (resistente a salpicos)',
    'Modos', 'ANC, Aware, Immersion',
    'App', 'Bose Music',
    'Cores', 'Preto, Prata'
) WHERE marca = 'Bose' AND modelo LIKE '%QuietComfort%' AND categoria = 'Audio' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Over-ear sem fios',
    'Cancelamento Ruído', 'Ativo Industry Leading',
    'Driver', '30mm',
    'Bateria', 'Até 30 horas (ANC On)',
    'Carregamento', 'USB-C (3min=3h)',
    'Bluetooth', '5.2',
    'Codecs', 'LDAC, AAC, SBC',
    'Controlos', 'Tácteis',
    'Hi-Res Audio', 'Certificado',
    'Multipoint', '2 dispositivos simultâneos',
    'Speak-to-Chat', 'Automático',
    'Cores', 'Preto, Prata'
) WHERE marca = 'Sony' AND modelo LIKE '%WH-1000XM5%' AND categoria = 'Audio' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Over-ear sem fios',
    'Cancelamento Ruído', 'Ativo com modo Transparência',
    'Driver', '40mm dinâmico Apple',
    'Bateria', 'Até 20 horas (ANC On)',
    'Carregamento', 'Lightning (5min=1.5h)',
    'Bluetooth', '5.0 + Chip H1',
    'Áudio Espacial', 'Com head tracking dinâmico',
    'Controlos', 'Digital Crown + botão',
    'Materiais', 'Alumínio e malha respirável',
    'Computational Audio', 'Sim',
    'Apple Ecosystem', 'Integração total',
    'Cores', '5 opções'
) WHERE marca = 'Apple' AND modelo LIKE '%AirPods Max%' AND categoria = 'Audio' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'In-ear sem fios (TWS)',
    'Cancelamento Ruído', 'Ativo Adaptativo',
    'Driver', 'Apple custom',
    'Bateria', 'Até 6h (estojo: 30h total)',
    'Carregamento', 'MagSafe + Lightning + USB-C',
    'Bluetooth', '5.3 + Chip H2',
    'Áudio Espacial', 'Personalizado com head tracking',
    'Controlos', 'Pressão + Deslizar volume',
    'Resistência', 'IPX4',
    'Modos', 'ANC, Transparência, Off',
    'Find My', 'Integrado no estojo',
    'Conversa', 'Automático'
) WHERE marca = 'Apple' AND modelo LIKE '%AirPods Pro%' AND categoria = 'Audio' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Coluna portátil',
    'Potência', '80W RMS',
    'Drivers', '2x woofers + 2x tweeters',
    'Bateria', 'Até 12 horas',
    'Carregamento', 'USB-C',
    'Bluetooth', '5.1',
    'Resistência', 'IP67 (água e poeira)',
    'PartyBoost', 'Liga até 100+ colunas',
    'Powerbank', 'Carrega dispositivos (USB)',
    'JBL App', 'Personalizável',
    'Peso', '960g',
    'Cores', '6 opções'
) WHERE marca = 'JBL' AND modelo LIKE '%Charge%' AND categoria = 'Audio' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Soundbar Premium',
    'Canais', '5.1.2 com Dolby Atmos',
    'Potência', '400W total',
    'Subwoofer', 'Wireless incluído',
    'Surround', 'Colunas traseiras opcionais',
    'Conectividade', 'HDMI eARC, Optical, Wi-Fi, Bluetooth',
    'Codecs', 'Dolby Atmos, DTS:X',
    'Alexa', 'Integrada',
    'AirPlay 2', 'Sim',
    'Spotify Connect', 'Sim',
    'Sonos App', 'Controlo total',
    'Trueplay', 'Calibração automática'
) WHERE marca = 'Sonos' AND modelo LIKE '%Arc%' AND categoria = 'Audio' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Coluna Smart',
    'Assistente', 'Amazon Alexa',
    'Som', 'Premium (graves profundos)',
    'Conectividade', 'Wi-Fi, Bluetooth',
    'Smart Home', 'Hub Zigbee integrado',
    'Áudio', 'Dolby stereo',
    'Controlo', 'Voz + App Alexa',
    'Multiroom', 'Liga com outros Echo',
    'Display LED', 'Anel de luz',
    'Privacy', 'Botão mute microfone',
    'Cores', 'Preto, Branco, Azul',
    'Peso', '940g'
) WHERE marca = 'Amazon' AND modelo LIKE '%Echo%' AND categoria = 'Audio' LIMIT 1;

-- =====================================================
-- CONSOLAS (5 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'AMD Zen 2 (8-core @ 3.5 GHz)',
    'GPU', 'AMD RDNA 2 (10.28 TFLOPs)',
    'RAM', '16GB GDDR6',
    'Armazenamento', '825GB SSD NVMe custom',
    'Resolução', 'Até 8K',
    'Taxa Frames', 'Até 120fps',
    'Ray Tracing', 'Hardware acelerado',
    'Leitor', 'Ultra HD Blu-ray 4K',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.1, Ethernet',
    'Portas', 'HDMI 2.1, USB-C, 2x USB-A',
    'DualSense', 'Haptic feedback + triggers adaptativos',
    'Retrocompatibilidade', 'PS4 (99% jogos)'
) WHERE marca = 'Sony' AND modelo LIKE '%PlayStation 5%' AND sku LIKE '%CS-%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'AMD Zen 2 (8-core @ 3.5 GHz)',
    'GPU', 'AMD RDNA 2 (10.28 TFLOPs)',
    'RAM', '16GB GDDR6',
    'Armazenamento', '825GB SSD NVMe custom',
    'Resolução', 'Até 8K',
    'Taxa Frames', 'Até 120fps',
    'Ray Tracing', 'Hardware acelerado',
    'Leitor', 'Sem leitor (Digital Only)',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.1',
    'Portas', 'HDMI 2.1, USB-C, 2x USB-A',
    'DualSense', 'Incluído',
    'Preço', 'Opção mais económica'
) WHERE marca = 'Sony' AND modelo LIKE '%Digital%' AND categoria = 'Consolas' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'AMD Zen 2 (8-core @ 3.8 GHz)',
    'GPU', 'AMD RDNA 2 (12 TFLOPs)',
    'RAM', '16GB GDDR6',
    'Armazenamento', '1TB SSD NVMe custom',
    'Resolução', 'Até 8K',
    'Taxa Frames', 'Até 120fps',
    'Ray Tracing', 'DirectX Raytracing',
    'Leitor', 'Ultra HD Blu-ray 4K',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.1, Ethernet',
    'Quick Resume', 'Retoma múltiplos jogos',
    'Xbox Game Pass', 'Compatible',
    'Retrocompatibilidade', '4 gerações Xbox'
) WHERE marca = 'Microsoft' AND modelo LIKE '%Series X%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'AMD Zen 2 (8-core @ 3.6 GHz)',
    'GPU', 'AMD RDNA 2 (4 TFLOPs)',
    'RAM', '10GB GDDR6',
    'Armazenamento', '512GB SSD NVMe',
    'Resolução', '1440p (upscale 4K)',
    'Taxa Frames', 'Até 120fps',
    'Ray Tracing', 'Sim',
    'Leitor', 'Sem leitor (All-Digital)',
    'Conectividade', 'Wi-Fi 5, Bluetooth 5.1',
    'Tamanho', '60% menor que Series X',
    'Xbox Game Pass', 'Otimizado',
    'Preço', 'Entry-level'
) WHERE marca = 'Microsoft' AND modelo LIKE '%Series S%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'Custom NVIDIA Tegra (Cortex-A57 + A78C)',
    'GPU', 'NVIDIA Maxwell / Ampere híbrida',
    'RAM', '4GB LPDDR4X',
    'Armazenamento', '64GB (expansível microSD)',
    'Resolução', '1080p TV / 720p portátil',
    'Taxa Frames', 'Até 60fps',
    'Ecrã', '7" OLED 720p (modelo OLED)',
    'Bateria', '4310 mAh (4.5-9h gameplay)',
    'Modos', 'TV, Tabletop, Portátil',
    'Joy-Con', '2 controlos destacáveis',
    'Online', 'Nintendo Switch Online',
    'Exclusivos', 'Mario, Zelda, Pokémon, Splatoon'
) WHERE marca = 'Nintendo' AND modelo LIKE '%OLED%' AND categoria = 'Consolas' LIMIT 1;

-- =====================================================
-- FRIGORÍFICOS (3 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '617 Litros',
    'Tipo', 'Side-by-Side French Door',
    'Classe Energética', 'A++',
    'Tecnologia', 'Family Hub 3.0',
    'Ecrã', '21.5" Full HD Touch',
    'NoFrost', 'Total (frigorífico + congelador)',
    'Dispensador', 'Água filtrada + Gelo (crushed/cubed)',
    'Compartimentos', 'FlexZone ajustável',
    'Iluminação', 'LED em todos os níveis',
    'Dimensões', '912 x 716 x 1853 mm',
    'Peso', '155 kg',
    'Cor', 'Aço Inoxidável',
    'Smart', 'Wi-Fi, App SmartThings, Alexa',
    'Câmaras', '3 internas (ver conteúdo remotamente)'
) WHERE categoria = 'Frigoríficos' AND marca = 'Samsung' AND modelo LIKE '%Family Hub%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '635 Litros',
    'Tipo', 'Side-by-Side InstaView',
    'Classe Energética', 'A+',
    'Tecnologia', 'InstaView Door-in-Door',
    'Porta', 'Vidro espelhado (toca 2x para iluminar)',
    'NoFrost', 'Total',
    'Dispensador', 'Água + Gelo + Craft Ice (esferas)',
    'LinearCooling', '±0.5°C estabilidade',
    'Door Cooling+', 'Ar frio direto na porta',
    'Dimensões', '912 x 738 x 1790 mm',
    'Peso', '145 kg',
    'Cor', 'Inox escovado',
    'Smart', 'Wi-Fi, App ThinQ, Google/Alexa',
    'Compressor', 'Linear Inverter (garantia 10 anos)'
) WHERE categoria = 'Frigoríficos' AND marca = 'LG' AND modelo LIKE '%InstaView%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '324 Litros',
    'Tipo', 'Combinado (frigorífico em cima)',
    'Classe Energética', 'A+++',
    'NoFrost', 'Total',
    'VitaFresh Pro', '3 gavetas (0°C preservação)',
    'MultiAirflow', 'Distribuição uniforme frio',
    'SuperCooling', 'Arrefecimento rápido',
    'Display', 'LED touch interior',
    'Iluminação', 'LED lateral uniforme',
    'Dimensões', '600 x 660 x 1860 mm',
    'Peso', '78 kg',
    'Cor', 'Aço Inoxidável',
    'Ruído', '36 dB (super silencioso)',
    'Compressor', 'Inverter eficiente'
) WHERE categoria = 'Frigoríficos' AND marca = 'Bosch' AND modelo LIKE '%Serie 6%' LIMIT 1;

-- =====================================================
-- MÁQUINAS DE LAVAR (3 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade Lavagem', '9 kg',
    'Capacidade Secagem', '6 kg',
    'Tipo', 'Lavagem-Secagem',
    'Classe Energética', 'A (Lavagem+Secagem E)',
    'Velocidade', '1400 RPM',
    'Tecnologia', 'AI DD (Direct Drive AI)',
    'Vapor', 'TurboSteam (elimina 99.9% alergénios)',
    'Programas', '14 lavagem + 10 secagem',
    'Display', 'LED Touch',
    'Motor', 'Inverter Direct Drive (garantia 10 anos)',
    'Smart', 'Wi-Fi, App ThinQ, controlo voz',
    'Dimensões', '600 x 640 x 850 mm',
    'Nível Ruído', '72 dB (lavagem) / 74 dB (secagem)',
    'Cor', 'Branco'
) WHERE categoria = 'Máquinas de Lavar' AND marca = 'LG' AND modelo LIKE '%AI DD%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '9 kg',
    'Tipo', 'Carga frontal',
    'Classe Energética', 'A+++',
    'Velocidade', '1400 RPM',
    'Tecnologia', 'i-DOS (doseamento automático)',
    'AntiVibration', 'Design para estabilidade',
    'VarioPerfect', '速度 ou Eco',
    'Programas', '15 (incluindo Outdoor, Delicados)',
    'Display', 'LED grande',
    'Motor', 'EcoSilence Drive',
    'Home Connect', 'Wi-Fi, App Bosch',
    'Dimensões', '598 x 590 x 848 mm',
    'Nível Ruído', '47 dB (lavagem) / 71 dB (centrifugação)',
    'Cor', 'Branco'
) WHERE categoria = 'Máquinas de Lavar' AND marca = 'Bosch' AND modelo LIKE '%Serie 8%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '9 kg',
    'Tipo', 'Carga frontal',
    'Classe Energética', 'A+++',
    'Velocidade', '1400 RPM',
    'Tecnologia', 'AddWash (adicionar roupa durante ciclo)',
    'EcoBubble', 'Lavagem eficaz água fria',
    'Programas', '14 (incluindo Super Speed 39min)',
    'Display', 'LED digital',
    'Motor', 'Digital Inverter (garantia 10 anos)',
    'Smart', 'Wi-Fi, App SmartThings',
    'Diamond Drum', 'Protege tecidos',
    'Dimensões', '600 x 600 x 850 mm',
    'Nível Ruído', '53 dB (lavagem) / 73 dB (centrifugação)',
    'Cor', 'Branco'
) WHERE categoria = 'Máquinas de Lavar' AND marca = 'Samsung' AND modelo LIKE '%AddWash%' LIMIT 1;

-- =====================================================
-- MICRO-ONDAS (3 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência', '850W micro / 1000W grill',
    'Capacidade', '23 Litros',
    'Tipo', 'Combinado (micro + grill)',
    'Tecnologia', 'Smart Sensor (ajuste automático)',
    'Grill', 'Cerâmica (fácil limpeza)',
    'Níveis Potência', '6',
    'Display', 'LED + botões tácteis',
    'Interior', 'Cerâmica esmaltada',
    'Programas', '6 automáticos',
    'Descongelação', 'Por peso',
    'Dimensões', '489 x 275 x 330 mm',
    'Cor', 'Preto',
    'Turntable', '28.8 cm',
    'Funções', 'Micro, Grill, Combinado'
) WHERE categoria = 'Micro-ondas' AND marca = 'Samsung' AND modelo LIKE '%Smart%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência', '1200W micro / 1000W grill',
    'Capacidade', '39 Litros',
    'Tipo', 'Combinado Smart Inverter',
    'Tecnologia', 'Inverter (descongelação uniforme)',
    'Grill', 'Quartz',
    'Níveis Potência', '10',
    'Display', 'LED branco',
    'Interior', 'EasyClean (antiaderente)',
    'Programas', '20 automáticos',
    'Descongelação', 'Turbo 3x mais rápido',
    'Dimensões', '563 x 350 x 483 mm',
    'Cor', 'Aço escovado',
    'NeoChef', 'Design premium',
    'Turntable', '34 cm'
) WHERE categoria = 'Micro-ondas' AND marca = 'LG' AND modelo LIKE '%NeoChef%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência', '1000W',
    'Capacidade', '27 Litros',
    'Tipo', 'Inverter',
    'Tecnologia', 'Inverter Turbo Defrost',
    'Níveis Potência', '5 inverter',
    'Display', 'LED + dial',
    'Interior', 'Flatbed (sem prato giratório)',
    'Programas', '17 automáticos',
    'Genius Sensor', 'Ajuste automático tempo/potência',
    'Dimensões', '550 x 310 x 398 mm',
    'Cor', 'Inox',
    'Flatbed', 'Mais espaço interno',
    'Chaos Defrost', 'Descongelação 360°'
) WHERE categoria = 'Micro-ondas' AND marca = 'Panasonic' AND modelo LIKE '%Inverter%' LIMIT 1;

-- =====================================================
-- ASPIRADORES (3 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência', '230W',
    'Sucção', '230 AW (Air Watts)',
    'Tipo', 'Sem fios stick vacuum',
    'Autonomia', 'Até 60 minutos (modo Eco)',
    'Carregamento', '4.5 horas completo',
    'Depósito', '0.76 Litros',
    'Peso', '3.0 kg',
    'Filtração', 'HEPA avançado (99.99%)',
    'Display', 'LCD (mostra modo, bateria, bloqueios)',
    'Modos', '3 (Eco, Auto, Boost)',
    'Laser', 'Detecção poeira invisível',
    'Acessórios', '8 ferramentas incluídas',
    'Motorbar', 'Escova anti-emaranhamento'
) WHERE categoria = 'Aspiradores' AND marca = 'Dyson' AND modelo LIKE '%V15%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Robô aspirador',
    'Navegação', 'PrecisionVision (câmara + AI)',
    'Sucção', '10x superior (vs Roomba 600)',
    'Escovas', 'Dual Multi-Surface (anti-emaranhamento)',
    'Clean Base', 'Auto-esvaziamento (60 dias)',
    'Bateria', 'Até 120 minutos',
    'Conectividade', 'Wi-Fi, App iRobot Genius',
    'Mapeamento', 'Imprint Smart Mapping',
    'Evita', 'Objetos sólidos (cabos, pet waste)',
    'Controlo Voz', 'Alexa, Google Assistant',
    'Sugestões', 'AI aprende e sugere limpezas',
    'Dimensões', '34 cm diâmetro x 9 cm altura'
) WHERE categoria = 'Aspiradores' AND marca = 'iRobot' AND modelo LIKE '%Roomba j7%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Robô aspirador + mop',
    'Navegação', 'LDS Laser (360° scan)',
    'Sucção', '4000 Pa',
    'Estação', 'Auto-esvaziamento + Auto-lavagem mop',
    'Depósito Poeira', '2.5L base + 0.55L robô',
    'Depósito Água', '2.5L água limpa + 2L água suja',
    'Bateria', '5200 mAh (até 180min)',
    'Mapeamento', 'Multi-piso (4 mapas)',
    'App', 'Mi Home / Xiaomi Home',
    'Obstáculos', 'Reactive 3D AI',
    'Mop', 'Vibração sónica',
    'Controlo Voz', 'Alexa, Google, Siri Shortcuts'
) WHERE categoria = 'Aspiradores' AND marca = 'Xiaomi' AND modelo LIKE '%Robot S10%' LIMIT 1;

-- =====================================================
-- AR CONDICIONADO (5 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência Refrigeração', '3.5 kW (12000 BTU)',
    'Potência Aquecimento', '4.0 kW (bomba de calor)',
    'Classe Energética', 'A+++ (refrigeração) / A++ (aquecimento)',
    'Tecnologia', 'Inverter Flash Streak',
    'Tipo', 'Split parede',
    'SEER', '8.73 (super eficiente)',
    'Nível Ruído', '19 dB (unidade interior)',
    'Controlo', 'Wi-Fi, App Daikin Onecta',
    'Modo Noturno', 'Operação silenciosa',
    'Filtros', 'Flash Streamer + Plasma Quad Plus',
    'Gás Refrigerante', 'R-32 (eco-friendly)',
    'Garantia', '5 anos compressor',
    'Dimensões Interior', '770 x 285 x 225 mm'
) WHERE categoria = 'Ar Condicionado' AND marca = 'Daikin' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência Refrigeração', '2.5 kW (9000 BTU)',
    'Potência Aquecimento', '3.2 kW',
    'Classe Energética', 'A++',
    'Tecnologia', 'Inverter Hyper Heating',
    'Tipo', 'Split parede',
    'SEER', '7.1',
    'Nível Ruído', '21 dB',
    'Controlo', 'Wi-Fi, App MELCloud',
    'Plasma Quad Plus', 'Purificação ar 4 fases',
    'Dry Mode', 'Desumidificação',
    'I-save', 'Modo poupança energia',
    'Gás Refrigerante', 'R-32',
    'Dimensões Interior', '799 x 295 x 209 mm'
) WHERE categoria = 'Ar Condicionado' AND marca = 'Mitsubishi' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência Refrigeração', '3.4 kW (12000 BTU)',
    'Potência Aquecimento', '4.0 kW',
    'Classe Energética', 'A++',
    'Tecnologia', 'Inverter',
    'Tipo', 'Split parede',
    'SEER', '6.8',
    'Nível Ruído', '23 dB',
    'Human Sensor', 'Deteta presença e ajusta',
    'Swing Automático', 'Vertical + Horizontal',
    'Filtros', 'Catechin + Anti-alérgico',
    'Timer', '24h programável',
    'Gás Refrigerante', 'R-32',
    'Dimensões Interior', '798 x 290 x 249 mm'
) WHERE categoria = 'Ar Condicionado' AND marca = 'Fujitsu' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência Refrigeração', '2.6 kW (9000 BTU)',
    'Potência Aquecimento', '3.0 kW',
    'Classe Energética', 'A++',
    'Tecnologia', 'Dual Inverter Compressor',
    'Tipo', 'Split parede',
    'SEER', '7.5',
    'Nível Ruído', '19 dB (modo silencioso)',
    'Controlo', 'Wi-Fi, App LG ThinQ',
    'Active Energy Control', 'Poupança até 70%',
    'Plasmaster Ionizer', 'Purificação ar',
    'Auto Clean', 'Limpeza automática interior',
    'Gás Refrigerante', 'R-32',
    'Compressor', 'Garantia 10 anos'
) WHERE categoria = 'Ar Condicionado' AND marca = 'LG' AND modelo LIKE '%Dual%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência Refrigeração', '3.5 kW (12000 BTU)',
    'Potência Aquecimento', '4.0 kW',
    'Classe Energética', 'A++',
    'Tecnologia', 'WindFree (sem correntes ar diretas)',
    'Tipo', 'Split parede',
    'SEER', '7.04',
    'Nível Ruído', '16 dB (modo WindFree)',
    'Controlo', 'Wi-Fi, App SmartThings',
    'AI Auto Cooling', 'Aprende padrões uso',
    'Good Sleep', 'Modo noturno inteligente',
    'Filtros', '3-Care (vírus, bactérias, pó)',
    'Gás Refrigerante', 'R-32',
    'Design', 'Minimalista branco mate'
) WHERE categoria = 'Ar Condicionado' AND marca = 'Samsung' AND modelo LIKE '%WindFree%' LIMIT 1;

-- =====================================================
-- MÁQUINAS DE CAFÉ (4 produtos)
-- =====================================================

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Automática de grão',
    'Pressão', '15 bar',
    'Depósito Água', '1.8 Litros',
    'Depósito Grãos', '250g',
    'Moinho', 'Aço inox (13 níveis)',
    'Display', 'TFT a cores 3.5"',
    'Bebidas', '13 receitas one-touch',
    'Vaporizador', 'LatteCrema System',
    'LatteCrema', 'Espuma cremosa automática',
    'Potência', '1450W',
    'App', 'Coffee Link (Bluetooth)',
    'Limpeza', 'Auto-limpeza',
    'Dimensões', '240 x 445 x 360 mm'
) WHERE categoria = 'Máquinas de Café' AND marca = 'De''Longhi' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Cápsulas Nespresso',
    'Pressão', '19 bar',
    'Depósito Água', '1.0 Litro',
    'Cápsulas Usadas', 'Contentor 10 cápsulas',
    'Tamanhos', 'Espresso, Lungo, Gran Lungo',
    'Aquecimento', '25 segundos',
    'Bluetooth', 'App Nespresso',
    'Aeroccino', 'Espumador leite incluído',
    'Potência', '1500W',
    'Auto-desligamento', 'Após 9 minutos',
    'Cores', '8 opções',
    'Dimensões', '120 x 380 x 280 mm',
    'Reciclagem', 'Cápsulas alumínio 100% recicláveis'
) WHERE categoria = 'Máquinas de Café' AND marca = 'Nespresso' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Manual profissional',
    'Pressão', '15 bar (bomba italiana)',
    'Depósito Água', '2.0 Litros',
    'Portafiltro', '54mm profissional',
    'Moinho', 'Integrado (burr moinho)',
    'Display', 'LCD',
    'Controlo Temperatura', 'PID (precisão 1°C)',
    'Varinha Vapor', 'Comercial (4 furos)',
    'Pré-infusão', 'Baixa pressão',
    'Potência', '1680W',
    'Pressostato', 'Digital',
    'Materiais', 'Aço inox escovado',
    'Dimensões', '310 x 330 x 405 mm'
) WHERE categoria = 'Máquinas de Café' AND marca = 'Sage' AND modelo LIKE '%Barista%' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Automática cápsulas',
    'Sistema', 'Dolce Gusto',
    'Pressão', '15 bar',
    'Depósito Água', '0.8 Litros',
    'Cápsulas', 'Compatível Dolce Gusto',
    'Bebidas', 'Quentes e frias',
    'Display', 'Touch LCD',
    'Aquecimento', '30 segundos',
    'Bluetooth', 'App NESCAFÉ Dolce Gusto',
    'XL Mode', 'Chávenas grandes',
    'Potência', '1500W',
    'Cores', 'Preto, Branco, Vermelho',
    'Dimensões', '240 x 370 x 270 mm'
) WHERE categoria = 'Máquinas de Café' AND marca = 'Krups' LIMIT 1;

SELECT '✅ Especificações completas adicionadas a TODOS os 66 produtos!' AS status;
