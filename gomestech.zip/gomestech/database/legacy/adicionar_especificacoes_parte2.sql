-- =====================================================
-- ESPECIFICAÇÕES FALTANTES - PARTE 2
-- Adiciona especificações para os 18 produtos restantes
-- =====================================================

USE gomestech;

-- =====================================================
-- AR CONDICIONADO (1 produto faltante)
-- =====================================================

-- ID 58: Samsung WindFree Elite 12000 BTU
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '12000 BTU',
    'Tipo', 'Split Inverter',
    'Classe Energética', 'A+++',
    'SEER', '8.9',
    'SCOP', '5.2',
    'Tecnologia', 'WindFree (23000 micro-furos), AI Auto Cooling',
    'Gás Refrigerante', 'R32',
    'Níveis Velocidade', '5 velocidades + WindFree',
    'Modos', 'Arrefecimento, Aquecimento, Desumidificação, Ventilação',
    'Smart Features', 'Wi-Fi, SmartThings, Bixby, Google Assistant',
    'Filtros', 'PM 1.0 Filter',
    'Nível Ruído', '16 dB (modo WindFree)',
    'Dimensões Unidade Interior', '110.8 x 29.2 x 20.3 cm',
    'Garantia', '3 anos (10 anos compressor)'
) WHERE id = 58;

-- =====================================================
-- ASPIRADORES (2 produtos faltantes)
-- =====================================================

-- ID 56: iRobot Roomba j7+
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Robot Aspirador com Auto-Esvaziamento',
    'Navegação', 'PrecisionVision + iRobot OS',
    'Mapeamento', 'Imprint Smart Mapping',
    'Sucção', 'Sistema AeroForce 3 estágios',
    'Filtros', 'Filtro HEPA',
    'Bateria', 'Até 75 minutos',
    'Base', 'Clean Base Auto-Esvaziamento (60 dias)',
    'Sensores', 'Detecção obstáculos, anti-queda',
    'Evitar Objetos', 'P.O.O.P. (deteta cabos, meias, dejetos)',
    'Conectividade', 'Wi-Fi, app iRobot Home, Alexa, Google',
    'Programação', 'Zonas Keep Out, limpeza por divisões',
    'Peso', '3.4 kg',
    'Extra', 'Escovas anti-emaranhamento'
) WHERE id = 56;

-- ID 57: Xiaomi Robot Vacuum S10+
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Robot Aspirador e Esfregona com Auto-Esvaziamento',
    'Navegação', 'LDS Laser + Visual SLAM',
    'Mapeamento', 'Multi-piso (até 4 mapas)',
    'Sucção', '4000 Pa',
    'Filtros', 'HEPA E11',
    'Bateria', '5200 mAh (até 180 min)',
    'Depósito Água', '200ml',
    'Base', 'Auto-Esvaziamento + Lavagem Esfregona',
    'Conectividade', 'Wi-Fi, app Mi Home, Alexa, Google',
    'Sensores', 'Detecção tapetes, anti-queda',
    'Modos', 'Aspirar, Esfregar, Híbrido',
    'Peso', '3.7 kg',
    'Extra', 'Esfregona rotativa, tapetes auto-levante'
) WHERE id = 57;

-- =====================================================
-- AUDIO (3 produtos faltantes)
-- =====================================================

-- ID 34: Apple AirPods Max
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Auscultadores Over-Ear',
    'Driver', '40mm custom dynamic',
    'Cancelamento Ruído', 'ANC Ativo + Modo Transparência',
    'Áudio Espacial', 'Sim (com rastreamento dinâmico)',
    'Chip', 'Apple H1 (dual)',
    'Bateria', 'Até 20h (ANC ativo)',
    'Carregamento', 'Lightning',
    'Conectividade', 'Bluetooth 5.0',
    'Sensores', 'Acelerómetro, giroscópio, detecção uso',
    'Controlos', 'Digital Crown, botão de controlo ruído',
    'Compatibilidade', 'iOS, macOS, watchOS',
    'Materiais', 'Alumínio, aço inoxidável, almofadas memory foam',
    'Peso', '384.8g',
    'Extra', 'Smart Case incluída'
) WHERE id = 34;

-- ID 39: JBL Charge 5
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Coluna Bluetooth Portátil',
    'Driver', '1x Woofer racetrack, 2x Tweeters',
    'Potência', '40W RMS',
    'Resposta Frequência', '60Hz - 20kHz',
    'Bateria', '7500mAh (até 20h)',
    'Resistência', 'IP67 (água e poeira)',
    'Conectividade', 'Bluetooth 5.1',
    'PartyBoost', 'Sim (ligar múltiplas colunas)',
    'PowerBank', 'Sim (USB-A)',
    'Peso', '960g',
    'Dimensões', '22.0 x 9.6 x 9.3 cm',
    'Cores', '8 opções disponíveis',
    'Extra', 'Alça de transporte integrada'
) WHERE id = 39;

-- ID 40: Sonos Era 300
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Coluna Smart Multiroom',
    'Drivers', '6 drivers (4 full-range, 2 tweeters)',
    'Áudio Espacial', 'Dolby Atmos, Spatial Audio',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.0, USB-C, Ethernet',
    'Sistema Operativo', 'Sonos S2',
    'Assistente Voz', 'Amazon Alexa, Sonos Voice Control',
    'AirPlay', 'AirPlay 2',
    'Trueplay', 'Sim (tuning automático)',
    'Peso', '4.5 kg',
    'Dimensões', '26 x 18.5 x 16 cm',
    'Audio', 'Som imersivo 360°',
    'Compatibilidade', 'iOS, Android, PC',
    'Extra', 'Botões touch, controlo por app'
) WHERE id = 40;

-- =====================================================
-- CONSOLAS (3 produtos faltantes)
-- =====================================================

-- ID 42: Sony PlayStation 5 Digital
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'AMD Zen 2 (8-core @ 3.5GHz)',
    'GPU', 'AMD RDNA 2 (10.28 TFLOPs)',
    'RAM', '16GB GDDR6',
    'Armazenamento', '825GB SSD NVMe (expansível)',
    'Resolução', 'Até 8K, 4K @ 120Hz',
    'Ray Tracing', 'Sim (hardware)',
    'Leitura Ótica', 'Não (apenas digital)',
    'Audio', 'Tempest 3D AudioTech',
    'Controlo', 'DualSense (haptic feedback)',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.1, Gigabit Ethernet',
    'Portas', '1x HDMI 2.1, 3x USB-A, 1x USB-C',
    'Dimensões', '39 x 9.2 x 26 cm',
    'Peso', '3.9 kg'
) WHERE id = 42;

-- ID 44: Microsoft Xbox Series S
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'AMD Zen 2 (8-core @ 3.6GHz)',
    'GPU', 'AMD RDNA 2 (4 TFLOPs)',
    'RAM', '10GB GDDR6',
    'Armazenamento', '512GB SSD NVMe (expansível)',
    'Resolução', 'Até 1440p @ 120Hz',
    'Ray Tracing', 'Sim',
    'Leitura Ótica', 'Não (apenas digital)',
    'Audio', 'Spatial Sound',
    'Controlo', 'Xbox Wireless Controller',
    'Conectividade', 'Wi-Fi 5, Bluetooth 5.1, Gigabit Ethernet',
    'Portas', '1x HDMI 2.1, 3x USB-A',
    'Dimensões', '27.5 x 15.1 x 6.35 cm',
    'Peso', '1.93 kg'
) WHERE id = 44;

-- ID 45: Nintendo Switch OLED
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'NVIDIA Custom Tegra (ARM Cortex-A57)',
    'GPU', 'NVIDIA Maxwell (256 CUDA cores)',
    'RAM', '4GB LPDDR4',
    'Armazenamento', '64GB (expansível até 2TB microSD)',
    'Ecrã', '7" OLED Multi-Touch',
    'Resolução', '1280 x 720 (portátil), 1920 x 1080 (TV)',
    'Audio', 'Stereo Speakers',
    'Bateria', '4310 mAh (4.5h a 9h)',
    'Conectividade', 'Wi-Fi 5, Bluetooth 4.1',
    'Modos', 'TV, Tabletop, Portátil',
    'Controlos', 'Joy-Con destacáveis',
    'Base', 'Dock com LAN Ethernet',
    'Dimensões', '24.2 x 10.2 x 1.4 cm',
    'Peso', '320g (apenas consola)'
) WHERE id = 45;

-- =====================================================
-- FRIGORÍFICOS (1 produto faltante)
-- =====================================================

-- ID 48: Bosch KGN39VWEA Combinado
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Combinado (frigo em cima)',
    'Capacidade Total', '366L (279L frigo + 87L congelador)',
    'Classe Energética', 'C',
    'Consumo Anual', '219 kWh',
    'Tecnologia', 'VitaFresh, LowFrost',
    'No Frost', 'LowFrost (baixa formação gelo)',
    'Prateleiras', 'Vidro de segurança',
    'Gavetas', 'VitaFresh XXL',
    'Iluminação', 'LED',
    'Dimensões', '60 x 201 x 66 cm',
    'Peso', '82 kg',
    'Nível Ruído', '38 dB',
    'Extra', 'Alarme porta aberta, display LCD'
) WHERE id = 48;

-- =====================================================
-- MÁQUINAS DE CAFÉ (1 produto faltante)
-- =====================================================

-- ID 63: Nespresso Essenza Mini
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Máquina de cápsulas',
    'Sistema', 'Nespresso Original',
    'Pressão', '19 bar',
    'Depósito Água', '0.6L',
    'Aquecimento', '30 segundos',
    'Tamanhos Café', '2 opções (Espresso 40ml, Lungo 110ml)',
    'Cápsulas Usadas', 'Capacidade 6 cápsulas',
    'Potência', '1260W',
    'Auto-Desligar', 'Após 9 minutos',
    'Dimensões', '33 x 20.4 x 8.4 cm',
    'Peso', '2.3 kg',
    'Cores', 'Preto, Branco, Vermelho',
    'Extra', 'Compacta, ideal para espaços pequenos'
) WHERE id = 63;

-- =====================================================
-- MÁQUINAS DE LAVAR (1 produto faltante)
-- =====================================================

-- ID 51: Bosch WAU28S80ES 8kg
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '8 kg',
    'Velocidade Centrifugação', '1400 rpm',
    'Classe Energética', 'A',
    'Consumo Anual', '152 kWh',
    'Consumo Água', '42L por ciclo',
    'Tecnologia', 'EcoSilence Drive, ActiveWater Plus',
    'Motor', 'EcoSilence (10 anos garantia)',
    'Programas', '15 programas',
    'Display', 'LED',
    'Dimensões', '59.8 x 84.8 x 59 cm',
    'Peso', '71 kg',
    'Nível Ruído', '47 dB (lavagem) / 71 dB (centrifugação)',
    'Extra', 'SpeedPerfect, Reload'
) WHERE id = 51;

-- =====================================================
-- MICRO-ONDAS (1 produto faltante)
-- =====================================================

-- ID 54: Bosch BFL524MS0 Encastre
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '20L',
    'Potência', '800W',
    'Tipo', 'Encastre',
    'Tecnologia', 'AutoPilot 7 (programas automáticos)',
    'Níveis Potência', '5 níveis',
    'Prato', '25.5cm giratório',
    'Display', 'TFT Touch Control',
    'Acabamento', 'Aço inoxidável',
    'Dimensões', '59.4 x 38.2 x 31.5 cm',
    'Dimensões Nicho', '56-56.2 x 36 x 55 cm',
    'Peso', '15 kg',
    'Extra', 'Função memória, bloqueio crianças'
) WHERE id = 54;

-- =====================================================
-- TABLETS (1 produto faltante)
-- =====================================================

-- ID 21: Apple iPad 10.9" 64GB
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '10.9" Liquid Retina IPS',
    'Resolução', '2360 x 1640 pixels',
    'Processador', 'Apple A14 Bionic',
    'RAM', '4GB',
    'Armazenamento', '64GB',
    'Câmara Principal', '12MP Wide',
    'Câmara Frontal', '12MP Ultra Wide (landscape)',
    'Bateria', '28.6 Wh (até 10h)',
    'Sistema Operativo', 'iPadOS 17',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.2, 5G (opcional)',
    'Portas', 'USB-C',
    'Compatibilidade', 'Apple Pencil (1ª gen), Magic Keyboard Folio',
    'Peso', '477g (Wi-Fi)',
    'Cores', '4 opções'
) WHERE id = 21;

-- =====================================================
-- TVS (3 produtos faltantes)
-- =====================================================

-- ID 29: Samsung Neo QLED 65" QN95C
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '65" Neo QLED 4K',
    'Resolução', '3840 x 2160 pixels',
    'Tecnologia', 'Quantum Mini LED, Neural Quantum Processor 4K',
    'HDR', 'HDR10+, HLG, Quantum HDR 2000',
    'Taxa Atualização', '120Hz',
    'Sistema Operativo', 'Tizen OS',
    'Audio', '60W 4.2.2Ch Object Tracking Sound+',
    'Smart Features', 'Bixby, Alexa, Google Assistant',
    'Gaming', 'Motion Xcelerator Turbo+, AMD FreeSync Premium Pro',
    'Design', 'Infinity One Design, One Connect Box',
    'Conectividade', '4x HDMI 2.1, 2x USB, Wi-Fi 6E, Bluetooth 5.2',
    'Dimensões', '144.4 x 82.7 x 2.62 cm',
    'Peso', '23.9 kg (sem base)'
) WHERE id = 29;

-- ID 30: LG OLED 55" C3
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '55" OLED Evo 4K',
    'Resolução', '3840 x 2160 pixels',
    'Tecnologia', 'OLED Self-Lit Pixels',
    'Processador', 'α9 AI Processor Gen6',
    'HDR', 'HDR10, Dolby Vision IQ, HLG',
    'Taxa Atualização', '120Hz',
    'Sistema Operativo', 'webOS 23',
    'Audio', '40W 2.2Ch Dolby Atmos',
    'Smart Features', 'ThinQ AI, Google Assistant, Alexa',
    'Gaming', 'G-Sync, FreeSync Premium, VRR, ALLM (4x HDMI 2.1)',
    'Conectividade', '4x HDMI 2.1, 3x USB, Wi-Fi 6, Bluetooth 5.3',
    'Dimensões', '122.8 x 70.6 x 4.49 cm',
    'Peso', '14.2 kg (sem base)'
) WHERE id = 30;

-- ID 33: Philips OLED 55" 808
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '55" OLED 4K',
    'Resolução', '3840 x 2160 pixels',
    'Tecnologia', 'OLED EX, Ambilight 3 lados',
    'Processador', 'P5 Perfect Picture Engine',
    'HDR', 'HDR10+, Dolby Vision, HLG',
    'Taxa Atualização', '120Hz',
    'Sistema Operativo', 'Android TV (Google TV)',
    'Audio', '50W 2.1Ch Dolby Atmos',
    'Smart Features', 'Google Assistant, Alexa',
    'Gaming', 'HDMI 2.1, VRR, ALLM, FreeSync Premium',
    'Conectividade', '4x HDMI 2.1, 2x USB, Wi-Fi 5, Bluetooth 5.0',
    'Dimensões', '122.7 x 72.1 x 5.2 cm',
    'Peso', '17.8 kg (sem base)'
) WHERE id = 33;

-- =====================================================
-- WEARABLES (1 produto faltante)
-- =====================================================

-- ID 28: Xiaomi Watch S2 Pro
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.43" AMOLED',
    'Resolução', '466 x 466 pixels',
    'Bateria', 'Até 14 dias',
    'Sensores', 'Frequência cardíaca, SpO2, GPS dual-band',
    'Resistência', '5ATM',
    'GPS', 'Dual-band GNSS',
    'Conectividade', 'Bluetooth 5.2',
    'Sistema Operativo', 'HyperOS',
    'Modos Desportivos', '150+',
    'Compatibilidade', 'Android 6.0+ / iOS 12+',
    'Caixa', 'Liga de Alumínio',
    'Peso', '52g (sem bracelete)',
    'Funcionalidades', 'Alexa, monitorização sono, stress'
) WHERE id = 28;

-- =====================================================
-- CONSULTAS DE VERIFICAÇÃO FINAL
-- =====================================================

-- Verificar quantos produtos agora têm especificações
SELECT 
    'Produtos com especificações' as status,
    COUNT(*) as total
FROM produtos 
WHERE especificacoes IS NOT NULL 
  AND especificacoes != '' 
  AND especificacoes != 'null';

-- Verificar quantos produtos ainda não têm especificações
SELECT 
    'Produtos SEM especificações' as status,
    COUNT(*) as total
FROM produtos 
WHERE especificacoes IS NULL 
  OR especificacoes = '' 
  OR especificacoes = 'null';

-- Listar produtos sem especificações (se ainda houver)
SELECT id, marca, modelo, categoria
FROM produtos 
WHERE especificacoes IS NULL 
  OR especificacoes = '' 
  OR especificacoes = 'null'
ORDER BY categoria, id;

-- Verificar total de produtos por categoria com especificações
SELECT 
    categoria,
    COUNT(*) as total,
    SUM(CASE WHEN especificacoes IS NOT NULL AND especificacoes != '' AND especificacoes != 'null' THEN 1 ELSE 0 END) as com_specs
FROM produtos
GROUP BY categoria
ORDER BY categoria;

SELECT '✅ TODAS AS ESPECIFICAÇÕES FORAM ADICIONADAS COM SUCESSO!' as resultado;
