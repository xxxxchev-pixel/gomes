-- =====================================================
-- ESPECIFICAÇÕES COMPLETAS PARA PRODUTOS FALTANTES
-- Adiciona especificações técnicas para 46 produtos
-- =====================================================

USE gomestech;

-- =====================================================
-- SMARTPHONES (4 produtos faltantes)
-- =====================================================

-- ID 6: Samsung Galaxy A54 5G 128GB
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.4" Super AMOLED',
    'Resolução', '2340 x 1080 pixels (120Hz)',
    'Processador', 'Exynos 1380',
    'RAM', '8GB',
    'Armazenamento', '128GB (expansível até 1TB)',
    'Câmara Principal', '50MP + 12MP Ultra + 5MP Macro',
    'Câmara Frontal', '32MP',
    'Bateria', '5000 mAh',
    'Sistema Operativo', 'Android 13 / One UI 5.1',
    '5G', 'Sim',
    'Resistência', 'IP67',
    'Carregamento', '25W Super Fast'
) WHERE id = 6;

-- ID 7: Xiaomi 13 Pro 256GB
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.73" AMOLED LTPO',
    'Resolução', '3200 x 1440 pixels (120Hz)',
    'Processador', 'Snapdragon 8 Gen 2',
    'RAM', '12GB LPDDR5X',
    'Armazenamento', '256GB UFS 4.0',
    'Câmara Principal', '50MP Leica + 50MP Tele + 50MP Ultra',
    'Câmara Frontal', '32MP',
    'Bateria', '4820 mAh',
    'Sistema Operativo', 'Android 13 / MIUI 14',
    '5G', 'Sim',
    'Resistência', 'IP68',
    'Carregamento', '120W HyperCharge'
) WHERE id = 7;

-- ID 8: Google Pixel 7 128GB
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.3" AMOLED',
    'Resolução', '2400 x 1080 pixels (90Hz)',
    'Processador', 'Google Tensor G2',
    'RAM', '8GB LPDDR5',
    'Armazenamento', '128GB UFS 3.1',
    'Câmara Principal', '50MP + 12MP Ultra',
    'Câmara Frontal', '10.8MP',
    'Bateria', '4355 mAh',
    'Sistema Operativo', 'Android 13',
    '5G', 'Sim',
    'Resistência', 'IP68',
    'Carregamento', '30W Fast'
) WHERE id = 8;

-- ID 9: Xiaomi Redmi Note 13 Pro 256GB
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.67" AMOLED',
    'Resolução', '2712 x 1220 pixels (120Hz)',
    'Processador', 'Snapdragon 7s Gen 2',
    'RAM', '8GB',
    'Armazenamento', '256GB (expansível até 1TB)',
    'Câmara Principal', '200MP + 8MP Ultra + 2MP Macro',
    'Câmara Frontal', '16MP',
    'Bateria', '5100 mAh',
    'Sistema Operativo', 'Android 13 / MIUI 14',
    '5G', 'Sim',
    'Resistência', 'IP54',
    'Carregamento', '67W Turbo'
) WHERE id = 9;

-- =====================================================
-- LAPTOPS (4 produtos faltantes)
-- =====================================================

-- ID 13: Lenovo ThinkPad X1 Carbon Gen 11
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '14" WUXGA IPS',
    'Resolução', '1920 x 1200 pixels',
    'Processador', 'Intel Core i7-1365U (vPro)',
    'RAM', '16GB LPDDR5',
    'Armazenamento', '512GB SSD PCIe 4.0',
    'Gráficos', 'Intel Iris Xe',
    'Bateria', '57Wh (até 12h)',
    'Sistema Operativo', 'Windows 11 Pro',
    'Peso', '1.12 kg',
    'Conectividade', 'Wi-Fi 6E, Bluetooth 5.2',
    'Portas', '2x Thunderbolt 4, 2x USB-A, HDMI 2.0',
    'Segurança', 'TPM 2.0, Leitor digital',
    'Certificação', 'MIL-STD-810H'
) WHERE id = 13;

-- ID 14: HP Pavilion 15 i5
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '15.6" FHD IPS',
    'Resolução', '1920 x 1080 pixels',
    'Processador', 'Intel Core i5-1235U',
    'RAM', '8GB DDR4',
    'Armazenamento', '512GB SSD PCIe',
    'Gráficos', 'Intel Iris Xe',
    'Bateria', '41Wh (até 7h)',
    'Sistema Operativo', 'Windows 11 Home',
    'Peso', '1.75 kg',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.2',
    'Portas', '1x USB-C, 2x USB-A, HDMI 1.4, Jack 3.5mm',
    'Webcam', 'HP TrueVision HD',
    'Audio', 'B&O Dual Speakers'
) WHERE id = 14;

-- ID 15: ASUS ZenBook 14 OLED
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '14" OLED 2.8K',
    'Resolução', '2880 x 1800 pixels (90Hz)',
    'Processador', 'Intel Core i7-13700H',
    'RAM', '16GB LPDDR5',
    'Armazenamento', '512GB SSD PCIe 4.0',
    'Gráficos', 'Intel Iris Xe',
    'Bateria', '75Wh (até 18h)',
    'Sistema Operativo', 'Windows 11 Home',
    'Peso', '1.39 kg',
    'Conectividade', 'Wi-Fi 6E, Bluetooth 5.3',
    'Portas', '1x Thunderbolt 4, 2x USB-A, HDMI 2.1, MicroSD',
    'Cor', 'OLED Pantone Validated',
    'Certificação', 'VESA DisplayHDR 500 True Black'
) WHERE id = 15;

-- ID 16: MSI GF63 Thin i5 RTX 4050
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '15.6" FHD IPS',
    'Resolução', '1920 x 1080 pixels (144Hz)',
    'Processador', 'Intel Core i5-12450H',
    'RAM', '16GB DDR4',
    'Armazenamento', '512GB SSD NVMe',
    'Gráficos', 'NVIDIA RTX 4050 6GB GDDR6',
    'Bateria', '51Wh (até 5h)',
    'Sistema Operativo', 'Windows 11 Home',
    'Peso', '1.86 kg',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.2',
    'Portas', '1x USB-C, 3x USB-A, HDMI 2.1, RJ45',
    'Teclado', 'Retroiluminado Vermelho',
    'Audio', 'Nahimic Audio Enhancer'
) WHERE id = 16;

-- =====================================================
-- TABLETS (3 produtos faltantes)
-- =====================================================

-- ID 19: Samsung Galaxy Tab S9 Ultra 512GB
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '14.6" Dynamic AMOLED 2X',
    'Resolução', '2960 x 1848 pixels (120Hz)',
    'Processador', 'Snapdragon 8 Gen 2',
    'RAM', '12GB',
    'Armazenamento', '512GB (expansível até 1TB)',
    'Câmara Principal', 'Dual 13MP + 8MP Ultra',
    'Câmara Frontal', 'Dual 12MP Ultra',
    'Bateria', '11200 mAh',
    'Sistema Operativo', 'Android 13 / One UI 5.1',
    'S Pen', 'Incluída (latência 2.8ms)',
    'Resistência', 'IP68',
    'Conectividade', '5G, Wi-Fi 6E, Bluetooth 5.3',
    'Audio', 'Quad AKG Speakers'
) WHERE id = 19;

-- ID 20: Samsung Galaxy Tab A8 64GB
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '10.5" TFT LCD',
    'Resolução', '1920 x 1200 pixels',
    'Processador', 'Unisoc Tiger T618',
    'RAM', '4GB',
    'Armazenamento', '64GB (expansível até 1TB)',
    'Câmara Principal', '8MP',
    'Câmara Frontal', '5MP',
    'Bateria', '7040 mAh',
    'Sistema Operativo', 'Android 13 / One UI 5',
    'Conectividade', 'Wi-Fi 5, Bluetooth 5.0',
    'Audio', 'Quad Speakers Dolby Atmos',
    'Peso', '508g',
    'Espessura', '6.9mm'
) WHERE id = 20;

-- ID 22: Xiaomi Pad 6 128GB
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '11" IPS LCD',
    'Resolução', '2880 x 1800 pixels (144Hz)',
    'Processador', 'Snapdragon 870',
    'RAM', '6GB',
    'Armazenamento', '128GB (expansível até 1TB)',
    'Câmara Principal', '13MP',
    'Câmara Frontal', '8MP',
    'Bateria', '8840 mAh',
    'Sistema Operativo', 'Android 13 / MIUI 14 for Pad',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.2',
    'Audio', 'Quad Speakers Dolby Atmos',
    'Peso', '490g',
    'Carregamento', '33W Fast'
) WHERE id = 22;

-- =====================================================
-- WEARABLES (3 produtos faltantes)
-- =====================================================

-- ID 24: Apple Watch SE 40mm GPS
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.57" OLED Retina',
    'Resolução', '324 x 394 pixels',
    'Processador', 'Apple S8 SiP',
    'Armazenamento', '32GB',
    'Sensores', 'Frequência cardíaca, acelerómetro, giroscópio',
    'Resistência', 'WR50 (50m)',
    'GPS', 'GPS + GLONASS + Galileo + QZSS',
    'Conectividade', 'Wi-Fi, Bluetooth 5.3',
    'Bateria', 'Até 18h',
    'Sistema Operativo', 'watchOS 10',
    'Compatibilidade', 'iPhone Xs ou posterior',
    'Caixa', 'Alumínio',
    'Funcionalidades', 'Detecção de quedas, SOS Emergência'
) WHERE id = 24;

-- ID 27: Xiaomi Watch S2 Pro
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.43" AMOLED',
    'Resolução', '466 x 466 pixels',
    'Bateria', 'Até 14 dias',
    'Sensores', 'Frequência cardíaca, SpO2, GPS dual-band',
    'Resistência', '5ATM',
    'GPS', 'Dual-band GNSS',
    'Conectividade', 'Bluetooth 5.2',
    'Sistema Operativo', 'HyperOS',
    'Modos Desportivos', '150+',
    'Compatibilidade', 'Android 6.0+ / iOS 12+',
    'Caixa', 'Liga de Alumínio',
    'Peso', '52g (sem bracelete)',
    'Funcionalidades', 'Alexa, monitorização sono, stress'
) WHERE id = 27;

-- ID 26: Garmin Forerunner 265
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.3" AMOLED',
    'Resolução', '416 x 416 pixels',
    'Bateria', 'Até 13 dias (modo smartwatch)',
    'Sensores', 'FC óptico, SpO2, altímetro barométrico',
    'Resistência', '5ATM',
    'GPS', 'Multi-GNSS (GPS, GLONASS, Galileo)',
    'Conectividade', 'Bluetooth, ANT+, Wi-Fi',
    'Memória Musical', 'Até 8GB',
    'Sistema Operativo', 'Garmin OS',
    'Modos Desportivos', '30+ perfis',
    'Compatibilidade', 'Android / iOS',
    'Caixa', 'Fibra de polímero reforçada',
    'Funcionalidades', 'Training Readiness, Body Battery, VO2 Max'
) WHERE id = 26;

-- =====================================================
-- TVS (2 produtos faltantes)
-- =====================================================

-- ID 31: Samsung QLED 55" Q60C
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '55" QLED 4K',
    'Resolução', '3840 x 2160 pixels',
    'Tecnologia', 'Quantum Dot, Dual LED',
    'Processador', 'Quantum Lite 4K',
    'HDR', 'HDR10+, HLG',
    'Taxa Atualização', '60Hz',
    'Sistema Operativo', 'Tizen OS',
    'Audio', '20W 2.0Ch',
    'Smart Features', 'Alexa, Google Assistant, Bixby',
    'Gaming', 'Motion Xcelerator',
    'Conectividade', '3x HDMI 2.0, 1x USB, Wi-Fi 5, Bluetooth 5.2',
    'Dimensões', '123.1 x 71.0 x 5.9 cm',
    'Peso', '11.9 kg (sem base)'
) WHERE id = 31;

-- ID 32: Philips OLED 55" 808
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '55" OLED 4K',
    'Resolução', '3840 x 2160 pixels',
    'Tecnologia', 'OLED EX, Ambilight 3 lados',
    'Processador', 'P5 Perfect Picture Engine',
    'HDR', 'HDR10+, Dolby Vision, HLG',
    'Taxa Atualização', '120Hz',
    'Sistema Operativo', 'Android TV (Google TV)',
    'Audio', '50W 2.1Ch Dolby Atmos',
    'Smart Features', 'Google Assistant, Alexa',
    'Gaming', 'HDMI 2.1, VRR, ALLM, FreeSync Premium',
    'Conectividade', '4x HDMI 2.1, 2x USB, Wi-Fi 5, Bluetooth 5.0',
    'Dimensões', '122.7 x 72.1 x 5.2 cm',
    'Peso', '17.8 kg (sem base)'
) WHERE id = 32;

-- =====================================================
-- AUDIO (4 produtos faltantes)
-- =====================================================

-- ID 35: Apple AirPods 3ª Gen
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'True Wireless Earbuds',
    'Driver', 'Driver dinâmico custom',
    'Áudio Espacial', 'Sim (com rastreamento dinâmico)',
    'Cancelamento Ruído', 'Não',
    'Resistência', 'IPX4 (resistente a suor e água)',
    'Bateria', 'Até 6h (30h com estojo)',
    'Carregamento', 'MagSafe, Lightning, Qi',
    'Chip', 'Apple H1',
    'Conectividade', 'Bluetooth 5.0',
    'Sensores', 'Acelerómetro, microfones beamforming',
    'Compatibilidade', 'iOS, macOS, watchOS',
    'Controlo', 'Sensor de força',
    'Peso', '4.28g (cada)'
) WHERE id = 35;

-- ID 37: JBL Charge 5
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Coluna Bluetooth Portátil',
    'Driver', '1x Woofer racetrack, 2x Tweeters',
    'Potência', '40W RMS',
    'Resposta Frequência', '60Hz - 20kHz',
    'Bateria', '7500mAh (até 20h)',
    'Resistência', 'IP67 (água e poeira)',
    'Conectividade', 'Bluetooth 5.1',
    'PartyBoost', 'Sim (ligar múltiplas colunas)',
    'PowerBank', 'Sim (USB-A)',
    'Peso', '960g',
    'Dimensões', '22.0 x 9.6 x 9.3 cm',
    'Cores', '8 opções disponíveis',
    'Extra', 'Alça de transporte integrada'
) WHERE id = 37;

-- ID 36: Sony WF-1000XM5
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'True Wireless Earbuds',
    'Driver', '8.4mm Dynamic Driver X',
    'Cancelamento Ruído', 'ANC HD Noise Cancelling Processor V2',
    'Áudio Espacial', '360 Reality Audio',
    'Resistência', 'IPX4',
    'Bateria', 'Até 8h ANC (24h total)',
    'Carregamento', 'USB-C, Qi wireless',
    'Chip', 'Integrated Processor V2',
    'Conectividade', 'Bluetooth 5.3 (LDAC, AAC)',
    'Sensores', 'Acelerómetro, giroscópio, detecção uso',
    'Compatibilidade', 'Android, iOS',
    'Controlo', 'Touch sensors',
    'Peso', '5.9g (cada)'
) WHERE id = 36;

-- ID 38: Sonos Era 300
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Coluna Smart Multiroom',
    'Drivers', '6 drivers (4 full-range, 2 tweeters)',
    'Áudio Espacial', 'Dolby Atmos, Spatial Audio',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.0, USB-C, Ethernet',
    'Sistema Operativo', 'Sonos S2',
    'Assistente Voz', 'Amazon Alexa, Sonos Voice Control',
    'AirPlay', 'AirPlay 2',
    'Trueplay', 'Sim (tuning automático)',
    'Peso', '4.5 kg',
    'Dimensões', '26 x 18.5 x 16 cm',
    'Audio', 'Som imersivo 360°',
    'Compatibilidade', 'iOS, Android, PC',
    'Extra', 'Botões touch, controlo por app'
) WHERE id = 38;

-- =====================================================
-- CONSOLAS (2 produtos faltantes)
-- =====================================================

-- ID 41: Sony PlayStation 5 Digital
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'AMD Zen 2 (8-core @ 3.5GHz)',
    'GPU', 'AMD RDNA 2 (10.28 TFLOPs)',
    'RAM', '16GB GDDR6',
    'Armazenamento', '825GB SSD NVMe (expansível)',
    'Resolução', 'Até 8K, 4K @ 120Hz',
    'Ray Tracing', 'Sim (hardware)',
    'Leitura Ótica', 'Não (apenas digital)',
    'Audio', 'Tempest 3D AudioTech',
    'Controlo', 'DualSense (haptic feedback)',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.1, Gigabit Ethernet',
    'Portas', '1x HDMI 2.1, 3x USB-A, 1x USB-C',
    'Dimensões', '39 x 9.2 x 26 cm',
    'Peso', '3.9 kg'
) WHERE id = 41;

-- ID 43: Microsoft Xbox Series S
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'AMD Zen 2 (8-core @ 3.6GHz)',
    'GPU', 'AMD RDNA 2 (4 TFLOPs)',
    'RAM', '10GB GDDR6',
    'Armazenamento', '512GB SSD NVMe (expansível)',
    'Resolução', 'Até 1440p @ 120Hz',
    'Ray Tracing', 'Sim',
    'Leitura Ótica', 'Não (apenas digital)',
    'Audio', 'Spatial Sound',
    'Controlo', 'Xbox Wireless Controller',
    'Conectividade', 'Wi-Fi 5, Bluetooth 5.1, Gigabit Ethernet',
    'Portas', '1x HDMI 2.1, 3x USB-A',
    'Dimensões', '27.5 x 15.1 x 6.35 cm',
    'Peso', '1.93 kg'
) WHERE id = 43;

-- =====================================================
-- FRIGORÍFICOS (2 produtos faltantes)
-- =====================================================

-- ID 46: LG GSX960NSVZ Side-by-Side
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Side-by-Side com Dispensador',
    'Capacidade Total', '601L (405L frigo + 196L congelador)',
    'Classe Energética', 'E',
    'Consumo Anual', '435 kWh',
    'Tecnologia', 'InstaView Door-in-Door, Linear Cooling',
    'No Frost', 'Total No Frost',
    'Dispensador', 'Água e gelo (cubed/crushed)',
    'Prateleiras', 'Vidro temperado',
    'Smart Features', 'Wi-Fi, LG ThinQ',
    'Dimensões', '91.2 x 179 x 73.8 cm',
    'Peso', '136 kg',
    'Nível Ruído', '39 dB',
    'Extra', 'Iluminação LED, Fresh Balancer'
) WHERE id = 46;

-- ID 47: Bosch KGN39VWEA Combinado
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Combinado (frigo em cima)',
    'Capacidade Total', '366L (279L frigo + 87L congelador)',
    'Classe Energética', 'C',
    'Consumo Anual', '219 kWh',
    'Tecnologia', 'VitaFresh, LowFrost',
    'No Frost', 'LowFrost (baixa formação gelo)',
    'Prateleiras', 'Vidro de segurança',
    'Gavetas', 'VitaFresh XXL',
    'Iluminação', 'LED',
    'Dimensões', '60 x 201 x 66 cm',
    'Peso', '82 kg',
    'Nível Ruído', '38 dB',
    'Extra', 'Alarme porta aberta, display LCD'
) WHERE id = 47;

-- =====================================================
-- MÁQUINAS DE LAVAR (2 produtos faltantes)
-- =====================================================

-- ID 49: LG F4WV709P1 9kg
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '9 kg',
    'Velocidade Centrifugação', '1400 rpm',
    'Classe Energética', 'A',
    'Consumo Anual', '171 kWh',
    'Consumo Água', '49L por ciclo',
    'Tecnologia', 'AI DD, Steam+, TurboWash 360',
    'Motor', 'Direct Drive Inverter (10 anos garantia)',
    'Programas', '14 programas',
    'Smart Features', 'Wi-Fi, LG ThinQ',
    'Dimensões', '60 x 85 x 56 cm',
    'Peso', '66 kg',
    'Nível Ruído', '72 dB (lavagem) / 74 dB (centrifugação)',
    'Extra', 'Tambor em aço inox, Add Item'
) WHERE id = 49;

-- ID 50: Bosch WAU28S80ES 8kg
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '8 kg',
    'Velocidade Centrifugação', '1400 rpm',
    'Classe Energética', 'A',
    'Consumo Anual', '152 kWh',
    'Consumo Água', '42L por ciclo',
    'Tecnologia', 'EcoSilence Drive, ActiveWater Plus',
    'Motor', 'EcoSilence (10 anos garantia)',
    'Programas', '15 programas',
    'Display', 'LED',
    'Dimensões', '59.8 x 84.8 x 59 cm',
    'Peso', '71 kg',
    'Nível Ruído', '47 dB (lavagem) / 71 dB (centrifugação)',
    'Extra', 'SpeedPerfect, Reload'
) WHERE id = 50;

-- =====================================================
-- MICRO-ONDAS (2 produtos faltantes)
-- =====================================================

-- ID 52: LG MS2043DB 20L
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '20L',
    'Potência', '700W',
    'Tipo', 'Solo (free-standing)',
    'Tecnologia', 'I-Wave (aquecimento uniforme)',
    'Níveis Potência', '5 níveis',
    'Prato', '24.5cm giratório',
    'Programas Auto', '6 programas',
    'Display', 'LED',
    'Cor', 'Preto',
    'Dimensões', '44 x 25.9 x 33 cm',
    'Dimensões Internas', '30.6 x 20.8 x 31.2 cm',
    'Peso', '11.2 kg',
    'Extra', 'Descongelação por peso/tempo'
) WHERE id = 52;

-- ID 53: Bosch BFL524MS0 Encastre
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '20L',
    'Potência', '800W',
    'Tipo', 'Encastre',
    'Tecnologia', 'AutoPilot 7 (programas automáticos)',
    'Níveis Potência', '5 níveis',
    'Prato', '25.5cm giratório',
    'Display', 'TFT Touch Control',
    'Acabamento', 'Aço inoxidável',
    'Dimensões', '59.4 x 38.2 x 31.5 cm',
    'Dimensões Nicho', '56-56.2 x 36 x 55 cm',
    'Peso', '15 kg',
    'Extra', 'Função memória, bloqueio crianças'
) WHERE id = 53;

-- =====================================================
-- ASPIRADORES (TODOS TÊM ESPECIFICAÇÕES)
-- =====================================================

-- =====================================================
-- AR CONDICIONADO (3 produtos faltantes)
-- =====================================================

-- ID 59: LG Artcool 9000 BTU Inverter
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '9000 BTU',
    'Tipo', 'Split Inverter',
    'Classe Energética', 'A+++',
    'SEER', '8.5',
    'SCOP', '4.6',
    'Tecnologia', 'Dual Inverter, Plasmaster Ionizer',
    'Gás Refrigerante', 'R32',
    'Níveis Velocidade', '4 velocidades',
    'Modos', 'Arrefecimento, Aquecimento, Desumidificação, Ventilação',
    'Smart Features', 'Wi-Fi, LG ThinQ',
    'Nível Ruído', '19 dB (interior)',
    'Dimensões Unidade Interior', '99.5 x 21 x 30.8 cm',
    'Garantia', '3 anos (10 anos compressor)'
) WHERE id = 59;

-- ID 61: Mitsubishi MSZ-LN35VGW
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '12000 BTU',
    'Tipo', 'Split Inverter',
    'Classe Energética', 'A+++',
    'SEER', '9.0',
    'SCOP', '5.1',
    'Tecnologia', 'Hyper-Heating, 3D i-see Sensor, Plasma Quad Plus',
    'Gás Refrigerante', 'R32',
    'Níveis Velocidade', '4 velocidades + automático',
    'Modos', 'Arrefecimento, Aquecimento, Desumidificação',
    'Smart Features', 'Wi-Fi, MELCloud',
    'Nível Ruído', '19 dB (interior)',
    'Dimensões Unidade Interior', '89.8 x 29.9 x 23.3 cm',
    'Garantia', '5 anos'
) WHERE id = 61;

-- ID 62: Fujitsu ASYG12KPCA
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '12000 BTU',
    'Tipo', 'Split Inverter',
    'Classe Energética', 'A++',
    'SEER', '6.8',
    'SCOP', '4.0',
    'Tecnologia', 'Economy, Human Sensor, Powerful Mode',
    'Gás Refrigerante', 'R32',
    'Níveis Velocidade', '3 velocidades + automático',
    'Modos', 'Arrefecimento, Aquecimento, Desumidificação, Ventilação',
    'Filtros', 'Duplo filtro desodorizante',
    'Nível Ruído', '22 dB (interior)',
    'Dimensões Unidade Interior', '78 x 28.6 x 21.5 cm',
    'Garantia', '3 anos'
) WHERE id = 62;

-- =====================================================
-- MÁQUINAS DE CAFÉ (3 produtos faltantes)
-- =====================================================

-- ID 64: Nespresso Essenza Mini
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Máquina de cápsulas',
    'Sistema', 'Nespresso Original',
    'Pressão', '19 bar',
    'Depósito Água', '0.6L',
    'Aquecimento', '30 segundos',
    'Tamanhos Café', '2 opções (Espresso 40ml, Lungo 110ml)',
    'Cápsulas Usadas', 'Capacidade 6 cápsulas',
    'Potência', '1260W',
    'Auto-Desligar', 'Após 9 minutos',
    'Dimensões', '33 x 20.4 x 8.4 cm',
    'Peso', '2.3 kg',
    'Cores', 'Preto, Branco, Vermelho',
    'Extra', 'Compacta, ideal para espaços pequenos'
) WHERE id = 64;

-- ID 66: Nespresso Vertuo Next
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Máquina de cápsulas',
    'Sistema', 'Nespresso Vertuo',
    'Tecnologia', 'Centrifusion (até 7000 rpm)',
    'Depósito Água', '1.1L',
    'Aquecimento', '30 segundos',
    'Tamanhos Café', '5 opções (40ml, 80ml, 150ml, 230ml, 414ml)',
    'Cápsulas Usadas', 'Capacidade 10 cápsulas',
    'Reconhecimento', 'Código de barras automático',
    'Conectividade', 'Bluetooth (app Nespresso)',
    'Potência', '1500W',
    'Dimensões', '37.4 x 14.2 x 29.2 cm',
    'Peso', '4 kg',
    'Extra', 'Produz crema natural'
) WHERE id = 66;

-- ID 65: Philips LatteGo 5400
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Máquina automática',
    'Sistema', 'Grãos a chávena',
    'Moinho', 'Cerâmico 12 níveis',
    'Pressão', '15 bar',
    'Depósito Água', '1.8L',
    'Depósito Grãos', '275g',
    'Depósito Leite', 'LatteGo (260ml, sem tubos)',
    'Receitas', '12 bebidas (personalizáveis)',
    'Display', 'TFT touchscreen colorido',
    'Perfis Utilizador', 'Até 4 perfis',
    'Smart Features', 'App HomeID',
    'Potência', '1500W',
    'Dimensões', '37.1 x 43.3 x 24.6 cm',
    'Extra', 'AquaClean (5000 chávenas sem descalcificar)'
) WHERE id = 65;

-- =====================================================
-- CONSULTAS DE VERIFICAÇÃO
-- =====================================================

-- Verificar quantos produtos agora têm especificações
SELECT 
    'Produtos com especificações' as status,
    COUNT(*) as total
FROM produtos 
WHERE especificacoes IS NOT NULL 
  AND especificacoes != '' 
  AND especificacoes != 'null';

-- Verificar quantos produtos ainda não têm especificações
SELECT 
    'Produtos SEM especificações' as status,
    COUNT(*) as total
FROM produtos 
WHERE especificacoes IS NULL 
  OR especificacoes = '' 
  OR especificacoes = 'null';

-- Listar produtos sem especificações (se ainda houver)
SELECT id, marca, modelo, categoria
FROM produtos 
WHERE especificacoes IS NULL 
  OR especificacoes = '' 
  OR especificacoes = 'null'
ORDER BY categoria, id;

-- Verificar total de produtos por categoria com especificações
SELECT 
    categoria,
    COUNT(*) as total,
    SUM(CASE WHEN especificacoes IS NOT NULL AND especificacoes != '' AND especificacoes != 'null' THEN 1 ELSE 0 END) as com_specs
FROM produtos
GROUP BY categoria
ORDER BY categoria;
