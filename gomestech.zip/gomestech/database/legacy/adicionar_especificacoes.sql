-- =====================================================
-- ADICIONAR ESPECIFICAÇÕES TÉCNICAS AOS PRODUTOS
-- =====================================================

USE gomestech;

-- Smartphones
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.1" Super Retina XDR OLED',
    'Processador', 'A17 Pro Chip',
    'RAM', '8GB',
    'Armazenamento', '256GB',
    'Câmara Principal', '48MP + 12MP + 12MP',
    'Câmara Frontal', '12MP TrueDepth',
    'Bateria', '3279 mAh',
    'Sistema Operativo', 'iOS 17',
    '5G', 'Sim',
    'Cor', 'Titânio Natural'
) WHERE sku = 'SM-001';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.8" Dynamic AMOLED 2X',
    'Processador', 'Snapdragon 8 Gen 3',
    'RAM', '12GB',
    'Armazenamento', '512GB',
    'Câmara Principal', '200MP + 50MP + 12MP + 10MP',
    'Câmara Frontal', '12MP',
    'Bateria', '5000 mAh',
    'Sistema Operativo', 'Android 14',
    '5G', 'Sim',
    'S Pen', 'Incluída'
) WHERE sku = 'SM-002';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.7" LTPO OLED 120Hz',
    'Processador', 'Google Tensor G3',
    'RAM', '12GB',
    'Armazenamento', '256GB',
    'Câmara Principal', '50MP + 48MP + 48MP',
    'Câmara Frontal', '10.5MP',
    'Bateria', '5050 mAh',
    'Sistema Operativo', 'Android 14',
    '5G', 'Sim',
    'Carregamento', '30W Rápido'
) WHERE sku = 'SM-003';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.1" Super Retina XDR',
    'Processador', 'A16 Bionic',
    'RAM', '6GB',
    'Armazenamento', '128GB',
    'Câmara Principal', '12MP + 12MP',
    'Câmara Frontal', '12MP',
    'Bateria', '3279 mAh',
    'Sistema Operativo', 'iOS 17',
    '5G', 'Sim',
    'Face ID', 'Sim'
) WHERE sku = 'SM-004';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '6.1" Dynamic AMOLED 2X',
    'Processador', 'Snapdragon 8 Gen 2',
    'RAM', '8GB',
    'Armazenamento', '256GB',
    'Câmara Principal', '50MP + 12MP + 10MP',
    'Câmara Frontal', '12MP',
    'Bateria', '3900 mAh',
    'Sistema Operativo', 'Android 13',
    '5G', 'Sim',
    'Resistência', 'IP68'
) WHERE sku = 'SM-005';

-- Laptops
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '13.6" Liquid Retina',
    'Processador', 'Apple M2',
    'RAM', '8GB Unified',
    'Armazenamento', '256GB SSD',
    'GPU', '8-core GPU',
    'Bateria', 'Até 18 horas',
    'Peso', '1.24 kg',
    'Sistema Operativo', 'macOS Sonoma',
    'Portas', '2x Thunderbolt 4, MagSafe 3',
    'Câmara', '1080p FaceTime HD'
) WHERE sku = 'LP-001';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '14.2" Liquid Retina XDR',
    'Processador', 'Apple M3 Pro',
    'RAM', '18GB Unified',
    'Armazenamento', '512GB SSD',
    'GPU', '14-core GPU',
    'Bateria', 'Até 18 horas',
    'Peso', '1.55 kg',
    'Sistema Operativo', 'macOS Sonoma',
    'Portas', '3x Thunderbolt 4, HDMI, SD Card',
    'Câmara', '1080p FaceTime HD'
) WHERE sku = 'LP-002';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '13.4" FHD+ InfinityEdge',
    'Processador', 'Intel Core i7-1355U',
    'RAM', '16GB LPDDR5',
    'Armazenamento', '512GB SSD NVMe',
    'GPU', 'Intel Iris Xe',
    'Bateria', 'Até 12 horas',
    'Peso', '1.17 kg',
    'Sistema Operativo', 'Windows 11 Pro',
    'Portas', '2x Thunderbolt 4',
    'Câmara', '720p HD'
) WHERE sku = 'LP-003';

-- Tablets
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '11" Liquid Retina',
    'Processador', 'Apple M2',
    'RAM', '8GB',
    'Armazenamento', '128GB',
    'Câmara Principal', '12MP Wide',
    'Câmara Frontal', '12MP Ultra Wide',
    'Bateria', 'Até 10 horas',
    'Peso', '462g',
    'Sistema Operativo', 'iPadOS 17',
    'Conectividade', 'Wi-Fi 6E, 5G (opcional)'
) WHERE sku = 'TB-001';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '11" Liquid Retina',
    'Processador', 'Apple M4',
    'RAM', '8GB',
    'Armazenamento', '256GB',
    'Câmara Principal', '12MP Wide',
    'Câmara Frontal', '12MP TrueDepth',
    'Bateria', 'Até 10 horas',
    'Peso', '444g',
    'Sistema Operativo', 'iPadOS 17',
    'Face ID', 'Sim',
    'ProMotion', '120Hz'
) WHERE sku = 'TB-002';

-- Wearables
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.9" Always-On Retina',
    'Processador', 'S9 SiP',
    'Resistência', 'WR50 + IP6X',
    'Sensores', 'ECG, SpO2, Temperatura',
    'Bateria', 'Até 18 horas',
    'GPS', 'Dupla frequência',
    'Conectividade', 'Bluetooth 5.3, Wi-Fi',
    'Sistema Operativo', 'watchOS 10',
    'Materiais', 'Alumínio',
    'Cores', 'Várias opções'
) WHERE sku = 'WR-001';

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Ecrã', '1.5" AMOLED Always-On',
    'Processador', 'Exynos W930',
    'Resistência', '5ATM + IP68',
    'Sensores', 'BIA, ECG, PPG',
    'Bateria', 'Até 40 horas',
    'GPS', 'Sim',
    'Conectividade', 'Bluetooth 5.3, Wi-Fi',
    'Sistema Operativo', 'Wear OS 4',
    'Materiais', 'Aço Inoxidável',
    'Bisel Rotativo', 'Sim'
) WHERE sku = 'WR-003';

-- TVs
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tamanho', '55 polegadas',
    'Tecnologia', 'QD-OLED 4K',
    'Resolução', '3840 x 2160',
    'Taxa Atualização', '120Hz',
    'HDR', 'Dolby Vision, HDR10+',
    'Smart TV', 'Tizen OS',
    'Som', 'Dolby Atmos',
    'Portas HDMI', '4x HDMI 2.1',
    'Gaming', 'VRR, ALLM',
    'Assistente', 'Bixby, Alexa'
) WHERE marca = 'Samsung' AND modelo LIKE '%OLED%' AND categoria = 'TVs' LIMIT 1;

-- Consolas
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'AMD Zen 2 8-core',
    'GPU', 'AMD RDNA 2 10.28 TFLOPs',
    'RAM', '16GB GDDR6',
    'Armazenamento', '825GB SSD NVMe',
    'Resolução', 'Até 8K',
    'Taxa Frames', 'Até 120fps',
    'Ray Tracing', 'Sim',
    'Leitor', 'Ultra HD Blu-ray',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.1',
    'Portas', 'HDMI 2.1, USB-C, USB-A'
) WHERE marca = 'Sony' AND modelo LIKE '%PS5%' AND categoria = 'Consolas' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'CPU', 'AMD Zen 2 8-core',
    'GPU', 'AMD RDNA 2 12 TFLOPs',
    'RAM', '16GB GDDR6',
    'Armazenamento', '1TB SSD NVMe',
    'Resolução', 'Até 8K',
    'Taxa Frames', 'Até 120fps',
    'Ray Tracing', 'Sim',
    'Leitor', 'Ultra HD Blu-ray',
    'Conectividade', 'Wi-Fi 6, Bluetooth 5.1',
    'Quick Resume', 'Sim'
) WHERE marca = 'Microsoft' AND modelo LIKE '%Series X%' LIMIT 1;

-- Audio
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Over-ear sem fios',
    'Cancelamento Ruído', 'Ativo Adaptativo',
    'Driver', '40mm dinâmico',
    'Bateria', 'Até 24 horas',
    'Carregamento', 'USB-C',
    'Bluetooth', '5.3',
    'Codecs', 'AAC, aptX',
    'Controlos', 'Tácteis',
    'Resistência', 'IPX4',
    'Cores', 'Preto, Prata'
) WHERE marca = 'Bose' AND categoria = 'Audio' LIMIT 1;

-- Eletrodomésticos
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '617 Litros',
    'Classe Energética', 'A++',
    'Tecnologia', 'Family Hub',
    'Ecrã', '21.5" Touch',
    'NoFrost', 'Sim',
    'Dispensador', 'Água e Gelo',
    'Dimensões', '912x716x1853mm',
    'Peso', '155kg',
    'Cor', 'Aço Inoxidável',
    'Smart', 'Wi-Fi, App SmartThings'
) WHERE categoria = 'Frigoríficos' AND marca = 'Samsung' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Capacidade', '9kg Lavagem / 6kg Secagem',
    'Classe Energética', 'A',
    'Velocidade', '1400 RPM',
    'Tecnologia', 'AI DD',
    'Vapor', 'TurboSteam',
    'Programas', '14',
    'Display', 'LED Touch',
    'Dimensões', '600x640x850mm',
    'Nível Ruído', '72 dB',
    'Cor', 'Branco'
) WHERE categoria = 'Máquinas de Lavar' AND marca = 'LG' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência', '850W',
    'Capacidade', '23 Litros',
    'Tipo', 'Combinado',
    'Grill', '1000W',
    'Níveis Potência', '5',
    'Display', 'LED',
    'Interior', 'Cerâmica',
    'Dimensões', '460x280x345mm',
    'Cor', 'Preto',
    'Funções', 'Descongelação, Auto'
) WHERE categoria = 'Micro-ondas' AND marca = 'Samsung' LIMIT 1;

UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência', '230W',
    'Sucção', '230 AW',
    'Tipo', 'Sem fios',
    'Autonomia', 'Até 60 minutos',
    'Carregamento', '4.5 horas',
    'Depósito', '0.76L',
    'Peso', '3kg',
    'Filtração', 'HEPA avançado',
    'Display', 'LCD',
    'Acessórios', '8 incluídos'
) WHERE categoria = 'Aspiradores' AND marca = 'Dyson' LIMIT 1;

-- Ar Condicionado
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Potência Refrigeração', '3.5 kW (12000 BTU)',
    'Potência Aquecimento', '4.0 kW',
    'Classe Energética', 'A+++',
    'Tecnologia', 'Inverter',
    'Tipo', 'Split',
    'Nível Ruído', '19 dB',
    'Controlo', 'WiFi, App',
    'Modo Noturno', 'Sim',
    'Filtros', 'Plasma Quad Plus',
    'Garantia', '5 anos compressor'
) WHERE categoria = 'Ar Condicionado' AND marca = 'Daikin' LIMIT 1;

-- Máquinas de Café
UPDATE produtos SET especificacoes = JSON_OBJECT(
    'Tipo', 'Automática',
    'Pressão', '15 bar',
    'Depósito Água', '1.8L',
    'Depósito Grãos', '250g',
    'Moinho', 'Aço Inox',
    'Display', 'TFT a cores',
    'Bebidas', '13 receitas',
    'Vaporizador', 'LatteCrema',
    'Potência', '1450W',
    'App', 'Coffee Link'
) WHERE categoria = 'Máquinas de Café' AND marca = 'De''Longhi' LIMIT 1;

SELECT '✅ Especificações adicionadas a vários produtos!' AS status;
