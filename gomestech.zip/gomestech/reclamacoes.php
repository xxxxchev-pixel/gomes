<?php
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Livro de Reclamações - GomesTech</title>
  <link rel="stylesheet" href="css/gomestech.css" />
</head>
<body>
  <?php require_once __DIR__ . '/includes/header.php'; ?>

  <main style="max-width: 1100px; margin: 0 auto; padding: var(--space-2xl) var(--space-lg);">
    <h1 style="margin-bottom: var(--space-lg);">Livro de Reclamações</h1>
    <p style="color: var(--text-secondary); line-height: 1.7;">
      Esta página destina-se a disponibilizar informações sobre o Livro de Reclamações.
      Se pretende adicionar o link oficial, indique o URL e eu atualizo o botão/link.
    </p>
  </main>

  <?php $baseUrl = rtrim(BASE_URL, '/'); ?>
  <footer class="footer">
    <div class="footer-container">
      <div class="footer-section">
        <h3>GOMESTECH</h3>
        <p>A tua loja online de tecnologia com os melhores preços e atendimento de qualidade.</p>
      </div>
      <div class="footer-section">
        <h3>COMPRAS</h3>
        <ul>
          <li><a href="<?= $baseUrl ?>/catalogo.php">Catálogo</a></li>
          <li><a href="<?= $baseUrl ?>/catalogo.php?cat=Smartphones">Smartphones</a></li>
          <li><a href="<?= $baseUrl ?>/catalogo.php?cat=Laptops">Laptops</a></li>
          <li><a href="<?= $baseUrl ?>/comparacao.php">Comparar Produtos</a></li>
        </ul>
      </div>
      <div class="footer-section">
        <h3>SUPORTE</h3>
        <ul>
          <li><a href="<?= $baseUrl ?>/ajuda.php">Ajuda ao Cliente</a></li>
          <li><a href="<?= $baseUrl ?>/ajuda.php">Entregas e Devoluções</a></li>
          <li><a href="<?= $baseUrl ?>/ajuda.php">Garantias</a></li>
          <li><a href="<?= $baseUrl ?>/ajuda.php">Contacte-nos</a></li>
        </ul>
      </div>
      <div class="footer-section">
        <h3>LEGAL</h3>
        <ul>
          <li><a href="<?= $baseUrl ?>/termos.php">Termos e Condições</a></li>
          <li><a href="<?= $baseUrl ?>/privacidade.php">Política de Privacidade</a></li>
          <li><a href="<?= $baseUrl ?>/reclamacoes.php">Livro de Reclamações</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; <?= date('Y') ?> GomesTech. Todos os direitos reservados.</p>
    </div>
  </footer>

  <script src="js/main.js"></script>
</body>
</html>
