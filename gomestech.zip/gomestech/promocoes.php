<?php
// Redirecionar para catálogo com filtro de promoções
header('Location: catalogo.php?filtro=promocoes');
exit;
