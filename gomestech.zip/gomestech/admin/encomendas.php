<?php
// Gestão de Encomendas - Admin Panel
if (!isset($mysqli) || !$mysqli) {
    $mysqli = db_connect();
}

// Processar ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_status'])) {
        $order_id = intval($_POST['order_id']);
        $new_status = $_POST['status'];
        $old_status = $_POST['old_status'] ?? '';
        $tracking_code = trim($_POST['tracking_code'] ?? '');
        
        $stmt = $mysqli->prepare('UPDATE encomendas SET status = ?, tracking_code = ? WHERE id = ?');
        $stmt->bind_param('ssi', $new_status, $tracking_code, $order_id);
        $stmt->execute();
        $stmt->close();
        
        // Reduzir stock se o estado mudou para "entregue"
        if ($new_status === 'entregue' && $old_status !== 'entregue') {
            // Buscar itens da encomenda
            $items_query = $mysqli->prepare('SELECT produto_id, quantity FROM encomenda_itens WHERE encomenda_id = ?');
            $items_query->bind_param('i', $order_id);
            $items_query->execute();
            $items_result = $items_query->get_result();
            
            // Reduzir stock de cada produto
            while ($item = $items_result->fetch_assoc()) {
                $update_stock = $mysqli->prepare('UPDATE produtos SET stock = stock - ? WHERE id = ? AND stock >= ?');
                $update_stock->bind_param('iii', $item['quantity'], $item['produto_id'], $item['quantity']);
                $update_stock->execute();
                $update_stock->close();
            }
            
            $items_query->close();
            echo '<div class="alert alert-success">Estado atualizado e stock reduzido!</div>';
        } else {
            echo '<div class="alert alert-success">Estado da encomenda atualizado!</div>';
        }
    }
    
    if (isset($_POST['add_note'])) {
        $order_id = intval($_POST['order_id']);
        $note = trim($_POST['note']);
        
        $stmt = $mysqli->prepare('UPDATE encomendas SET notes = CONCAT(COALESCE(notes, ""), ?, "\n---\n") WHERE id = ?');
        $timestamp_note = "[" . date('Y-m-d H:i:s') . "] " . $note;
        $stmt->bind_param('si', $timestamp_note, $order_id);
        $stmt->execute();
        $stmt->close();
        
        echo '<div class="alert alert-success">Nota adicionada!</div>';
    }
    
    if (isset($_POST['cancel_order'])) {
        $order_id = intval($_POST['order_id']);
        $reason = trim($_POST['cancel_reason'] ?? 'Cancelado pelo administrador');
        
        $stmt = $mysqli->prepare('UPDATE encomendas SET status = "cancelada", notes = CONCAT(COALESCE(notes, ""), ?) WHERE id = ?');
        $cancel_note = "[" . date('Y-m-d H:i:s') . "] CANCELADO: " . $reason . "\n---\n";
        $stmt->bind_param('si', $cancel_note, $order_id);
        $stmt->execute();
        $stmt->close();
        
        echo '<div class="alert alert-warning">Encomenda cancelada!</div>';
    }
}

// Filtros
$filtro_status = $_GET['filtro_status'] ?? '';
$filtro_metodo = $_GET['filtro_metodo'] ?? '';
$pesquisa = trim($_GET['pesquisa'] ?? '');

// Construir query
$where = ['1=1'];
$params = [];
$types = '';

if ($filtro_status) {
    $where[] = 'e.status = ?';
    $params[] = $filtro_status;
    $types .= 's';
}

if ($filtro_metodo) {
    $where[] = 'e.payment_method = ?';
    $params[] = $filtro_metodo;
    $types .= 's';
}

if ($pesquisa) {
    $where[] = '(e.order_number LIKE ? OR u.nome LIKE ? OR u.email LIKE ?)';
    $search_param = '%' . $pesquisa . '%';
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= 'sss';
}

$sql = 'SELECT e.*, u.nome as user_nome, u.email as user_email 
        FROM encomendas e 
        JOIN users u ON e.user_id = u.id 
        WHERE ' . implode(' AND ', $where) . ' 
        ORDER BY e.created_at DESC';

$stmt = $mysqli->prepare($sql);
if ($stmt && !empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$encomendas = [];
while ($row = $result->fetch_assoc()) {
    $encomendas[] = $row;
}
$stmt->close();

// Estatísticas
$stats_query = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) as pendentes,
    SUM(CASE WHEN status = 'processando' THEN 1 ELSE 0 END) as processando,
    SUM(CASE WHEN status = 'enviada' THEN 1 ELSE 0 END) as enviadas,
    SUM(CASE WHEN status = 'entregue' THEN 1 ELSE 0 END) as entregues,
    SUM(CASE WHEN status = 'cancelada' THEN 1 ELSE 0 END) as canceladas,
    SUM(total) as valor_total
FROM encomendas";
$stats = $mysqli->query($stats_query)->fetch_assoc();
?>

<style>
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: var(--secondary-bg);
        border-radius: 12px;
        padding: 20px;
        text-align: center;
        border: 2px solid var(--border);
    }
    
    .stat-value {
        font-size: 32px;
        font-weight: 700;
        color: var(--primary);
        margin: 10px 0;
    }
    
    .stat-label {
        font-size: 14px;
        color: var(--text-muted);
        text-transform: uppercase;
        font-weight: 600;
    }
    
    .orders-table {
        width: 100%;
        border-collapse: collapse;
        background: var(--secondary-bg);
        border-radius: 12px;
        overflow: hidden;
    }
    
    .orders-table th {
        background: var(--primary);
        color: white;
        padding: 15px;
        text-align: left;
        font-weight: 600;
    }
    
    .orders-table td {
        padding: 15px;
        border-bottom: 1px solid var(--border);
    }
    
    .orders-table tr:hover {
        background: var(--bg);
    }
    
    .status-badge {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .status-pendente { background: #fff3cd; color: #856404; }
    .status-processando { background: #cce5ff; color: #004085; }
    .status-enviada { background: #d1ecf1; color: #0c5460; }
    .status-entregue { background: #d4edda; color: #155724; }
    .status-cancelada { background: #f8d7da; color: #721c24; }
    
    .order-details {
        display: none;
        padding: 20px;
        background: var(--bg);
        border-top: 2px solid var(--border);
    }
    
    .order-details.active {
        display: block;
    }
    
    .detail-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 20px;
    }
    
    .detail-section {
        background: var(--secondary-bg);
        padding: 20px;
        border-radius: 8px;
    }
    
    .detail-section h4 {
        margin: 0 0 15px 0;
        color: var(--primary);
    }
    
    .action-buttons {
        display: flex;
        gap: 10px;
        margin-top: 20px;
    }
</style>

<div style="padding: 20px;">
    <h2 style="margin-bottom: 30px;">Gestão de Encomendas</h2>
    
    <!-- Estatísticas -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-label">Total Encomendas</div>
            <div class="stat-value"><?= $stats['total'] ?? 0 ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Pendentes</div>
            <div class="stat-value" style="color: #ffc107;"><?= $stats['pendentes'] ?? 0 ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Processando</div>
            <div class="stat-value" style="color: #2196f3;"><?= $stats['processando'] ?? 0 ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Enviadas</div>
            <div class="stat-value" style="color: #17a2b8;"><?= $stats['enviadas'] ?? 0 ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Entregues</div>
            <div class="stat-value" style="color: #28a745;"><?= $stats['entregues'] ?? 0 ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Valor Total</div>
            <div class="stat-value" style="color: #28a745;">€<?= number_format($stats['valor_total'] ?? 0, 2, ',', '.') ?></div>
        </div>
    </div>
    
    <!-- Filtros -->
    <div style="background: var(--secondary-bg); padding: 20px; border-radius: 12px; margin-bottom: 20px;">
        <form method="GET" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
            <input type="hidden" name="page" value="encomendas">
            
            <div>
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Pesquisar</label>
                <input type="text" name="pesquisa" value="<?= htmlspecialchars($pesquisa) ?>" placeholder="Nº encomenda, cliente..." style="width: 100%; padding: 10px; border: 2px solid var(--border); border-radius: 8px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Estado</label>
                <select name="filtro_status" style="width: 100%; padding: 10px; border: 2px solid var(--border); border-radius: 8px;">
                    <option value="">Todos</option>
                    <option value="pendente" <?= $filtro_status === 'pendente' ? 'selected' : '' ?>>Pendente</option>
                    <option value="processando" <?= $filtro_status === 'processando' ? 'selected' : '' ?>>Processando</option>
                    <option value="enviada" <?= $filtro_status === 'enviada' ? 'selected' : '' ?>>Enviada</option>
                    <option value="entregue" <?= $filtro_status === 'entregue' ? 'selected' : '' ?>>Entregue</option>
                    <option value="cancelada" <?= $filtro_status === 'cancelada' ? 'selected' : '' ?>>Cancelada</option>
                </select>
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Pagamento</label>
                <select name="filtro_metodo" style="width: 100%; padding: 10px; border: 2px solid var(--border); border-radius: 8px;">
                    <option value="">Todos</option>
                    <option value="Multibanco" <?= $filtro_metodo === 'Multibanco' ? 'selected' : '' ?>>Multibanco</option>
                    <option value="MB WAY" <?= $filtro_metodo === 'MB WAY' ? 'selected' : '' ?>>MB WAY</option>
                    <option value="Cartão de Crédito" <?= $filtro_metodo === 'Cartão de Crédito' ? 'selected' : '' ?>>Cartão</option>
                    <option value="PayPal" <?= $filtro_metodo === 'PayPal' ? 'selected' : '' ?>>PayPal</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary" style="padding: 10px 20px;">Filtrar</button>
        </form>
    </div>
    
    <!-- Tabela de Encomendas -->
    <table class="orders-table">
        <thead>
            <tr>
                <th>Nº Encomenda</th>
                <th>Cliente</th>
                <th>Data</th>
                <th>Total</th>
                <th>Pagamento</th>
                <th>Estado</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($encomendas as $enc): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($enc['order_number']) ?></strong></td>
                    <td>
                        <?= htmlspecialchars($enc['user_nome']) ?><br>
                        <small style="color: var(--text-muted);"><?= htmlspecialchars($enc['user_email']) ?></small>
                    </td>
                    <td><?= date('d/m/Y H:i', strtotime($enc['created_at'])) ?></td>
                    <td><strong>€<?= number_format($enc['total'], 2, ',', '.') ?></strong></td>
                    <td><?= htmlspecialchars($enc['payment_method']) ?></td>
                    <td><span class="status-badge status-<?= $enc['status'] ?>"><?= ucfirst($enc['status']) ?></span></td>
                    <td>
                        <button onclick="toggleDetails(<?= $enc['id'] ?>)" class="btn btn-sm btn-primary">Ver</button>
                    </td>
                </tr>
                <tr id="details-<?= $enc['id'] ?>" class="order-details">
                    <td colspan="7">
                        <div class="detail-grid">
                            <div class="detail-section">
                                <h4>Informações de Entrega</h4>
                                <pre style="white-space: pre-wrap; font-family: inherit; margin: 0;"><?= htmlspecialchars($enc['shipping_address']) ?></pre>
                                <?php if ($enc['modo_entrega']): ?>
                                    <p style="margin-top: 10px;">
                                        <strong>Modo de Entrega:</strong> 
                                        <?= $enc['modo_entrega'] === 'standard' ? 'Standard (GRÁTIS - 2-3 dias)' : 'Express (€5,99 - 2 horas)' ?>
                                    </p>
                                <?php endif; ?>
                                <?php if ($enc['billing_nif']): ?>
                                    <p style="margin-top: 10px;"><strong>NIF:</strong> <?= htmlspecialchars($enc['billing_nif']) ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="detail-section">
                                <h4>Detalhes da Encomenda</h4>
                                <?php
                                $items_stmt = $mysqli->prepare('SELECT ei.*, p.marca, p.modelo FROM encomenda_itens ei JOIN produtos p ON ei.produto_id = p.id WHERE ei.encomenda_id = ?');
                                $items_stmt->bind_param('i', $enc['id']);
                                $items_stmt->execute();
                                $items = $items_stmt->get_result();
                                ?>
                                <ul style="list-style: none; padding: 0; margin: 0;">
                                    <?php while ($item = $items->fetch_assoc()): ?>
                                        <li style="padding: 8px 0; border-bottom: 1px solid var(--border);">
                                            <strong><?= $item['quantity'] ?>x</strong> <?= htmlspecialchars($item['marca'] . ' ' . $item['modelo']) ?>
                                            <span style="float: right;">€<?= number_format($item['price'] * $item['quantity'], 2, ',', '.') ?></span>
                                        </li>
                                    <?php endwhile; ?>
                                </ul>
                                <?php if ($enc['tracking_code']): ?>
                                    <p style="margin-top: 15px;"><strong>Código de Rastreio:</strong> <?= htmlspecialchars($enc['tracking_code']) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <?php if ($enc['notes']): ?>
                            <div class="detail-section" style="margin-top: 20px;">
                                <h4>Notas</h4>
                                <pre style="white-space: pre-wrap; font-family: inherit; margin: 0; font-size: 13px;"><?= htmlspecialchars($enc['notes']) ?></pre>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Formulários de Ação -->
                        <div class="action-buttons">
                            <!-- Atualizar Estado -->
                            <form method="POST" style="flex: 1;">
                                <input type="hidden" name="update_status" value="1">
                                <input type="hidden" name="order_id" value="<?= $enc['id'] ?>">
                                <input type="hidden" name="old_status" value="<?= $enc['status'] ?>">
                                <div style="display: flex; gap: 10px;">
                                    <select name="status" required style="flex: 1; padding: 10px; border: 2px solid var(--border); border-radius: 8px;">
                                        <option value="">Alterar Estado...</option>
                                        <option value="pendente">Pendente</option>
                                        <option value="processando">Processando</option>
                                        <option value="enviada">Enviada</option>
                                        <option value="entregue">Entregue</option>
                                    </select>
                                    <input type="text" name="tracking_code" placeholder="Código rastreio (opcional)" style="flex: 1; padding: 10px; border: 2px solid var(--border); border-radius: 8px;">
                                    <button type="submit" class="btn btn-success">Atualizar</button>
                                </div>
                            </form>
                        </div>
                        
                        <div class="action-buttons" style="margin-top: 10px;">
                            <!-- Adicionar Nota -->
                            <form method="POST" style="flex: 2;">
                                <input type="hidden" name="add_note" value="1">
                                <input type="hidden" name="order_id" value="<?= $enc['id'] ?>">
                                <div style="display: flex; gap: 10px;">
                                    <input type="text" name="note" placeholder="Adicionar nota/problema..." required style="flex: 1; padding: 10px; border: 2px solid var(--border); border-radius: 8px;">
                                    <button type="submit" class="btn btn-primary">Adicionar Nota</button>
                                </div>
                            </form>
                            
                            <!-- Cancelar -->
                            <?php if ($enc['status'] !== 'cancelada' && $enc['status'] !== 'entregue'): ?>
                                <form method="POST" onsubmit="return confirm('Tem a certeza que deseja cancelar esta encomenda?');">
                                    <input type="hidden" name="cancel_order" value="1">
                                    <input type="hidden" name="order_id" value="<?= $enc['id'] ?>">
                                    <input type="text" name="cancel_reason" placeholder="Motivo (opcional)" style="padding: 10px; border: 2px solid var(--border); border-radius: 8px; width: 200px;">
                                    <button type="submit" class="btn" style="background: #dc3545; color: white;">Cancelar Encomenda</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            
            <?php if (empty($encomendas)): ?>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <div style="font-size: 48px; margin-bottom: 10px;"></div>
                        <strong>Nenhuma encomenda encontrada</strong>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
function toggleDetails(orderId) {
    const detailsRow = document.getElementById('details-' + orderId);
    detailsRow.classList.toggle('active');
}
</script>
