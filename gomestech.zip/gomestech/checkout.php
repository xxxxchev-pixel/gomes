<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?redirect=checkout');
    exit;
}

$error = '';
$success = '';
$user_id = $_SESSION['user_id'];

// Carregar produtos do carrinho
$cart_items = [];
$total = 0;

if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    
    $stmt = $mysqli->prepare("SELECT * FROM produtos WHERE id IN ($placeholders)");
    $stmt->bind_param($types, ...$ids);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($produto = $result->fetch_assoc()) {
        $quantidade = $_SESSION['cart'][$produto['id']];
        $subtotal = $produto['preco'] * $quantidade;
        $total += $subtotal;
        
        $cart_items[] = [
            'produto' => $produto,
            'quantidade' => $quantidade,
            'subtotal' => $subtotal
        ];
    }
    $stmt->close();
}

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $nif = trim($_POST['nif'] ?? '');
    $morada = trim($_POST['morada'] ?? '');
    $codigo_postal = trim($_POST['codigo_postal'] ?? '');
    $cidade = trim($_POST['cidade'] ?? '');
    $metodo_pagamento = $_POST['metodo_pagamento'] ?? '';
    $modo_entrega = $_POST['modo_entrega'] ?? 'standard';
    $custo_entrega_selecionado = floatval($_POST['custo_entrega'] ?? 0);
    
    if (empty($nome) || empty($email) || empty($telefone) || empty($nif) || empty($morada) || empty($codigo_postal) || empty($cidade) || empty($metodo_pagamento) || empty($modo_entrega)) {
        $error = 'Por favor, preencha todos os campos obrigatórios.';
    } elseif (empty($cart_items)) {
        $error = 'O seu carrinho está vazio.';
    } else {
        // Gerar número de encomenda único
        $order_number = 'GT' . date('Ymd') . rand(1000, 9999);
        
        // Criar encomenda
        $mysqli->begin_transaction();
        try {
            $user_id = intval($_SESSION['user_id']);
            
            // Calcular custos
            $subtotal = $total;
            $custo_envio = $custo_entrega_selecionado;
            $total_final = $subtotal + $custo_envio;
            
            // Montar endereço completo com modo de entrega
            $shipping_address = "Modo: " . ($modo_entrega === 'express' ? 'Express (2 horas)' : 'Standard (2-3 dias)') . "\n" . $nome . "\n" . $morada . "\n" . $codigo_postal . " " . $cidade . "\nTelefone: " . $telefone . "\nEmail: " . $email;
            
            // Inserir encomenda (SEM reduzir stock ainda)
            $stmt = $mysqli->prepare('INSERT INTO encomendas (user_id, order_number, total, shipping_address, billing_nif, payment_method, modo_entrega, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            $status = 'pendente';
            $stmt->bind_param('isdsssss', $user_id, $order_number, $total_final, $shipping_address, $nif, $metodo_pagamento, $modo_entrega, $status);
            $stmt->execute();
            $encomenda_id = $stmt->insert_id;
            $stmt->close();

            // Inserir itens da encomenda (SEM reduzir stock)
            $item_stmt = $mysqli->prepare('INSERT INTO encomenda_itens (encomenda_id, produto_id, quantity, price) VALUES (?, ?, ?, ?)');
            foreach ($cart_items as $item) {
                $pid = intval($item['produto']['id']);
                $qty = intval($item['quantidade']);
                $price = floatval($item['produto']['preco']);
                $item_stmt->bind_param('iiid', $encomenda_id, $pid, $qty, $price);
                $item_stmt->execute();
            }
            $item_stmt->close();

            $mysqli->commit();
            
            // Limpar carrinho
            unset($_SESSION['cart']);
            
            // Redirecionar para página de confirmação
            header('Location: encomenda-confirmacao.php?order=' . $order_number);
            exit;
            
        } catch (Throwable $e) {
            $mysqli->rollback();
            $error = 'Erro ao processar encomenda: ' . $e->getMessage();
        }
    }
}

// Buscar dados do utilizador
$user_stmt = $mysqli->prepare("SELECT * FROM users WHERE id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finalizar Compra - GomesTech</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/gomestech.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f5f5f5; }
        
        .checkout-wrapper {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Progress Steps */
        .checkout-header {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .progress-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .progress-line {
            position: absolute;
            top: 25px;
            left: 50px;
            right: 50px;
            height: 3px;
            background: #e0e0e0;
            z-index: 0;
        }
        
        .progress-line-fill {
            height: 100%;
            background: #ff6a00;
            width: 0%;
            transition: width 0.4s ease;
        }
        
        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            z-index: 1;
            flex: 1;
            cursor: pointer;
        }
        
        .step-circle {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: white;
            border: 3px solid #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 18px;
            color: #999;
            transition: all 0.3s ease;
            margin-bottom: 12px;
        }
        
        .step.active .step-circle {
            border-color: #ff6a00;
            background: #ff6a00;
            color: white;
            transform: scale(1.1);
        }
        
        .step.completed .step-circle {
            border-color: #00c853;
            background: #00c853;
            color: white;
        }
        
        .step-label {
            font-size: 14px;
            font-weight: 600;
            color: #999;
            text-align: center;
            transition: color 0.3s ease;
        }
        
        .step.active .step-label {
            color: #ff6a00;
        }
        
        .step.completed .step-label {
            color: #00c853;
        }
        
        /* Checkout Content */
        .checkout-content {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 30px;
            align-items: start;
        }
        
        .checkout-form {
            background: white;
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .form-section {
            display: none;
            animation: fadeIn 0.4s ease;
        }
        
        .form-section.active {
            display: block;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .section-title {
            font-size: 24px;
            font-weight: 700;
            color: #333;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #333;
            font-size: 14px;
        }
        
        .form-group input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.2s;
            background: white;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #ff6a00;
            box-shadow: 0 0 0 3px rgba(255,106,0,0.1);
        }
        
        .payment-methods {
            display: grid;
            gap: 16px;
        }
        
        .payment-option, .delivery-option {
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 16px;
            background: white;
        }
        
        .payment-option:hover, .delivery-option:hover {
            border-color: #ff6a00;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .payment-option input[type="radio"], .delivery-option input[type="radio"] {
            width: 24px;
            height: 24px;
            accent-color: #ff6a00;
            cursor: pointer;
        }
        
        .payment-option.selected, .delivery-option.selected {
            border-color: #ff6a00;
            background: rgba(255,106,0,0.05);
        }
        
        .delivery-options {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .delivery-details {
            flex: 1;
        }
        
        .payment-icon {
            font-size: 28px;
        }
        
        .payment-info {
            flex: 1;
        }
        
        .payment-info strong {
            display: block;
            font-size: 16px;
            margin-bottom: 4px;
        }
        
        .payment-info small {
            color: #666;
            font-size: 13px;
        }
        
        /* Navigation Buttons */
        .form-navigation {
            display: flex;
            gap: 16px;
            margin-top: 32px;
            padding-top: 24px;
            border-top: 1px solid #e0e0e0;
        }
        
        .btn-nav {
            flex: 1;
            padding: 16px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-prev {
            background: #f5f5f5;
            color: #333;
        }
        
        .btn-prev:hover {
            background: #e0e0e0;
        }
        
        .btn-next {
            background: #ff6a00;
            color: white;
        }
        
        .btn-next:hover {
            background: #e55f00;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255,106,0,0.3);
        }
        
        /* Summary Sidebar */
        .order-summary {
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            position: sticky;
            top: 20px;
        }
        
        .summary-title {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 20px;
            color: #333;
        }
        
        .cart-item {
            display: flex;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .cart-item:last-child {
            border-bottom: none;
        }
        
        .cart-item img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            border-radius: 8px;
            background: #fafafa;
            border: 1px solid #f0f0f0;
            padding: 8px;
        }
        
        .cart-item-info {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .cart-item-name {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 4px;
            color: #333;
        }
        
        .cart-item-qty {
            font-size: 13px;
            color: #666;
        }
        
        .cart-item-price {
            font-weight: 700;
            color: #ff6a00;
            font-size: 15px;
            align-self: center;
        }
        
        .summary-totals {
            margin-top: 24px;
            padding-top: 20px;
            border-top: 2px solid #f0f0f0;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            font-size: 14px;
        }
        
        .summary-row.total {
            font-size: 20px;
            font-weight: 700;
            color: #ff6a00;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 2px solid #f0f0f0;
        }
        
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 600;
        }
        
        .alert-error {
            background: #fee;
            color: #c33;
            border: 2px solid #fcc;
        }
        
        @media (max-width: 1024px) {
            .checkout-content {
                grid-template-columns: 1fr;
            }
            
            .order-summary {
                position: static;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="checkout-wrapper">
        <!-- Progress Steps -->
        <div class="checkout-header">
            <div class="progress-container">
                <div class="progress-line">
                    <div class="progress-line-fill" id="progressFill"></div>
                </div>
                <div class="step active" data-step="1">
                    <div class="step-circle">1</div>
                    <div class="step-label">Identificação</div>
                </div>
                <div class="step" data-step="2">
                    <div class="step-circle">2</div>
                    <div class="step-label">Entrega</div>
                </div>
                <div class="step" data-step="3">
                    <div class="step-circle">3</div>
                    <div class="step-label">Pagamento</div>
                </div>
                <div class="step" data-step="4">
                    <div class="step-circle">4</div>
                    <div class="step-label">Confirmação</div>
                </div>
            </div>
        </div>
        
        <?php if($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if(empty($cart_items)): ?>
            <div style="text-align:center;background:white;padding:80px 40px;border-radius:12px">
                <h2 style="font-size:28px;margin-bottom:16px">O seu carrinho está vazio</h2>
                <p style="color:#666;margin-bottom:24px">Adicione produtos para finalizar a compra</p>
                <a href="catalogo.php" style="display:inline-block;padding:14px 32px;background:#ff6a00;color:white;border-radius:8px;text-decoration:none;font-weight:600">Ver Catálogo</a>
            </div>
        <?php else: ?>
        
        <div class="checkout-content">
            <!-- Form -->
            <div class="checkout-form">
                <form method="POST" id="checkoutForm">
                    <!-- Step 1: Identificação -->
                    <div class="form-section active" data-section="1">
                        <div class="section-title">
                            <span aria-hidden="true"></span>
                            <span>Dados de Identificação</span>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="nome">Nome Completo *</label>
                                <input type="text" id="nome" name="nome" required value="<?php echo htmlspecialchars($user['nome'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="email">Email *</label>
                                <input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="telefone">Telefone *</label>
                                <input type="tel" id="telefone" name="telefone" required value="<?php echo htmlspecialchars($user['telefone'] ?? ''); ?>" placeholder="912 345 678">
                            </div>
                            <div class="form-group">
                                <label for="nif">NIF *</label>
                                <input type="text" id="nif" name="nif" required value="<?php echo htmlspecialchars($user['nif'] ?? ''); ?>" placeholder="123456789" maxlength="9" pattern="[0-9]{9}">
                            </div>
                        </div>
                        
                        <div class="form-navigation">
                            <button type="button" class="btn-nav btn-next" onclick="nextStep()">Continuar →</button>
                        </div>
                    </div>
                    
                    <!-- Step 2: Morada e Entrega -->
                    <div class="form-section" data-section="2">
                        <div class="section-title">
                            <span aria-hidden="true"></span>
                            <span>Morada e Opções de Entrega</span>
                        </div>
                        
                        <div class="form-group">
                            <label for="morada">Morada (Rua, Número, Andar) *</label>
                            <input type="text" id="morada" name="morada" required placeholder="Rua das Flores, 123, 2º Esq">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="codigo_postal">Código Postal *</label>
                                <input type="text" id="codigo_postal" name="codigo_postal" required placeholder="1000-100" maxlength="8" pattern="[0-9]{4}-[0-9]{3}">
                            </div>
                            <div class="form-group">
                                <label for="cidade">Cidade *</label>
                                <input type="text" id="cidade" name="cidade" required placeholder="Lisboa">
                            </div>
                        </div>
                        
                        <div style="margin-top: 30px;">
                            <h3 style="font-size: 18px; margin-bottom: 16px; color: #333;">Opções de Entrega</h3>
                            <p style="font-size: 14px; color: #666; margin-bottom: 16px;">Envio por: <strong>WORTEN</strong></p>
                            
                            <div class="delivery-options">
                                <div class="delivery-option" onclick="selectDelivery('standard', 0, this)">
                                    <input type="radio" name="modo_entrega" value="standard" id="delivery_standard" checked required>
                                    <div class="delivery-details">
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <div>
                                                <strong style="font-size: 16px;">Standard</strong>
                                                <p style="margin: 4px 0 0 0; color: #666; font-size: 14px;">Entrega em 2 a 3 dias úteis</p>
                                            </div>
                                            <div style="font-size: 18px; font-weight: 700; color: #00c853;">GRÁTIS</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="delivery-option" onclick="selectDelivery('express', 5.99, this)">
                                    <input type="radio" name="modo_entrega" value="express" id="delivery_express">
                                    <div class="delivery-details">
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <div>
                                                <strong style="font-size: 16px;">Express</strong>
                                                <p style="margin: 4px 0 0 0; color: #666; font-size: 14px;">Entrega em 2 horas</p>
                                            </div>
                                            <div style="font-size: 18px; font-weight: 700; color: #ff6a00;">€5,99</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <input type="hidden" name="custo_entrega" id="custo_entrega" value="0">
                        </div>
                        
                        <div class="form-navigation">
                            <button type="button" class="btn-nav btn-prev" onclick="prevStep()">← Voltar</button>
                            <button type="button" class="btn-nav btn-next" onclick="nextStep()">Continuar →</button>
                        </div>
                    </div>
                    
                    <!-- Step 3: Pagamento -->
                    <div class="form-section" data-section="3">
                        <div class="section-title">
                            <span aria-hidden="true"></span>
                            <span>Método de Pagamento</span>
                        </div>
                        
                        <div class="payment-methods">
                            <div class="payment-option" onclick="selectPayment('Multibanco', this)">
                                <input type="radio" name="metodo_pagamento" value="Multibanco" id="pay1" required>
                                <span class="payment-icon" aria-hidden="true"></span>
                                <div class="payment-info">
                                    <strong>Multibanco</strong>
                                    <small>Referência Multibanco (válida 3 dias)</small>
                                </div>
                            </div>
                            
                            <div class="payment-option" onclick="selectPayment('MB WAY', this)">
                                <input type="radio" name="metodo_pagamento" value="MB WAY" id="pay2">
                                <span class="payment-icon" aria-hidden="true"></span>
                                <div class="payment-info">
                                    <strong>MB WAY</strong>
                                    <small>Pagamento instantâneo via telemóvel</small>
                                </div>
                            </div>
                            
                            <div class="payment-option" onclick="selectPayment('Cartão de Crédito', this)">
                                <input type="radio" name="metodo_pagamento" value="Cartão de Crédito" id="pay3">
                                <span class="payment-icon" aria-hidden="true"></span>
                                <div class="payment-info">
                                    <strong>Cartão de Crédito/Débito</strong>
                                    <small>Visa, Mastercard, American Express</small>
                                </div>
                            </div>
                            
                            <div class="payment-option" onclick="selectPayment('PayPal', this)">
                                <input type="radio" name="metodo_pagamento" value="PayPal" id="pay4">
                                <span class="payment-icon" aria-hidden="true"></span>
                                <div class="payment-info">
                                    <strong>PayPal</strong>
                                    <small>Pagamento seguro via PayPal</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-navigation">
                            <button type="button" class="btn-nav btn-prev" onclick="prevStep()">← Voltar</button>
                            <button type="button" class="btn-nav btn-next" onclick="nextStep()">Continuar →</button>
                        </div>
                    </div>
                    
                    <!-- Step 4: Confirmação -->
                    <div class="form-section" data-section="4">
                        <div class="section-title">
                            <span aria-hidden="true"></span>
                            <span>Confirmar Encomenda</span>
                        </div>
                        
                        <div style="background:#f9f9f9;padding:24px;border-radius:8px;margin-bottom:24px">
                            <h3 style="margin:0 0 16px 0;font-size:16px;color:#333">Resumo dos Dados</h3>
                            <div style="font-size:14px;line-height:1.8;color:#666">
                                <p><strong>Nome:</strong> <span id="confirm-nome"></span></p>
                                <p><strong>Email:</strong> <span id="confirm-email"></span></p>
                                <p><strong>Telefone:</strong> <span id="confirm-telefone"></span></p>
                                <p><strong>NIF:</strong> <span id="confirm-nif"></span></p>
                                <p><strong>Morada:</strong> <span id="confirm-morada"></span></p>
                                <p><strong>Código Postal:</strong> <span id="confirm-cp"></span></p>
                                <p><strong>Cidade:</strong> <span id="confirm-cidade"></span></p>
                                <p><strong>Modo de Entrega:</strong> <span id="confirm-entrega"></span></p>
                                <p><strong>Pagamento:</strong> <span id="confirm-pagamento"></span></p>
                            </div>
                        </div>
                        
                        <div style="background:#e3f2fd;border-left:4px solid #2196f3;padding:16px;border-radius:4px;margin-bottom:24px">
                            <p style="margin:0;font-size:14px;color:#1565c0">
                                <strong>Prazo de Entrega:</strong> A sua encomenda será entregue em 2-5 dias úteis após confirmação do pagamento.
                            </p>
                        </div>
                        
                        <div class="form-navigation">
                            <button type="button" class="btn-nav btn-prev" onclick="prevStep()">← Voltar</button>
                            <button type="submit" class="btn-nav btn-next">Confirmar e Finalizar</button>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Summary -->
            <div class="order-summary">
                <h3 class="summary-title">Resumo da Encomenda</h3>
                
                <div style="max-height:400px;overflow-y:auto;margin-bottom:20px">
                    <?php foreach($cart_items as $item): ?>
                        <div class="cart-item">
                            <img src="<?php echo htmlspecialchars($item['produto']['imagem_principal'] ?? ''); ?>" alt="">
                            <div class="cart-item-info">
                                <div class="cart-item-name"><?php echo htmlspecialchars($item['produto']['marca'] . ' ' . $item['produto']['modelo']); ?></div>
                                <div class="cart-item-qty"><?php echo $item['quantidade']; ?>x <?php echo number_format($item['produto']['preco'], 2, ',', '.'); ?> €</div>
                            </div>
                            <div class="cart-item-price"><?php echo number_format($item['subtotal'], 2, ',', '.'); ?> €</div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="summary-totals">
                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span><?php echo number_format($total, 2, ',', '.'); ?> €</span>
                    </div>
                    <div class="summary-row">
                        <span>Envio</span>
                        <span style="color:#00c853;font-weight:600">GRÁTIS</span>
                    </div>
                    <div class="summary-row total">
                        <span>TOTAL</span>
                        <span><?php echo number_format($total, 2, ',', '.'); ?> €</span>
                    </div>
                </div>
            </div>
        </div>
        
        <?php endif; ?>
    </div>
    
    <script>
        let currentStep = 1;
        const totalSteps = 4;
        
        function updateProgress() {
            // Update progress bar
            const progress = ((currentStep - 1) / (totalSteps - 1)) * 100;
            document.getElementById('progressFill').style.width = progress + '%';
            
            // Update steps
            document.querySelectorAll('.step').forEach(step => {
                const stepNum = parseInt(step.dataset.step);
                step.classList.remove('active', 'completed');
                
                if (stepNum === currentStep) {
                    step.classList.add('active');
                } else if (stepNum < currentStep) {
                    step.classList.add('completed');
                }
            });
            
            // Update form sections
            document.querySelectorAll('.form-section').forEach(section => {
                section.classList.remove('active');
            });
            document.querySelector(`.form-section[data-section="${currentStep}"]`).classList.add('active');
            
            // Update confirmation data on step 4
            if (currentStep === 4) {
                document.getElementById('confirm-nome').textContent = document.getElementById('nome').value;
                document.getElementById('confirm-email').textContent = document.getElementById('email').value;
                document.getElementById('confirm-telefone').textContent = document.getElementById('telefone').value;
                document.getElementById('confirm-nif').textContent = document.getElementById('nif').value;
                document.getElementById('confirm-morada').textContent = document.getElementById('morada').value;
                document.getElementById('confirm-cp').textContent = document.getElementById('codigo_postal').value;
                document.getElementById('confirm-cidade').textContent = document.getElementById('cidade').value;
                
                const selectedDelivery = document.querySelector('input[name="modo_entrega"]:checked');
                if (selectedDelivery) {
                    const deliveryText = selectedDelivery.value === 'standard' ? 'Standard (GRÁTIS - 2 a 3 dias)' : 'Express (€5,99 - 2 horas)';
                    document.getElementById('confirm-entrega').textContent = deliveryText;
                }
                
                const selectedPayment = document.querySelector('input[name="metodo_pagamento"]:checked');
                document.getElementById('confirm-pagamento').textContent = selectedPayment ? selectedPayment.value : 'Não selecionado';
            }
        }
        
        function nextStep() {
            // Validate current step
            const currentSection = document.querySelector(`.form-section[data-section="${currentStep}"]`);
            const inputs = currentSection.querySelectorAll('input[required]');
            let valid = true;
            
            inputs.forEach(input => {
                if (!input.checkValidity()) {
                    input.reportValidity();
                    valid = false;
                }
            });
            
            if (!valid) return;
            
            if (currentStep < totalSteps) {
                currentStep++;
                updateProgress();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }
        
        function prevStep() {
            if (currentStep > 1) {
                currentStep--;
                updateProgress();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }
        
        function selectPayment(method, element) {
            document.querySelectorAll('.payment-option').forEach(opt => opt.classList.remove('selected'));
            element.classList.add('selected');
            element.querySelector('input').checked = true;
        }
        
        function selectDelivery(mode, cost, element) {
            document.querySelectorAll('.delivery-option').forEach(opt => opt.classList.remove('selected'));
            element.classList.add('selected');
            element.querySelector('input').checked = true;
            document.getElementById('custo_entrega').value = cost;
            updateOrderSummary(cost);
        }
        
        function updateOrderSummary(shippingCost) {
            const subtotal = <?= $total ?>;
            const total = subtotal + shippingCost;
            
            // Atualizar envio
            const shippingElement = document.querySelector('.summary-row:nth-child(2) span:last-child');
            if (shippingCost === 0) {
                shippingElement.innerHTML = '<span style="color:#00c853;font-weight:600">GRÁTIS</span>';
            } else {
                shippingElement.textContent = '€' + shippingCost.toFixed(2).replace('.', ',');
            }
            
            // Atualizar total
            document.querySelector('.summary-row.total span:last-child').textContent = '€' + total.toFixed(2).replace('.', ',');
        }
        
        // Allow clicking on step circles to navigate
        document.querySelectorAll('.step').forEach(step => {
            step.addEventListener('click', function() {
                const targetStep = parseInt(this.dataset.step);
                if (targetStep < currentStep) {
                    currentStep = targetStep;
                    updateProgress();
                }
            });
        });
        
        // Initialize
        updateProgress();
    </script>
</body>
</html>
