<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Processar atualização de dados pessoais
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $telefone = trim($_POST['telefone']);
    $nif = trim($_POST['nif']);
    
    if (empty($nome) || empty($email)) {
        $error = 'Nome e email são obrigatórios.';
    } else {
        // Verificar se o email já existe (exceto o próprio)
        $check_email = $mysqli->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
        $check_email->bind_param('si', $email, $user_id);
        $check_email->execute();
        if ($check_email->get_result()->num_rows > 0) {
            $error = 'Este email já está a ser utilizado por outra conta.';
        } else {
            $update_stmt = $mysqli->prepare('UPDATE users SET nome = ?, email = ?, telefone = ?, nif = ? WHERE id = ?');
            $update_stmt->bind_param('ssssi', $nome, $email, $telefone, $nif, $user_id);
            if ($update_stmt->execute()) {
                $success = 'Dados atualizados com sucesso!';
            } else {
                $error = 'Erro ao atualizar dados.';
            }
            $update_stmt->close();
        }
        $check_email->close();
    }
}

// Processar alteração de senha
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Buscar senha atual
    $pass_stmt = $mysqli->prepare('SELECT password FROM users WHERE id = ?');
    $pass_stmt->bind_param('i', $user_id);
    $pass_stmt->execute();
    $pass_result = $pass_stmt->get_result()->fetch_assoc();
    $pass_stmt->close();
    
    if (!password_verify($current_password, $pass_result['password'])) {
        $error = 'Senha atual incorreta.';
    } elseif (strlen($new_password) < 6) {
        $error = 'A nova senha deve ter pelo menos 6 caracteres.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'As senhas não coincidem.';
    } else {
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $update_pass = $mysqli->prepare('UPDATE users SET password = ? WHERE id = ?');
        $update_pass->bind_param('si', $hashed, $user_id);
        if ($update_pass->execute()) {
            $success = 'Senha alterada com sucesso!';
        } else {
            $error = 'Erro ao alterar senha.';
        }
        $update_pass->close();
    }
}

// Processar cancelamento de encomenda
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_order'])) {
    $order_id = intval($_POST['order_id']);
    
    // Verificar se a encomenda pertence ao utilizador
    $check_stmt = $mysqli->prepare('SELECT id, status FROM encomendas WHERE id = ? AND user_id = ?');
    if ($check_stmt) {
        $check_stmt->bind_param('ii', $order_id, $user_id);
        $check_stmt->execute();
        $order_check = $check_stmt->get_result()->fetch_assoc();
        $check_stmt->close();
    } else {
        $order_check = null;
    }
    
    if ($order_check) {
        if ($order_check['status'] === 'Pendente' || $order_check['status'] === 'Pago') {
            $stmt = $mysqli->prepare('UPDATE encomendas SET status = "Cancelado" WHERE id = ?');
            if ($stmt) {
                $stmt->bind_param('i', $order_id);
                $stmt->execute();
                $stmt->close();
            }
            $success = 'Encomenda cancelada com sucesso!';
        } else {
            $error = 'Esta encomenda já não pode ser cancelada.';
        }
    } else {
        $error = 'Encomenda não encontrada.';
    }
}

// Buscar encomendas do utilizador
$stmt = $mysqli->prepare('SELECT * FROM encomendas WHERE user_id = ? ORDER BY data_encomenda DESC');
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $encomendas = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} else {
    $encomendas = [];
}

// Buscar dados do utilizador
$user_stmt = $mysqli->prepare('SELECT * FROM users WHERE id = ?');
if ($user_stmt) {
    $user_stmt->bind_param('i', $user_id);
    $user_stmt->execute();
    $user = $user_stmt->get_result()->fetch_assoc();
    $user_stmt->close();
} else {
    $user = null;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha Conta - GomesTech</title>
    <link rel="stylesheet" href="css/gomestech.css">
    <style>
        .account-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }
        
        .account-grid {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 30px;
        }
        
        .account-sidebar {
            background: white;
            border-radius: 12px;
            padding: 30px;
            height: fit-content;
            position: sticky;
            top: 20px;
        }
        
        .user-info {
            text-align: center;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #ff6a00, #ee0979);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            color: white;
            margin: 0 auto 15px;
        }
        
        .user-name {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .user-email {
            color: #666;
            font-size: 14px;
        }
        
        .account-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .account-menu li {
            margin-bottom: 10px;
        }
        
        .account-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            border-radius: 8px;
            color: #333;
            text-decoration: none;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .account-menu a:hover, .account-menu a.active {
            background: #fff5f0;
            color: #ff6a00;
        }
        
        .account-content {
            background: white;
            border-radius: 12px;
            padding: 40px;
        }
        
        .orders-list {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .order-card {
            border: 2px solid #f0f0f0;
            border-radius: 12px;
            padding: 24px;
            transition: all 0.2s;
        }
        
        .order-card:hover {
            border-color: #ff6a00;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .order-number {
            font-size: 18px;
            font-weight: 700;
            color: #ff6a00;
        }
        
        .order-date {
            color: #666;
            font-size: 14px;
        }
        
        .order-status {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .status-pendente { background: #fff3cd; color: #856404; }
        .status-processando { background: #cce5ff; color: #004085; }
        .status-enviada { background: #d1ecf1; color: #0c5460; }
        .status-entregue { background: #d4edda; color: #155724; }
        .status-cancelada { background: #f8d7da; color: #721c24; }
        
        .order-items {
            margin-bottom: 20px;
        }
        
        .order-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 10px 0;
        }
        
        .order-summary {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 15px;
            border-top: 1px solid #f0f0f0;
        }
        
        .order-total {
            font-size: 24px;
            font-weight: 700;
            color: #ff6a00;
        }
        
        .order-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary {
            background: #ff6a00;
            color: white;
        }
        
        .btn-primary:hover {
            background: #e55f00;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 600;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 2px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 2px solid #f5c6cb;
        }
        
        .content-section {
            display: none;
        }
        
        .content-section.active {
            display: block;
        }
        
        .account-menu a {
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .account-grid {
                grid-template-columns: 1fr;
            }
            
            .account-sidebar {
                position: static;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="account-container">
        <?php if($success): ?>
            <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <?php if($error): ?>
            <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <div class="account-grid">
            <!-- Sidebar -->
            <aside class="account-sidebar">
                <div class="user-info">
                    <div class="user-avatar">👤</div>
                    <div class="user-name"><?= htmlspecialchars($user['nome']) ?></div>
                    <div class="user-email"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                
                <ul class="account-menu">
                    <li><a href="#encomendas" onclick="showSection('encomendas')" id="menu-encomendas" class="active">📦 Minhas Encomendas</a></li>
                    <li><a href="#configuracoes" onclick="showSection('configuracoes')" id="menu-configuracoes">⚙️ Configurações da Conta</a></li>
                    <li><a href="favoritos.php">❤️ Favoritos</a></li>
                    <li><a href="carrinho.php">🛒 Carrinho</a></li>
                    <li><a href="logout.php">🚪 Sair</a></li>
                </ul>
            </aside>
            
            <!-- Content -->
            <main class="account-content">
                <!-- Seção de Encomendas -->
                <div id="section-encomendas" class="content-section active">
                    <h2 style="margin-bottom: 30px;">📦 Minhas Encomendas</h2>
                    
                    <?php if (empty($encomendas)): ?>
                    <div style="text-align: center; padding: 60px 20px;">
                        <div style="font-size: 64px; margin-bottom: 20px;">📦</div>
                        <h3 style="margin-bottom: 10px;">Ainda não tem encomendas</h3>
                        <p style="color: #666; margin-bottom: 20px;">Explore nosso catálogo e faça sua primeira compra!</p>
                        <a href="catalogo.php" class="btn btn-primary">Ver Catálogo</a>
                    </div>
                <?php else: ?>
                    <div class="orders-list">
                        <?php foreach ($encomendas as $enc): ?>
                            <div class="order-card">
                                <div class="order-header">
                                    <div>
                                        <div class="order-number">#<?= htmlspecialchars($enc['numero_encomenda']) ?></div>
                                        <div class="order-date">📅 <?= date('d/m/Y \\u00e0\\s H:i', strtotime($enc['data_encomenda'])) ?></div>
                                    </div>
                                    <span class="order-status status-<?= strtolower($enc['status']) ?>">
                                        <?= $enc['status'] ?>
                                    </span>
                                </div>
                                
                                <div class="order-items">
                                    <?php
                                    $items_stmt = $mysqli->prepare('SELECT ei.*, p.marca, p.modelo FROM encomenda_itens ei JOIN produtos p ON ei.produto_id = p.id WHERE ei.encomenda_id = ?');
                                    if ($items_stmt) {
                                        $items_stmt->bind_param('i', $enc['id']);
                                        $items_stmt->execute();
                                        $items = $items_stmt->get_result();
                                    ?>
                                    
                                    <?php while ($item = $items->fetch_assoc()): ?>
                                        <div class="order-item">
                                            <div style="font-size: 14px; color: #666;">
                                                <strong><?= $item['quantidade'] ?>x</strong> <?= htmlspecialchars($item['marca'] . ' ' . $item['modelo']) ?>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                    <?php } ?>
                                </div>
                                
                                <div class="order-summary">
                                    <div>
                                        <div style="color: #666; font-size: 14px; margin-bottom: 5px;">💳 <?= htmlspecialchars($enc['metodo_pagamento']) ?></div>
                                        <div style="color: #666; font-size: 14px; margin-bottom: 5px;">
                                            🚚 Entrega Standard (2-3 dias)
                                        </div>
                                    </div>
                                    <div>
                                        <div class="order-total">€<?= number_format($enc['total'], 2, ',', '.') ?></div>
                                    </div>
                                </div>
                                
                                <div class="order-actions" style="margin-top: 20px;">
                                    <a href="encomenda-confirmacao.php?order=<?= htmlspecialchars($enc['numero_encomenda']) ?>" class="btn btn-primary">👁️ Ver Detalhes</a>
                                    
                                    <?php if ($enc['status'] === 'Pendente' || $enc['status'] === 'Pago'): ?>
                                        <form method="POST" onsubmit="return confirm('Tem certeza que deseja cancelar esta encomenda?')" style="display: inline;">
                                            <input type="hidden" name="cancel_order" value="1">
                                            <input type="hidden" name="order_id" value="<?= $enc['id'] ?>">
                                            <button type="submit" class="btn btn-danger">❌ Cancelar Encomenda</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                </div>
                
                <!-- Seção de Configurações -->
                <div id="section-configuracoes" class="content-section" style="display: none;">
                    <h2 style="margin-bottom: 30px;">⚙️ Configurações da Conta</h2>
                    
                    <!-- Dados Pessoais -->
                    <div style="background: white; border-radius: 12px; padding: 30px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                        <h3 style="margin-top: 0; color: #333; border-bottom: 2px solid #f0f0f0; padding-bottom: 12px; margin-bottom: 20px;">
                            👤 Dados Pessoais
                        </h3>
                        
                        <form method="POST">
                            <input type="hidden" name="update_profile" value="1">
                            
                            <div style="margin-bottom: 20px;">
                                <label style="display: block; font-weight: 600; margin-bottom: 8px; color: #333;">Nome Completo *</label>
                                <input type="text" name="nome" required value="<?= htmlspecialchars($user['nome']) ?>" 
                                    style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 8px; font-size: 15px;">
                            </div>
                            
                            <div style="margin-bottom: 20px;">
                                <label style="display: block; font-weight: 600; margin-bottom: 8px; color: #333;">Email *</label>
                                <input type="email" name="email" required value="<?= htmlspecialchars($user['email']) ?>" 
                                    style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 8px; font-size: 15px;">
                            </div>
                            
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                                <div>
                                    <label style="display: block; font-weight: 600; margin-bottom: 8px; color: #333;">Telefone</label>
                                    <input type="tel" name="telefone" value="<?= htmlspecialchars($user['telefone'] ?? '') ?>" 
                                        style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 8px; font-size: 15px;" placeholder="912 345 678">
                                </div>
                                
                                <div>
                                    <label style="display: block; font-weight: 600; margin-bottom: 8px; color: #333;">NIF</label>
                                    <input type="text" name="nif" value="<?= htmlspecialchars($user['nif'] ?? '') ?>" maxlength="9" 
                                        style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 8px; font-size: 15px;" placeholder="123456789">
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary" style="padding: 12px 32px;">
                                💾 Guardar Alterações
                            </button>
                        </form>
                    </div>
                    
                    <!-- Alterar Senha -->
                    <div style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                        <h3 style="margin-top: 0; color: #333; border-bottom: 2px solid #f0f0f0; padding-bottom: 12px; margin-bottom: 20px;">
                            🔒 Alterar Senha
                        </h3>
                        
                        <form method="POST">
                            <input type="hidden" name="change_password" value="1">
                            
                            <div style="margin-bottom: 20px;">
                                <label style="display: block; font-weight: 600; margin-bottom: 8px; color: #333;">Senha Atual *</label>
                                <input type="password" name="current_password" required 
                                    style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 8px; font-size: 15px;" placeholder="••••••••">
                            </div>
                            
                            <div style="margin-bottom: 20px;">
                                <label style="display: block; font-weight: 600; margin-bottom: 8px; color: #333;">Nova Senha *</label>
                                <input type="password" name="new_password" required minlength="6"
                                    style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 8px; font-size: 15px;" placeholder="••••••••">
                                <small style="color: #666; font-size: 13px; margin-top: 4px; display: block;">Mínimo de 6 caracteres</small>
                            </div>
                            
                            <div style="margin-bottom: 20px;">
                                <label style="display: block; font-weight: 600; margin-bottom: 8px; color: #333;">Confirmar Nova Senha *</label>
                                <input type="password" name="confirm_password" required minlength="6"
                                    style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 8px; font-size: 15px;" placeholder="••••••••">
                            </div>
                            
                            <button type="submit" class="btn btn-primary" style="padding: 12px 32px;">
                                🔐 Alterar Senha
                            </button>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <footer class="footer">
        <div class="footer-bottom"><p>&copy; <?= date('Y') ?> GomesTech. Todos os direitos reservados.</p></div>
    </footer>
    
    <script>
        function showSection(section) {
            // Ocultar todas as seções
            document.querySelectorAll('.content-section').forEach(s => {
                s.style.display = 'none';
                s.classList.remove('active');
            });
            
            // Remover active de todos os links
            document.querySelectorAll('.account-menu a').forEach(link => {
                link.classList.remove('active');
            });
            
            // Mostrar seção selecionada
            document.getElementById('section-' + section).style.display = 'block';
            document.getElementById('section-' + section).classList.add('active');
            
            // Adicionar active ao link
            document.getElementById('menu-' + section).classList.add('active');
            
            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
            
            return false;
        }
        
        // Verificar se há mensagem de sucesso/erro para mostrar seção correta
        <?php if ($success && (isset($_POST['update_profile']) || isset($_POST['change_password']))): ?>
            showSection('configuracoes');
        <?php endif; ?>
    </script>
</body>
</html>
