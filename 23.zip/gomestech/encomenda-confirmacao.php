<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['order'])) {
    header('Location: index.php');
    exit;
}

$order_number = $_GET['order'];
$user_id = $_SESSION['user_id'];

// Buscar informações da encomenda
$stmt = $mysqli->prepare("
    SELECT e.*, u.nome as user_nome, u.email 
    FROM encomendas e 
    JOIN users u ON e.user_id = u.id 
    WHERE e.numero_encomenda = ? AND e.user_id = ?
");
if ($stmt) {
    $stmt->bind_param("si", $order_number, $user_id);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();
} else {
    die('Erro ao preparar query: ' . $mysqli->error);
}

if (!$order) {
    header('Location: index.php');
    exit;
}

// Buscar itens da encomenda
$stmt = $mysqli->prepare("
    SELECT ei.*, p.marca, p.modelo
    FROM encomenda_itens ei
    JOIN produtos p ON ei.produto_id = p.id
    WHERE ei.encomenda_id = ?
");
if ($stmt) {
    $stmt->bind_param("i", $order['id']);
    $stmt->execute();
    $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    die('Erro ao preparar query de itens: ' . $mysqli->error);
}

// Calcular prazo de entrega
$prazo_entrega = '2 a 3 dias úteis';
$custo_envio = $order['custo_envio'] ?? 0;
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedido Confirmado - GomesTech</title>
    <link rel="stylesheet" href="css/gomestech.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .confirmation-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .success-banner {
            background: linear-gradient(135deg, #00c853, #00e676);
            border-radius: 16px;
            padding: 50px 30px;
            text-align: center;
            color: white;
            margin-bottom: 30px;
            box-shadow: 0 8px 24px rgba(0, 200, 83, 0.3);
        }
        
        .cancelled-banner {
            background: linear-gradient(135deg, #dc3545, #e74c3c);
            box-shadow: 0 8px 24px rgba(220, 53, 69, 0.3);
        }

        .success-icon {
            font-size: 80px;
            margin-bottom: 20px;
            animation: checkPop 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        @keyframes checkPop {
            0% { transform: scale(0) rotate(0deg); opacity: 0; }
            50% { transform: scale(1.2) rotate(10deg); }
            100% { transform: scale(1) rotate(0deg); opacity: 1; }
        }

        .success-banner h1 {
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .success-banner p {
            font-size: 18px;
            opacity: 0.95;
            margin-bottom: 20px;
        }

        .order-number-badge {
            display: inline-block;
            background: rgba(255, 255, 255, 0.25);
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 20px;
            font-weight: 700;
            letter-spacing: 1px;
            margin-top: 10px;
        }

        .info-section {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .info-section h2 {
            font-size: 20px;
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid #f0f0f0;
        }

        .delivery-info {
            display: flex;
            align-items: center;
            padding: 20px;
            background: #e8f5e9;
            border-left: 4px solid #00c853;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .delivery-icon {
            font-size: 48px;
            margin-right: 20px;
        }

        .delivery-text h3 {
            font-size: 18px;
            color: #2e7d32;
            margin-bottom: 5px;
        }

        .delivery-text p {
            font-size: 15px;
            color: #558b2f;
        }

        .order-items {
            margin-top: 20px;
        }

        .order-item {
            display: flex;
            justify-content: space-between;
            padding: 15px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .order-item:last-child {
            border-bottom: none;
        }

        .item-name {
            font-weight: 600;
            color: #333;
        }

        .item-qty {
            color: #666;
            font-size: 14px;
            margin-top: 4px;
        }

        .item-price {
            font-weight: 700;
            color: #ff6a00;
            font-size: 16px;
        }

        .order-summary {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            font-size: 15px;
        }

        .summary-row.total {
            border-top: 2px solid #ddd;
            margin-top: 10px;
            padding-top: 15px;
            font-size: 20px;
            font-weight: 700;
            color: #00c853;
        }

        .payment-info {
            background: #fff3e0;
            border-left: 4px solid #ff9800;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .payment-info h3 {
            color: #e65100;
            margin-bottom: 10px;
            font-size: 16px;
        }

        .payment-info p {
            color: #ef6c00;
            font-size: 14px;
            line-height: 1.6;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 16px 32px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #ff6a00;
            color: white;
        }

        .btn-primary:hover {
            background: #e65100;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 106, 0, 0.3);
        }

        .btn-secondary {
            background: white;
            color: #666;
            border: 2px solid #ddd;
        }

        .btn-secondary:hover {
            border-color: #ff6a00;
            color: #ff6a00;
            transform: translateY(-2px);
        }

        .next-steps {
            background: #e3f2fd;
            border-left: 4px solid #2196f3;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .next-steps h3 {
            color: #1565c0;
            margin-bottom: 15px;
            font-size: 16px;
        }

        .next-steps ul {
            list-style: none;
            padding: 0;
        }

        .next-steps li {
            padding: 8px 0;
            color: #1976d2;
            font-size: 14px;
            line-height: 1.6;
        }

        .next-steps li:before {
            content: "✓ ";
            color: #00c853;
            font-weight: bold;
            margin-right: 8px;
        }

        @media (max-width: 768px) {
            .confirmation-container {
                margin: 20px auto;
                padding: 0 15px;
            }

            .success-banner {
                padding: 40px 20px;
            }

            .success-banner h1 {
                font-size: 28px;
            }

            .action-buttons {
                flex-direction: column;
            }

            .delivery-info {
                flex-direction: column;
                text-align: center;
            }

            .delivery-icon {
                margin-right: 0;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="confirmation-container">
        <!-- Banner de Sucesso ou Cancelamento -->
        <div class="success-banner <?= $order['status'] === 'Cancelado' ? 'cancelled-banner' : '' ?>">
            <div class="success-icon"><?= $order['status'] === 'Cancelado' ? '❌' : '✅' ?></div>
            <h1><?= $order['status'] === 'Cancelado' ? 'Pedido Cancelado' : 'Pedido Confirmado!' ?></h1>
            <p><?= $order['status'] === 'Cancelado' ? 'Este pedido foi cancelado' : 'O seu pedido foi realizado com sucesso' ?></p>
            <div class="order-number-badge">
                Nº do Pedido: <?= htmlspecialchars($order_number) ?>
            </div>
        </div>

        <!-- Informações de Entrega -->
        <?php if ($order['status'] !== 'Cancelado'): ?>
        <div class="info-section">
            <h2>📦 Informações de Entrega</h2>
            
            <div class="delivery-info">
                <div class="delivery-icon">🚚</div>
                <div class="delivery-text">
                    <h3>Entrega Standard</h3>
                    <p>Previsão de entrega: <strong><?= $prazo_entrega ?></strong></p>
                </div>
            </div>

            <div style="font-size: 14px; color: #666; line-height: 1.6;">
                <p><strong>Nome:</strong> <?= htmlspecialchars($order['nome']) ?></p>
                <p><strong>Morada:</strong> <?= htmlspecialchars($order['morada']) ?></p>
                <p><strong>Código Postal:</strong> <?= htmlspecialchars($order['codigo_postal']) ?></p>
                <p><strong>Cidade:</strong> <?= htmlspecialchars($order['cidade']) ?></p>
                <p><strong>Telefone:</strong> <?= htmlspecialchars($order['telefone']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($order['email']) ?></p>
                <p><strong>NIF:</strong> <?= htmlspecialchars($order['nif']) ?></p>
            </div>
        </div>
        <?php else: ?>
        <div class="info-section">
            <h2>📦 Estado da Encomenda</h2>
            
            <div style="background: #f8d7da; border-left: 4px solid #dc3545; padding: 20px; border-radius: 8px;">
                <h3 style="color: #721c24; margin-bottom: 10px; font-size: 16px;">❌ Encomenda Cancelada</h3>
                <p style="color: #721c24; font-size: 14px; line-height: 1.6; margin: 0;">
                    Esta encomenda foi cancelada e não será processada. Se efetuou algum pagamento, o valor será reembolsado.
                </p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Produtos -->
        <div class="info-section">
            <h2>🛍️ Produtos</h2>
            
            <div class="order-items">
                <?php foreach ($items as $item): ?>
                    <div class="order-item">
                        <div>
                            <div class="item-name"><?= htmlspecialchars($item['marca'] . ' ' . $item['modelo']) ?></div>
                            <div class="item-qty">Quantidade: <?= $item['quantidade'] ?></div>
                        </div>
                        <div class="item-price">
                            €<?= number_format($item['preco_unitario'] * $item['quantidade'], 2, ',', '.') ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="order-summary">
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span>€<?= number_format($order['subtotal'], 2, ',', '.') ?></span>
                </div>
                <div class="summary-row">
                    <span>Envio</span>
                    <span><?= $custo_envio > 0 ? '€' . number_format($custo_envio, 2, ',', '.') : '<span style="color:#00c853">GRÁTIS</span>' ?></span>
                </div>
                <div class="summary-row total">
                    <span>TOTAL</span>
                    <span>€<?= number_format($order['total'], 2, ',', '.') ?></span>
                </div>
            </div>
        </div>

        <!-- Informações de Pagamento -->
        <?php if ($order['status'] !== 'Cancelado'): ?>
        <div class="info-section">
            <h2>💳 Pagamento</h2>
            
            <div class="payment-info">
                <h3>Método selecionado: <?= htmlspecialchars($order['metodo_pagamento'] ?? 'Não definido') ?></h3>
                <p>
                    <?php if (($order['metodo_pagamento'] ?? '') === 'Multibanco'): ?>
                        📧 Receberá um email com a referência Multibanco para efetuar o pagamento. A referência é válida por 3 dias.
                    <?php elseif (($order['metodo_pagamento'] ?? '') === 'MB WAY'): ?>
                        📱 Receberá uma notificação no seu telemóvel para confirmar o pagamento via MB WAY.
                    <?php elseif (($order['metodo_pagamento'] ?? '') === 'PayPal'): ?>
                        🅿️ O pagamento será processado através do PayPal. Receberá um email com os detalhes.
                    <?php else: ?>
                        💳 O pagamento será processado. Receberá uma confirmação por email.
                    <?php endif; ?>
                </p>
            </div>

            <div class="next-steps">
                <h3>📋 Próximos Passos</h3>
                <ul>
                    <li>Receberá um email de confirmação em breve</li>
                    <li>Após confirmação do pagamento, a encomenda será processada</li>
                    <li>Poderá acompanhar o estado da encomenda na sua conta</li>
                    <li>Será notificado quando a encomenda for enviada</li>
                </ul>
            </div>
        </div>
        <?php endif; ?>

        <!-- Botões de Ação -->
        <div class="action-buttons">
            <a href="index.php" class="btn btn-primary">🏠 Voltar à Página Principal</a>
            <a href="conta.php" class="btn btn-secondary">📦 Ver Minhas Encomendas</a>
        </div>

        <div style="text-align: center; margin-top: 30px; color: #999; font-size: 14px;">
            <p><?= $order['status'] === 'Cancelado' ? 'Se tiver alguma dúvida, entre em contacto connosco.' : 'Obrigado por comprar na GomesTech! 🎉' ?></p>
        </div>
    </div>
</body>
</html>
