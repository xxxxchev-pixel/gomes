# 📦 GomesTech - Base de Dados

## 🎯 Sistema Totalmente Automatizado

A base de dados GomesTech está **100% consolidada e automatizada** num único ficheiro SQL com **stored procedures, functions e triggers** que substituem todos os scripts PHP externos.

---

## 📄 Ficheiro Principal

### 🔵 GOMESTECH.sql
**Ficheiro Principal - ÚNICO E COMPLETO COM AUTOMAÇÃO**

Este é o **único ficheiro SQL necessário** para criar toda a base de dados GomesTech com todas as funcionalidades automatizadas.

#### ✨ O que está incluído:

**Estrutura Completa:**
- ✅ 10 Tabelas principais (users, categories, brands, produtos, favoritos, comparacao, carrinho, encomendas, encomenda_itens, promocoes)
- ✅ 13 Categorias pré-definidas
- ✅ 42 Marcas principais
- ✅ 1 Utilizador admin (admin@gomestech.pt / admin123)

**Funcionalidades Avançadas:**
- ✅ 4 Views úteis (produtos populares, estatísticas, baixo stock, produtos completos)
- ✅ 3 Triggers automáticos (gestão de stock, SKU auto, geração de nomes)
- ✅ 8 Stored Procedures (gestão completa de produtos e preços)
- ✅ 3 Functions úteis (cálculos e validações)
- ✅ Índices otimizados para performance
- ✅ Foreign Keys configuradas
- ✅ Campos timestamp automáticos
- ✅ UTF-8 (utf8mb4) configurado

**Automações Integradas (substituem scripts PHP):**
- 🤖 Geração automática de slugs
- 💰 Aplicação de descontos por categoria
- 📊 Diagnóstico da base de dados
- 💵 Atualização inteligente de preços
- 🔍 Pesquisa avançada de produtos
- 📈 Definição automática de preços por categoria/marca

---

## 🚀 Como Instalar

### Opção 1: phpMyAdmin (Recomendado)
1. Abrir phpMyAdmin
2. Clicar em "Importar"
3. Selecionar `GOMESTECH.sql`
4. Clicar em "Executar"
5. ✅ Pronto! Tudo automatizado!

### Opção 2: Linha de Comandos MySQL
```bash
mysql -u root -p < database/GOMESTECH.sql
```

### Opção 3: Via PHP (Apenas para importar produtos do JSON)
```bash
php database/importar_catalogo_json.php
```

---

## 🤖 Comandos Automatizados (Stored Procedures)

Todas as funcionalidades estão integradas na base de dados:

### 1. Gerar Slugs para Todos os Produtos
```sql
CALL sp_gerar_todos_slugs();
```
**Funcionalidade:** Regenera slugs URL-friendly para todos os produtos
**Exemplo:** "iPhone 15 Pro Max" → "iphone-15-pro-max"

### 2. Aplicar Descontos por Categoria
```sql
CALL sp_aplicar_desconto_categoria('Smartphones', 15);
```
**Funcionalidade:** Aplica 15% de desconto em todos os Smartphones
**Categorias disponíveis:** Smartphones, Laptops, Tablets, TVs, Audio, Consolas, Wearables, Frigoríficos, Máquinas de Lavar, Micro-ondas, Aspiradores, Ar Condicionado, Máquinas de Café

### 3. Remover Descontos de uma Categoria
```sql
CALL sp_remover_desconto_categoria('Laptops');
```
**Funcionalidade:** Restaura preços originais dos Laptops

### 4. Marcar Produtos em Destaque
```sql
CALL sp_marcar_destaques(20);
```
**Funcionalidade:** Define os 20 produtos mais vendidos como destaque
---

## 🔧 Functions Úteis

### 1. Calcular Desconto Percentual
```sql
SELECT fn_calcular_desconto(999.00, 799.00);  -- Retorna 20.02
```

### 2. Verificar se Produto está em Promoção
```sql
SELECT fn_em_promocao(1);  -- Retorna 0 ou 1
```

### 3. Criar Slug Limpo
```sql
SELECT fn_slugify('iPhone 15 Pro Max 256GB');  -- Retorna 'iphone-15-pro-max-256gb'
```

---

## 📊 Estrutura da Base de Dados

### Tabelas Principais

```
gomestech/
├── 👥 users                    Utilizadores do sistema
├── 📂 categories               Categorias de produtos
├── 🏷️ brands                   Marcas de produtos
├── 📦 produtos                 Catálogo completo
├── ⭐ favoritos                Lista de desejos
├── 🔄 comparacao               Comparação de produtos
├── 🛒 carrinho                 Carrinho de compras
├── 📋 encomendas               Pedidos/Encomendas
├── 📝 encomenda_itens          Itens das encomendas
└── 🏷️ promocoes                Promoções temporárias
```

### Categorias Incluídas

1. 📱 Smartphones
2. 💻 Laptops
3. 📱 Tablets
4. ⌚ Wearables
5. 📺 TVs
6. 🎧 Audio
7. 🎮 Consolas
8. 🧊 Frigoríficos
9. 🌀 Máquinas de Lavar
10. 📦 Micro-ondas
11. 🧹 Aspiradores
12. ❄️ Ar Condicionado
13. ☕ Máquinas de Café

### Marcas Principais (42 total)

**Tecnologia:** Apple, Samsung, Google, OnePlus, Dell, Lenovo, HP, Asus, MSI, Sony, Microsoft, Nintendo, LG, Philips, TP-Link, Xiaomi, Motorola, Realme

**Audio:** Bose, JBL, Sonos, Marshall, Harman Kardon, Amazon

**Eletrodomésticos:** Bosch, Siemens, Whirlpool, Beko, Indesit, Teka, Panasonic, Dyson, Rowenta, iRobot

**Climatização:** Daikin, Mitsubishi, Fujitsu

**Café:** De'Longhi, Nespresso, Sage, Krups

---

## 🔐 Credenciais Padrão

### Utilizador Administrador
- **Email:** admin@gomestech.pt
- **Password:** admin123
- **Tipo:** Administrador (is_admin = 1)

> ⚠️ **Segurança:** Altere a password do admin após a primeira instalação!

---

## 📈 Funcionalidades Automáticas

### Triggers

#### 1. after_encomenda_item_insert
- Atualiza stock automaticamente ao criar item de encomenda
- Calcula subtotal do item

#### 2. after_encomenda_cancelada
- Restaura stock quando encomenda é cancelada
- Reverte as quantidades para o stock

#### 3. before_produto_insert
- Gera SKU automaticamente se não fornecido
- Gera nome do produto (marca + modelo)
- Define preco_original igual a preco se não fornecido

### Views (4 no total)

#### v_produtos_populares
Lista produtos mais vendidos com estatísticas

#### v_stats_encomendas
Estatísticas diárias de encomendas e receita

#### v_produtos_baixo_stock
Produtos com stock inferior a 10 unidades

#### v_produtos_completo
View completa com todas as informações de produtos incluindo:
- Informações de categoria e marca
- Desconto percentual calculado
- Status de promoção
- Total de favoritos e comparações

---

## 🎯 Exemplos de Uso

### Workflow Completo de Gestão de Produtos

```sql
-- 1. Importar produtos (via PHP ou manual)
-- php database/importar_catalogo_json.php

-- 2. Gerar slugs automaticamente
CALL sp_gerar_todos_slugs();

-- 3. Definir preços inteligentes para produtos sem preço
CALL sp_definir_precos_inteligentes();

-- 4. Aplicar descontos de Black Friday
CALL sp_aplicar_descontos_globais();

-- 5. Ver produtos em promoção
SELECT * FROM v_produtos_completo WHERE desconto_percentual > 0;

-- 6. Diagnóstico geral
CALL sp_diagnostico();
```

### Atualização de Preços Individual

```sql
-- Atualizar preço de um produto específico
CALL sp_atualizar_preco('Apple', 'iPhone 15 Pro', 1179.00);

-- Aplicar 25% de desconto em todos os smartphones
CALL sp_aplicar_descontos_categoria('Smartphones', 25.00);

-- Ver produtos com maior desconto
SELECT marca, modelo, preco_original, preco, 
       fn_calcular_desconto(preco_original, preco) AS desconto
FROM produtos 
WHERE preco < preco_original
ORDER BY desconto DESC
LIMIT 10;
```

### Pesquisa e Análise

```sql
-- Pesquisar produtos
CALL sp_pesquisar_produtos('iPhone', NULL, 10);

-- Ver produtos populares
SELECT * FROM v_produtos_populares LIMIT 10;

-- Produtos com stock baixo
SELECT * FROM v_produtos_baixo_stock;

-- Estatísticas de encomendas
SELECT * FROM v_stats_encomendas;
```

---

## ⚙️ Configuração no config.php

O ficheiro `config.php` já está configurado para conectar à base de dados:

```php
define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'gomestech');
```

**Suporta variáveis de ambiente** (`.env`):
```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASS=
DB_NAME=gomestech
```

---

## 🔍 Verificação Pós-Instalação

Execute estas queries para verificar a instalação:

```sql
-- Verificar tabelas criadas (esperado: 10)
SELECT COUNT(*) as total_tabelas 
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'gomestech' AND TABLE_TYPE = 'BASE TABLE';

-- Verificar stored procedures (esperado: 8)
SELECT COUNT(*) as total_procedures
FROM information_schema.ROUTINES 
WHERE ROUTINE_SCHEMA = 'gomestech' AND ROUTINE_TYPE = 'PROCEDURE';

-- Verificar functions (esperado: 3)
SELECT COUNT(*) as total_functions
FROM information_schema.ROUTINES 
WHERE ROUTINE_SCHEMA = 'gomestech' AND ROUTINE_TYPE = 'FUNCTION';

-- Verificar views (esperado: 4)
SELECT COUNT(*) as total_views
FROM information_schema.VIEWS 
WHERE TABLE_SCHEMA = 'gomestech';

-- Verificar triggers (esperado: 3)
SELECT COUNT(*) as total_triggers
FROM information_schema.TRIGGERS 
WHERE TRIGGER_SCHEMA = 'gomestech';

-- Diagnóstico completo
CALL sp_diagnostico();
```

---

## 📚 Documentação Técnica

### Estrutura de Ficheiros

```
database/
├── GOMESTECH.sql              ⭐ Ficheiro principal (ÚNICO necessário)
├── importar_catalogo_json.php  Importador de produtos do JSON (opcional)
└── README.md                   Esta documentação
```

### Scripts PHP Removidos (Agora na DB)

Os seguintes scripts foram **integrados como stored procedures** e removidos:

- ❌ `aplicar_descontos_globais.php` → ✅ `CALL sp_aplicar_descontos_globais();`
- ❌ `atualizar_precos_mercado.php` → ✅ `CALL sp_atualizar_preco(...);`
- ❌ `atualizar_todos_precos.php` → ✅ `CALL sp_definir_precos_inteligentes();`
- ❌ `executar_atualizacao_precos.php` → ✅ `CALL sp_atualizar_preco(...);`
- ❌ `gerar_slugs.php` → ✅ `CALL sp_gerar_todos_slugs();`
- ❌ `diagnostico_rapido.php` → ✅ `CALL sp_diagnostico();`
- ❌ `listar_produtos.php` → ✅ `SELECT * FROM produtos;`
- ❌ `limpar_ficheiros.php` → (não necessário)
- ❌ Todos os ficheiros `.sql` duplicados → ✅ `GOMESTECH.sql`

### Vantagens da Integração na Base de Dados

✅ **Performance:** Execução direta no servidor MySQL (mais rápido)  
✅ **Segurança:** Sem necessidade de scripts PHP externos  
✅ **Manutenção:** Tudo centralizado num único local  
✅ **Portabilidade:** Funciona em qualquer sistema com MySQL  
✅ **Consistência:** Garante integridade dos dados  
✅ **Automação:** Triggers executam automaticamente  
✅ **Simplicidade:** Menos ficheiros para gerir  

---

## 🆘 Resolução de Problemas

### Erro ao importar GOMESTECH.sql

**Problema:** Timeout ou erro de memória  
**Solução:** Aumentar `max_execution_time` e `memory_limit` no php.ini

### Stored Procedures não encontradas

**Problema:** Procedures não aparecem após importação  
**Solução:** Verificar se MySQL suporta stored procedures (versão 5.0+)

```sql
-- Listar procedures disponíveis
SHOW PROCEDURE STATUS WHERE Db = 'gomestech';

-- Listar functions disponíveis
SHOW FUNCTION STATUS WHERE Db = 'gomestech';
```

### Produtos sem slug

**Problema:** Produtos importados sem slug  
**Solução:** Executar gerador automático

```sql
CALL sp_gerar_todos_slugs();
```

### Preços desatualizados

**Problema:** Preços não refletem mercado  
**Solução:** Aplicar preços inteligentes ou descontos

```sql
CALL sp_definir_precos_inteligentes();
-- ou
CALL sp_aplicar_descontos_globais();
```

---

## 📞 Suporte e Manutenção

### Comandos de Manutenção Periódica

```sql
-- Otimizar todas as tabelas (executar mensalmente)
OPTIMIZE TABLE users, categories, brands, produtos, favoritos, 
               comparacao, carrinho, encomendas, encomenda_itens, promocoes;

-- Analisar tabelas (executar após grandes alterações)
ANALYZE TABLE produtos;

-- Ver tamanho da base de dados
SELECT 
    table_schema AS 'Database',
    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Size (MB)'
FROM information_schema.tables
WHERE table_schema = 'gomestech'
GROUP BY table_schema;
```

### Backup Automático

```bash
# Criar backup completo
mysqldump -u root -p gomestech > gomestech_backup_$(date +%Y%m%d).sql

# Restaurar backup
mysql -u root -p gomestech < gomestech_backup_20250126.sql
```

---

## 🎉 Conclusão

A base de dados GomesTech está **totalmente automatizada** e **pronta para produção**!

✅ **Instalação simples:** Um único ficheiro SQL  
✅ **Gestão automatizada:** Stored procedures para tudo  
✅ **Alta performance:** Índices e otimizações  
✅ **Segurança:** Triggers e validações  
✅ **Escalabilidade:** Estrutura profissional  

**Próximos passos:**
1. Importar `GOMESTECH.sql`
2. Executar `CALL sp_diagnostico();`
3. Importar produtos: `php importar_catalogo_json.php`
4. Gerar slugs: `CALL sp_gerar_todos_slugs();`
5. Aceder ao site: `http://localhost/gomestech/`

---

**GomesTech** - Sistema de E-commerce Profissional 🚀
SELECT COUNT(*) as total_produtos FROM produtos;
-- Esperado: 70+

-- Verificar categorias
SELECT COUNT(*) as total_categorias FROM categories;
-- Esperado: 13

-- Verificar marcas
SELECT COUNT(*) as total_marcas FROM brands;
-- Esperado: 42

-- Verificar views
SELECT COUNT(*) as total_views 
FROM information_schema.VIEWS 
WHERE TABLE_SCHEMA = 'gomestech';
-- Esperado: 3

-- Verificar triggers
SELECT COUNT(*) as total_triggers 
FROM information_schema.TRIGGERS 
WHERE TRIGGER_SCHEMA = 'gomestech';
-- Esperado: 3

-- Verificar stored procedures
SELECT COUNT(*) as total_procedures 
FROM information_schema.ROUTINES 
WHERE ROUTINE_SCHEMA = 'gomestech' AND ROUTINE_TYPE = 'PROCEDURE';
-- Esperado: 2
```

---

## 📝 Notas Importantes

### ✅ Características
- **Uma única base de dados:** `gomestech`
- **Character set:** UTF-8 (utf8mb4_unicode_ci)
- **Engine:** InnoDB (transações e foreign keys)
- **Timestamps:** Automáticos (created_at, updated_at)
- **Foreign keys:** Configuradas com ON DELETE CASCADE/RESTRICT
- **Índices:** Otimizados para pesquisas rápidas

### ⚠️ Avisos
- O script **elimina a base de dados existente** (`DROP DATABASE IF EXISTS`)
- Faça **backup** antes de executar em produção
- Password do admin é simples (altere em produção)
- Taxa de envio: €5 (grátis acima de €50)
- IVA configurado a 23% (Portugal)

### 🔧 Manutenção
```sql
-- Otimizar todas as tabelas
OPTIMIZE TABLE users, categories, brands, produtos, 
    favoritos, comparacao, carrinho, encomendas, 
    encomenda_itens, promocoes;

-- Analisar tabelas
ANALYZE TABLE produtos, encomendas;

-- Ver tamanho da base de dados
SELECT 
    table_schema AS 'Database',
    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Size (MB)'
FROM information_schema.tables
WHERE table_schema = 'gomestech'
GROUP BY table_schema;
```

---

## 🎉 Resumo

- ✅ **1 ficheiro SQL** para toda a base de dados
- ✅ **10 tabelas** principais
- ✅ **70+ produtos** de exemplo
- ✅ **13 categorias** e **42 marcas**
- ✅ **Automação completa** (triggers, procedures, views)
- ✅ **Performance otimizada** (índices, foreign keys)
- ✅ **Pronto para produção**

---

**Versão:** 2.0 (Consolidada)  
**Última Atualização:** 24 Novembro 2025  
**Autor:** GomesTech Development Team
